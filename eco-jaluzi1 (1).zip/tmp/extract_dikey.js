const fs = require('fs');

const rawHtml = `
<a href="https://ibb.co/Ndd47RrN"><img src="https://i.ibb.co/zTTkNdF2/photo-2026-08-28-11-39-23.jpg" alt="photo-2026-08-28-11-39-23" border="0"></a>
<a href="https://ibb.co/rfG1GKTf"><img src="https://i.ibb.co/JFRMRW0F/photo-2026-08-28-11-39-22.jpg" alt="photo-2026-08-28-11-39-22" border="0"></a>
<a href="https://ibb.co/Ndk2nkZg"><img src="https://i.ibb.co/67p0Jpgc/photo-2026-08-28-11-39-20.jpg" alt="photo-2026-08-28-11-39-20" border="0"></a>
<a href="https://ibb.co/JjZj3Pd5"><img src="https://i.ibb.co/LdKdNfPn/photo-2026-08-28-11-39-19.jpg" alt="photo-2026-08-28-11-39-19" border="0"></a>
<a href="https://ibb.co/wZGsLKbt"><img src="https://i.ibb.co/SDYrxK1S/photo-2026-08-28-11-39-18.jpg" alt="photo-2026-08-28-11-39-18" border="0"></a>
<a href="https://ibb.co/tpKZbfT2"><img src="https://i.ibb.co/HT4NrvfP/photo-2026-08-28-11-39-17.jpg" alt="photo-2026-08-28-11-39-17" border="0"></a>
<a href="https://ibb.co/FkdRzSMg"><img src="https://i.ibb.co/DPj0Qxy5/photo-2026-08-28-11-39-15.jpg" alt="photo-2026-08-28-11-39-15" border="0"></a>
<a href="https://ibb.co/dJw6zscv"><img src="https://i.ibb.co/HpfYkL2y/photo-2026-08-28-11-39-14.jpg" alt="photo-2026-08-28-11-39-14" border="0"></a>
<a href="https://ibb.co/ZzLSQ09f"><img src="https://i.ibb.co/b5WF4kt6/photo-2026-08-28-11-39-13.jpg" alt="photo-2026-08-28-11-39-13" border="0"></a>
<a href="https://ibb.co/5h12d9sF"><img src="https://i.ibb.co/CKwWqtV2/photo-2026-08-28-11-39-11.jpg" alt="photo-2026-08-28-11-39-11" border="0"></a>
<a href="https://ibb.co/C5ftb3X8"><img src="https://i.ibb.co/bgk3sMym/photo-2026-08-28-11-39-10.jpg" alt="photo-2026-08-28-11-39-10" border="0"></a>
<a href="https://ibb.co/YFwhytVb"><img src="https://i.ibb.co/7dLKRG0b/photo-2026-08-28-11-39-09.jpg" alt="photo-2026-08-28-11-39-09" border="0"></a>
<a href="https://ibb.co/7tFf7wtb"><img src="https://i.ibb.co/yFJ9LwFV/photo-2026-08-28-11-39-07.jpg" alt="photo-2026-08-28-11-39-07" border="0"></a>
<a href="https://ibb.co/wZ6qNYhv"><img src="https://i.ibb.co/9mY09GHM/photo-2026-06-06-17-47-56-2.jpg" alt="photo-2026-06-06-17-47-56-2" border="0"></a>
<a href="https://ibb.co/HfsxDDwG"><img src="https://i.ibb.co/NdPm66DW/photo-2026-08-28-11-39-06.jpg" alt="photo-2026-08-28-11-39-06" border="0"></a>
<a href="https://ibb.co/Jj11jspJ"><img src="https://i.ibb.co/DfJJfRM2/photo-2026-08-28-11-38-59.jpg" alt="photo-2026-08-28-11-38-59" border="0"></a>
<a href="https://ibb.co/pvTpzTJR"><img src="https://i.ibb.co/MDHLVHMG/photo-2026-08-28-11-38-57.jpg" alt="photo 2026 08 28 11 38 57" border="0"></a>
<a href="https://ibb.co/xqt022RH"><img src="https://i.ibb.co/Kxpk553w/photo-2026-08-28-11-38-56.jpg" alt="photo-2026-08-28-11-38-56" border="0"></a>
<a href="https://ibb.co/F42N4xt4"><img src="https://i.ibb.co/d4F14Wy4/photo-2026-08-28-11-38-55.jpg" alt="photo-2026-08-28-11-38-55" border="0"></a>
<a href="https://ibb.co/7xBSwRS2"><img src="https://i.ibb.co/twnH7xH8/photo-2026-07-13-17-00-56-3.jpg" alt="photo-2026-07-13-17-00-56-3" border="0"></a>
<a href="https://ibb.co/tw7LCfdQ"><img src="https://i.ibb.co/fVhD0Rcq/photo-2026-07-13-17-00-56-2.jpg" alt="photo-2026-07-13-17-00-56-2" border="0"></a>
<a href="https://ibb.co/PXwpvz3"><img src="https://i.ibb.co/vyZ56vg/photo-2026-07-13-17-00-56.jpg" alt="photo-2026-07-13-17-00-56" border="0"></a>
<a href="https://ibb.co/RTNWcQ0g"><img src="https://i.ibb.co/8gbV9P5m/photo-2026-07-13-17-00-55-7.jpg" alt="photo-2026-07-13-17-00-55-7" border="0"></a>
<a href="https://ibb.co/r2CxX97Y"><img src="https://i.ibb.co/yFw6x2ft/photo-2026-07-13-17-00-55-6.jpg" alt="photo-2026-07-13-17-00-55-6" border="0"></a>
<a href="https://ibb.co/SLsn4Cs"><img src="https://i.ibb.co/1SvqtWv/photo-2026-07-13-17-00-55-5.jpg" alt="photo-2026-07-13-17-00-55-5" border="0"></a>
<a href="https://ibb.co/zDMgD0B"><img src="https://i.ibb.co/bD0VD8C/photo-2026-07-13-17-00-55-4.jpg" alt="photo-2026-07-13-17-00-55-4" border="0"></a>
<a href="https://ibb.co/SwH11sVC"><img src="https://i.ibb.co/KxBQQ0Vv/photo-2026-07-13-17-00-55-3.jpg" alt="photo-2026-07-13-17-00-55-3" border="0"></a>
<a href="https://ibb.co/VYGwZDBm"><img src="https://i.ibb.co/Zzr2PKTm/photo-2026-07-13-17-00-55-2.jpg" alt="photo-2026-07-13-17-00-55-2" border="0"></a>
`;

const regex = /src="(https:\/\/i\.ibb\.co\/[^"]+)"/g;
let match;
const urls = [];
while ((match = regex.exec(rawHtml)) !== null) {
  if (!urls.includes(match[1])) {
    urls.push(match[1]);
  }
}

console.log('Total unique Dikey URLs extracted:', urls.length);
console.log(urls);
