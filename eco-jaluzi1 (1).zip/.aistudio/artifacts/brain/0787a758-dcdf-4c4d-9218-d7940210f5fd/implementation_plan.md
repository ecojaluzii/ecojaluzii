# Mahsulotlar Katalogida "Rollo jaluzi (Roller blinds)" Alohida Bo'limi va Galereyasi

Mahsulotlar katalogiga yangi alohida "Rollo jaluzi (Roller blinds)" toifasi/papkasi qo'shiladi hamda foydalanuvchi yuborgan 70+ ta real rollo jaluzi namunalari va modellari to'liq interaktiv galereya, filtrlar va buyurtma berish tugmalari bilan ta'minlanadi.

---

### Foydalanuvchi Tanlovi va Tasdiqlangan Qarorlar

> [!IMPORTANT]
> Foydalanuvchi tomonidan interaktiv so'rov orqali quyidagi asosiy qarorlar tasdiqlandi:
> 1. **Bo'lim joylashuvi**: Faqat **Mahsulotlar katalogi** ichida alohida papka/bo'lim sifatida ochiladi.
> 2. **Sarlavha va nomlanishi**: **"Rollo jaluzi (Roller blinds)"** deb nomlanadi.

---

## 1. Umumiy Ko'rinish va Imkoniyatlar

- **Asosiy maqsad**: Foydalanuvchi Mahsulotlar katalogiga kirganda to'g'ridan-to'g'ri "Rollo jaluzi (Roller blinds)" papkasini tanlashi, 70+ ta barcha rollo matolari va modellarining fotosuratlarini ko'rishi, ularni kattalashtirishi (lightbox/zoom) va tanlangan model bo'yicha bevosita mutaxassis bilan bog'lanishi mumkin bo'ladi.
- **Qulaylik**: Rollo jaluzilar matolari, turlari (Blackout, Dimout, Plain, Teksturali) va o'rnatish uslublari bo'yicha saralangan holda qulay va tez yuklanadi.
- **Tezkor kirish**: Katalog bosh sahifasidagi tezkor toifalar qatorida ham "Rollo jaluzi" tugmasi birinchi qatorlarda qulay joylashtiriladi.

---

## 2. Foydalanuvchi Tajribasi va Dizayn (UX / Visual Design)

1. **Katalogdagi Papka & Banner**:
   - Mahsulotlar katalogining yuqori toifalar panelida `"Rollo jaluzi (Roller blinds)"` alohida papka va faol filtr sifatida ajratib ko'rsatiladi.
   - Tanlanganda Rollo jaluzi bo'yicha maxsus qulay katalog oynasi (yoki toifaviy grid) ochiladi.
2. **Kengaytirilgan Rollo Galereyasi**:
   - Foydalanuvchi yuborgan barcha 70+ ta rasm yuqori sifatda, to'liq aspect-ratio bilan yuklanadi.
   - Har bir rasm uchun `referrerPolicy="no-referrer"` ta'minlanadi (`i.ibb.co` xatolarining oldini olish uchun).
   - Har bir rasmda "To'liq ko'rish (Zoom)" va "Shu modeldan buyurtma qilish" imkoniyatlari bo'ladi.
3. **Lightbox & Modal ko'rish**:
   - Rasmni bosganda to'liq ekranli fotogalereya (oldingi/keyingi suratlarga o'tish, raqamlash) ishlaydi.
   - Dizayn "Eco Jaluzi" brendi ranglari (emerald yashil, issiq oltin/amber, qaymoqrang fon) bilan uyg'unlashtiriladi.

---

## 3. Texnik Arxitektura va Ma'lumotlar Tuzilmasi

```
┌────────────────────────────────────────────────────────┐
│             Mahsulotlar Katalogi (Modal / Oyna)        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Toifalar: Barchasi | Rollo Jaluzi | Dikey | ...  │  │
│  └──────────────────────────────────────────────────┘  │
│                           │                            │
│             [Rollo jaluzi tanlanganda]                 │
│                           ▼                            │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 70+ ta Rollo Mahsulotlari va Matolari Kartalari  │  │
│  │ (Surat + Model nomi + Xususiyatlar + Buyurtma)   │  │
│  └──────────────────────────────────────────────────┘  │
│                           │                            │
│             [Rasm ustiga bosilganda]                   │
│                           ▼                            │
│  ┌──────────────────────────────────────────────────┐  │
│  │ To'liq ekranli Lightbox / Zoom fotogalereyasi    │  │
│  └──────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────┘
```

- **Ma'lumotlar manbai**: `src/data/rolloCatalog.ts` (yoki `src/data/rolloGallery.ts`) faylida barcha 70+ ta unikal rasmlar ro'yxati, ID'lari, saralash parametrlari va ma'lumotlari jamlanadi.
- **dbService integratsiyasi**: `src/services/db.ts` orqali mahsulotlar to'plamiga Rollo modellari to'liq integratsiya qilinadi.
- **Komponentlar**: `MainCatalogsGateway.tsx` va `RolloGalleryModal.tsx` komponentlarida tegishli boshqaruvchi funksiyalar va filtrlash bog'lanadi.

---

## 4. Amalga Oshirish Bosqichlari

1. **1-bosqich**: Foydalanuvchi yuborgan barcha 70+ ta rasm URL'larini tozalab, `src/data/rolloCatalog.ts` fayliga tartibli formatda joylashtirish.
2. **2-bosqich**: `MainCatalogsGateway.tsx` faylida Mahsulotlar katalogi toifalari orasiga "Rollo jaluzi (Roller blinds)" papkasini qo'shish va filtr mantiqini yangilash.
3. **3-bosqich**: Mahsulotlar katalogida Rollo rasmlari to'liq ochilishi uchun maxsus interaktiv kartalar, lightbox va modal ko'rish qismini ulash.
4. **4-bosqich**: Kompilyatsiya va xatoliklarni tekshirish (`compile_applet`, `lint_applet`).
