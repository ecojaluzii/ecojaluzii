import { GoogleGenAI } from "@google/genai";

export const handler = async (event: any) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 450, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const { message, image, history, lang, productsContext } = body;

    const apiKey = process.env.GEMINI_API_KEY;
    let ai: GoogleGenAI | null = null;
    if (apiKey) {
      ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
    }

    if (ai) {
      let langInstruction = "";
      if (lang === 'ru') {
        langInstruction = "Разговаривайте с клиентом исключительно на русском языке. Давайте полные, вежливые, подробные и структурированные ответы.";
      } else if (lang === 'en') {
        langInstruction = "Speak with the client exclusively in English. Provide full, polite, detailed, and structured answers.";
      } else {
        langInstruction = "Mijoz bilan FAQAT O'ZBEK TILIDA gaplashing. Har doim to'liq, muloyim, batafsil, tushunarli va chiroyli tartiblangan javob bering.";
      }

      const systemInstruction = `Siz "ECO JALUZI" kompaniyasining aqlli, do'stona, samimiy va professional virtual AI maslahatchisiz.

ASOSIY QOIDALAR VA VAZIFALAR:
1. Salomlashish va odob-axloq:
   - Agar mijoz salom bersa (masalan: "Salom", "Assalomu alaykum", "Salom alaykum", "Hayrli kun", "Privet", "Hello" va h.k.), albatta salomiga iliq va samimiy alik oling ("Vaalaykum assalom!", "Assalomu alaykum!"), o'zingiz ham salom berib, hol-ahvol so'rang va qanday yordam bera olishingizni so'rang.
2. To'liq va batafsil javob berish:
   - Mijozning har qanday savoliga har tomonlama to'liq, tushunarli, qiziqarli va professional darajada batafsil javob bering. Qisqa yoki quruq 1-2 jumlali javoblar bilan cheklanmang.
3. NARXLARNI HISOBLAMASLIK QOIDASI (QAT'IY TALAB):
   - Siz sun'iy intellekt sifatida mijozga qat'iy matematik hisob-kitob (masalan: "falon metr jaluzi faloncha so'm bo'ladi" deb narx hisoblash) QILMANG!
   - Agar mijoz narx so'rasa yoki hisoblashni iltimos qilsa:
     * Narxlar tanlangan mato toifasi, zichligi, mexanizm turi va deraza o'lchamiga qarab individual hisoblanishini tushuntiring.
     * Mutaxassisimiz barcha mato namunalari (katalog) bilan mijoz xonadoniga borib, aniq o'lchov olib, yakuniy smetani hisoblab berishini ayting.
     * Shuningdek, mijoz saytimizdagi "Narx Kalkulyatori" yoki "3D Dizayner" bo'limi orqali taxminiy hisob-kitobni o'zi amalga oshirishi mumkinligini eslatib o'ting.
4. QAT'IY TAQIQLANGAN SO'Z ("bepul"):
   - "Bepul", "bepulga", "besplatno", "free" so'zlarini UMUMAN ISHLATMANG! Hech qachon bu so'zni tilga olmang.
   - Xizmatlar haqida gapirganda "o'lchov olish va professional konsultatsiya xizmatimiz mavjud" deb ayting, ammo "bepul" so'zini aslo qo'llamang.
5. Rasm yaratish qoidasi (DIQQAT!):
   - Faqat va faqat mijozning o'zi to'g'ridan-to'g'ri rasm yaratishni yoki dizayn chizib berishni SO'RAGANDA (masalan: "rasm yarat", "rasmini yaratib ber", "dizayn ko'rsat", "surat chizib ber", "rasm chiqar", "generate image" deb aniq so'rasa), javobingiz oxiriga [GENERATE_IMAGE: <ingliz tilida batafsil rasm tavsifi>] kodini qo'shing.
   - AGAR mijoz rasm yaratishni so'ramagan bo'lsa (masalan, shunchaki savol berayotgan, narx so'rayotgan, salomlashayotgan yoki shunchaki deraza rasmini yuborgan bo'lsa), O'ZINGIZDAN O'ZINGIZ ASLO rasm yaratmang va [GENERATE_IMAGE] kodini yozmang! Faqat to'liq matnli maslahat va javob bering.
6. Mahsulotlar haqida ma'lumot:
   - Jaluzilar, ularning turlari (Combo/Zebra, Dikey, Plisse, Rollor, Bambuk/Yog'och va boshqalar), matolar, mexanizmlar va xususiyatlari haqida quyidagi sayt ma'lumotlar bazasiga tayanib to'liq ma'lumot bering.
   - Bog'lanish uchun telefon raqamimiz: +998 94 000 99 77.

${langInstruction}

Quyidagi ma'lumotlar (saytdagi mahsulotlar bazasi) - sizning asosiy bilimlaringiz manbayi:
${productsContext || "Mahsulotlar: Combo (Zebra jaluzi), Dikey (Vertikal jaluzi), Plisse, Rollor (Rolikli parda), Bambuk va boshqa premium jaluzi turlari."}`;

      const contents: any[] = [];
      if (history && Array.isArray(history)) {
        history.forEach((msg: any) => {
          contents.push({ role: msg.role, parts: [{ text: msg.text }] });
        });
      }

      const parts: any[] = [];
      if (image) {
        const base64Data = image.split(',')[1] || image;
        const mimeType = image.split(';')[0].split(':')[1] || 'image/jpeg';
        parts.push({
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        });
      }
      if (message) {
        parts.push({ text: message });
      }

      contents.push({ role: 'user', parts });

      const modelsToTry = [
        'gemini-3.6-flash',
        'gemini-3.1-flash-lite',
        'gemini-flash-latest',
        'gemini-3.8-flash'
      ];

      for (const model of modelsToTry) {
        try {
          const response = await ai.models.generateContent({
            model,
            contents,
            config: {
              systemInstruction,
              temperature: 0.6
            }
          });
          const text = response.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) {
            return { statusCode: 200, headers, body: JSON.stringify({ text }) };
          }
        } catch (mErr: any) {
          console.warn(`Netlify function model ${model} failed:`, mErr.message);
        }
      }
    }

    // Fallback response if AI is not configured or fails
    const lower = (message || "").toLowerCase().trim();
    let text = "";
    if (lang === 'ru') {
      if (lower.includes("привет") || lower.includes("здравствуй") || lower.includes("салам") || lower.includes("добрый") || lower === "hi" || lower === "hello") {
        text = "Здравствуйте! Рады приветствовать вас в **ECO JALUZI**!\n\nЧем я могу вам помочь сегодня? Мы являемся прямым производителем современных, качественных и экологичных жалюзи и штор для любых типов окон и интерьеров.\n\nВы можете задать любой вопрос по моделям, материалам, подбору под интерьер или отправить фото вашей комнаты/окна для экспертной консультации!\n\n📞 Связь с нами: **+998 94 000 99 77**";
      } else if (lower.includes("создай фото") || lower.includes("создай дизайн") || lower.includes("нарисуй") || lower.includes("сгенерируй") || lower.includes("дизайн")) {
        text = "С удовольствием подготовлю для вас персональный визуальный дизайн жалюзи! [GENERATE_IMAGE: modern luxury window blinds zebra combo and roller shades in an elegant stylish room interior]";
      } else if (lower.includes("виды") || lower.includes("какие") || lower.includes("каталог") || lower.includes("модели") || lower.includes("ассортимент") || lower.includes("типы")) {
        text = "В каталоге **ECO JALUZI** представлены все современные и премиальные виды жалюзи:\n\n1. **Combo (День-Ночь / Зебра)** — самый популярный выбор для спален и гостиных. Двойное полотно позволяет плавно регулировать естественный свет.\n2. **Dikey (Вертикальные тканевые жалюзи)** — идеальное решение для панорамных и высоких окон, офисов и гостиных. Тканевые ламели поворачиваются на 180°.\n3. **Rollor (Рулонные шторы)** — практичные, лаконичные шторы с пылеотталкивающей пропиткой.\n4. **Plisse (Плиссе)** — изящные жалюзи-гармошки для стандартных, арочных и мансардных окон.\n5. **Бамбуковые и деревянные жалюзи** — 100% натуральные экологичные материалы, придающие интерьеру особый уют.\n6. **Алюминиевые и Римские шторы** — долговечность, строгость и классический стиль.\n\nДля какой комнаты вы подбираете жалюзи? С радостью поможем с выбором!\n📞 Консультация: **+998 94 000 99 77**";
      } else if (lower.includes("цена") || lower.includes("цены") || lower.includes("стоимость") || lower.includes("сколько") || lower.includes("замер") || lower.includes("заказ") || lower.includes("купить") || lower.includes("посчитай")) {
        text = "Стоимость жалюзи в **ECO JALUZI** рассчитывается индивидуально в зависимости от выбранного типа жалюзи, категории ткани и точных размеров окна.\n\n🔹 **Как происходит точный расчет?**\n- Наш специалист выезжает к вам с полным каталогом тканей и материалов\n- Проводит точные замеры окна и рассчитывает смету\n- Собственное производство без посреднических наценок\n- Официальная гарантия **1 год** на механизмы и ткани\n\nТакже вы можете воспользоваться онлайн-калькулятором на нашем сайте или оставить заявку специалисту:\n📞 Телефон: **+998 94 000 99 77**";
      } else {
        text = "В **ECO JALUZI** мы производим жалюзи под индивидуальный размер и дизайн вашего помещения (гостиная, спальня, кухня, детская, офис).\n\nВсе наши ткани имеют пыле- и грязеотталкивающую пропитку. Предоставляется официальная гарантия 1 год.\n\nНапишите параметры вашего окна или пожелания по стилю, и мы подберем наилучшее решение!\n📞 Телефон для связи: **+998 94 000 99 77**";
      }
    } else if (lang === 'en') {
      if (lower.includes("hello") || lower.includes("hi") || lower.includes("hey") || lower.includes("good")) {
        text = "Hello and welcome to **ECO JALUZI**!\n\nHow can I help you today? We are a leading manufacturer of premium, custom-made window blinds, roller shades, and curtains.\n\nFeel free to ask about our models, materials, interior recommendations, or upload a photo of your window!\n\n📞 Phone: **+998 94 000 99 77**";
      } else if (lower.includes("create image") || lower.includes("generate") || lower.includes("design") || lower.includes("photo")) {
        text = "I will gladly create a realistic visual design for your window blinds! [GENERATE_IMAGE: modern luxury window blinds and roller shades in an elegant living room]";
      } else if (lower.includes("price") || lower.includes("cost") || lower.includes("calculate") || lower.includes("how much")) {
        text = "At **ECO JALUZI**, the exact price depends on your window dimensions, the chosen mechanism, and fabric grade.\n\nOur specialist visits your location with complete physical fabric swatches to take exact measurements and calculate the official quote.\n\nYou can also use the online Price Calculator on our website or contact us directly:\n📞 **+998 94 000 99 77**";
      } else {
        text = "Welcome to **ECO JALUZI**! We specialize in custom-crafted blinds including Combo Zebra, Dikey Vertical, Rollor Shades, Plisse, and Natural Wood/Bamboo blinds with a 1-year warranty.\n\nHow may we assist your interior project today? Contact: **+998 94 000 99 77**";
      }
    } else {
      if (lower.includes("salom") || lower.includes("assalom") || lower.includes("hayrli") || lower.includes("qalesiz") || lower.includes("yaxshimisiz") || lower === "salom" || lower === "hello") {
        text = "Vaalaykum assalom! **ECO JALUZI** kompaniyasining virtual AI maslahatchisiga xush kelibsiz!\n\nSizga qanday yordam bera olaman? Biz xonadoningiz va ofisingiz uchun zamonaviy, sifatli va ekologik toza barcha turdagi jaluzilarni to‘g‘ridan-to‘g‘ri fabrikamizda ishlab chiqaramiz.\n\nO‘zingizni qiziqtirgan savolni bering yoki derazangiz rasmini yuboring, eng mos modelni tanlashda yordam beraman!\n\n📞 Bog‘lanish: **+998 94 000 99 77**";
      } else if (lower.includes("rasm yarat") || lower.includes("rasmini yarat") || lower.includes("dizayn chiz") || lower.includes("surat yarat") || lower.includes("dizayn yarat") || lower.includes("rasm chiqar") || lower.includes("rasmini chiqar")) {
        text = "Albatta, siz uchun xonadoningizga mos zamonaviy va nafis jaluzi dizayni rasmini tayyorlayman! [GENERATE_IMAGE: modern luxury window blinds zebra combo and roller shades in an elegant living room]";
      } else if (lower.includes("qanday jaluzi") || lower.includes("qanaqa jaluzi") || lower.includes("turlari") || lower.includes("modellari") || lower.includes("katalog") || lower.includes("nimalar bor") || lower.includes("qanday turlari") || lower.includes("qanaqa bor")) {
        text = "**ECO JALUZI** quyidagi barcha asosiy va premium turdagi jaluzilarni taklif etadi:\n\n1. **Combo (Zebra jaluzi)** — shaffof va to‘q qatlamlarning almashinishi orqali yorug‘likni qulay sozlash imkonini beradi. Yotoqxona va mehmonxonalar uchun eng ommabop tanlov.\n2. **Dikey (Vertikal matoli jaluzi)** — katta va keng vitrina derazalar, mehmonxona va ofislar uchun juda nafis yechim. Matolari 180° buriladi.\n3. **Rollor (Rolikli parda)** — ixcham, amaliy, chang yutmaydigan maxsus antistatik matoli tizim.\n4. **Plisse jaluzi** — har qanday nostandart (arka, uchburchak, mansarda) derazalarga mukammal mos keladi.\n5. **Bambuk va Yog‘och jaluzi** — 100% tabiiy va ekologik toza material, interyerga tabiiy shinamlik baxsh etadi.\n6. **Alyumin va Rim pardalari** — mustahkamlik, namlikka chidamlilik va klassik ko‘rinish.\n\nSizga qaysi xonangiz uchun jaluzi kerak? Batafsil maslahat berishdan mamnunmiz!\n📞 Aloqa: **+998 94 000 99 77**";
      } else if (lower.includes("dikey") || lower.includes("vertikal")) {
        text = "**Dikey (Vertikal) jaluzilar** haqida to‘liq ma’lumot:\n\n- **Xususiyatlari:** Keng va baland derazalar, mehmonxona va zamonaviy ofislar uchun mukammal ko‘rinish beradi.\n- **Mato sifati:** Maxsus antistatik chang yutmaydigan matolardan tayyorlanadi, quyoshda o‘ngmaydi.\n- **Boshqaruv:** Lamellarni 180 gradusga burib, yorug‘lik tushish burchagini aniq sozlash mumkin.\n- **Kafolat:** Barcha mexanizmlarga 1 yil rasmiy kafolat beriladi.\n\nMutaxassisimiz katalog va mato namunalari bilan tashrif buyurishi uchun bog‘laning: **+998 94 000 99 77**";
      } else if (lower.includes("zebra") || lower.includes("combo")) {
        text = "**Combo (Zebra) jaluzilari** haqida to‘liq ma’lumot:\n\n- **Nega mashhur?** Kunduzi yumshoq yorug‘lik, kechasi esa to‘liq qorong‘ulik hosil qilish imkonini beruvchi ikki qavatli aqlli tizim.\n- **Xonalar:** Yotoqxona, zal, bolalar xonasi va oshxonalarga juda mos tushadi.\n- **Ranglar:** 100 dan ortiq rang va tekstura variantlari mavjud.\n- **Tozalash:** Maxsus chang o‘tkazmaydigan qoplamasi tufayli yuvish shart emas, quruq salfetka bilan artish yetarli.\n\nO‘lchov olish va buyurtma uchun: **+998 94 000 99 77**";
      } else if (lower.includes("narx") || lower.includes("narxi") || lower.includes("qancha") || lower.includes("necha pul") || lower.includes("o'lchov") || lower.includes("olchov") || lower.includes("buyurtma") || lower.includes("zakaz") || lower.includes("kafolat") || lower.includes("hisobla")) {
        text = "**ECO JALUZI** narxlari va buyurtma tartibi haqida:\n\n📌 **Narxlar qanday belgilanadi?**\nJaluzi narxi tanlangan model (Combo, Dikey, Rollor, Bambuk va boshqalar), matoning zichligi, toifasi hamda derazangizning aniq kvadrat metr (m²) o‘lchamiga qarab individual belgilanadi.\n\n🛠 **Aniq narxni bilish yo‘llari:**\n1. **Mutaxassis tashrifi:** Mutaxassisimiz barcha mato namunalari va to‘liq katalog bilan xonadoningizga boradi, aniq o‘lchov olib, yakuniy smetani hisoblab beradi.\n2. **Saytdagi Narx Kalkulyatori:** Saytimizning «Narx hisoblash» bo‘limida o‘lchamlarni kiritib, taxminiy narxni hisoblashingiz mumkin.\n3. **1 yil rasmiy kafolat:** Barcha mexanizm va matolarimizga 1 yil to‘liq kafolat beriladi.\n\nBuyurtma berish yoki mutaxassis chaqirish uchun qo‘ng‘iroq qiling: **+998 94 000 99 77**";
      } else if (lower.includes("oshxona") || lower.includes("kuxnya")) {
        text = "**Oshxona uchun eng mos jaluzilar:**\n\n1. **Rollor (Rolikli) parda** — namlik va bug‘ga chidamli, yuvish oson bo‘lgan maxsus matoli.\n2. **Alyumin jaluzi** — yog‘ va namlikdan qo‘rqmaydi, tozalash juda qulay.\n3. **Combo (Zebra)** — oson sozlanadi va zamonaviy ko‘rinish beradi.\n\nQo‘shimcha savollaringiz bo‘lsa, bemalol so‘rang! 📞 **+998 94 000 99 77**";
      } else if (lower.includes("yotoqxona") || lower.includes("spalni")) {
        text = "**Yotoqxona uchun tavsiya etiladigan modellar:**\n\n1. **Blackout Combo (Zebra)** — 100% yorug‘likni to‘suvchi va sifatli uyquni ta’minlovchi tizim.\n2. **Plisse pardalar** — derazaga nafis va sokin kayfiyat beradi.\n3. **Yog‘och / Bambuk jaluzi** — ekologik toza va xonaga shinam iliqlik bag‘ishlaydi.\n\nO‘lchov olish uchun: **+998 94 000 99 77**";
      } else {
        text = "Assalomu alaykum! **ECO JALUZI** kompaniyasida sizning didingiz va interyeringizga mos har qanday turdagi sifatli jaluzilar ishlab chiqariladi.\n\nSizga qaysi xona uchun jaluzi kerak yoki qaysi model qiziqtirayotganini yozsangiz, to‘liq tavsiya va ma'lumotlarni taqdim etamiz!\n\n📞 Telefon: **+998 94 000 99 77**\n🏢 Fabrikadan to‘g‘ridan-to‘g‘ri yetkazish va 1 yil kafolat.";
      }
    }

    return { statusCode: 200, headers, body: JSON.stringify({ text }) };
  } catch (error: any) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ text: "Assalomu alaykum! Men ECO JALUZI kompaniyasining virtual maslahatchisiman. Sizga qanday yordam bera olaman? Aloqa uchun: +998 94 000 99 77." })
    };
  }
};
