import { Order, AdminConfig } from '../types';
import { dbService } from './db';

export const telegramService = {
  /**
   * Sends a formatted order message to a Telegram chat/channel using the configured bot token
   */
  async sendOrder(order: Omit<Order, 'id' | 'status'>, config: AdminConfig): Promise<{ ok: boolean; error?: string }> {
    const token = config.telegramBotToken;
    let chatId = config.telegramChatId;

    if (!chatId && token) {
      try {
        const detected = await telegramService.detectChatId(token);
        if (detected && detected.id) {
          chatId = String(detected.id);
          const currentConfig = dbService.getAdminConfig();
          dbService.updateAdminConfig({ ...currentConfig, telegramChatId: chatId });
        }
      } catch (err) {
        console.warn('Auto-detecting chat ID failed:', err);
      }
    }

    if (!token || !chatId) {
      console.warn('Telegram integration is not fully configured (missing token or chat ID)');
      return { ok: false, error: 'Bot Token yoki Chat ID kiritilmagan' };
    }

    const messageText = `🔔 <b>YANGI BUYURTMA (ECO JALUZI)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Mijoz:</b> ${order.name}\n` +
      `📞 <b>Telefon:</b> <a href="tel:${order.phone}">${order.phone}</a>\n` +
      `🪟 <b>Jaluzi turi:</b> ${order.typeOfBlinds}\n` +
      `📐 <b>Derazalar soni:</b> ${order.numberOfWindows} ta\n` +
      `📍 <b>Manzil:</b> ${order.address}\n` +
      `💬 <b>Izoh:</b> ${order.comments || 'Yozilmadi'}\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🕒 <b>Sana:</b> ${order.date || new Date().toISOString().split('T')[0]}`;

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: messageText,
          parse_mode: 'HTML',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Telegram API error response:', errorData);
        return { ok: false, error: errorData.description || 'Xatolik yuz berdi' };
      }

      return { ok: true };
    } catch (err: any) {
      console.error('Failed to send order to Telegram:', err);
      return { ok: false, error: err.message || 'Tarmoq xatosi' };
    }
  },

  /**
   * Sends a consultation or callback request to Telegram
   */
  async sendConsultation(
    consult: { name: string; phone: string; type?: string; message?: string },
    config: AdminConfig
  ): Promise<{ ok: boolean; error?: string }> {
    const token = config.telegramBotToken;
    let chatId = config.telegramChatId;

    if (!chatId && token) {
      try {
        const detected = await telegramService.detectChatId(token);
        if (detected && detected.id) {
          chatId = String(detected.id);
          const currentConfig = dbService.getAdminConfig();
          dbService.updateAdminConfig({ ...currentConfig, telegramChatId: chatId });
        }
      } catch (err) {
        console.warn('Auto-detecting chat ID failed:', err);
      }
    }

    if (!token || !chatId) {
      return { ok: false, error: 'Bot Token yoki Chat ID kiritilmagan' };
    }

    const messageText = `📞 <b>YANGI MUROJAAT / KONSULTATSIYA (ECO JALUZI)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Mijoz:</b> ${consult.name}\n` +
      `📱 <b>Telefon:</b> <a href="tel:${consult.phone}">${consult.phone}</a>\n` +
      (consult.type ? `🪟 <b>Tanlangan tur:</b> ${consult.type}\n` : '') +
      (consult.message ? `💬 <b>Savol / Izoh:</b> ${consult.message}\n` : '') +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🕒 <b>Vaqt:</b> ${new Date().toLocaleString('uz-UZ')}`;

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: messageText,
          parse_mode: 'HTML',
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        return { ok: false, error: errData.description || 'Xatolik' };
      }

      return { ok: true };
    } catch (err: any) {
      return { ok: false, error: err.message };
    }
  },

  /**
   * Sends a test message to verify the bot token and chat ID
   */
  async sendTestMessage(token: string, chatId: string): Promise<{ ok: boolean; message?: string }> {
    if (!token || !chatId) {
      return { ok: false, message: 'Iltimos, Bot Token va Chat ID maydonlarini to‘ldiring!' };
    }

    const testText = `✅ <b>ECO JALUZI — Telegram Bot testi muvaffaqiyatli yakunlandi!</b>\n\n` +
      `Tabriklaymiz! Botingiz sayt bilan to‘liq bog‘landi. Saytdan qoldirilgan barcha buyurtmalar shu yerga kelib tushadi.\n` +
      `🕒 <b>Test vaqti:</b> ${new Date().toLocaleString('uz-UZ')}`;

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: testText,
          parse_mode: 'HTML',
        }),
      });

      const data = await response.json();
      if (response.ok && data.ok) {
        return { ok: true, message: 'Test xabari Telegramga muvaffaqiyatli yuborildi!' };
      } else {
        return { ok: false, message: data.description || 'Telegram xabar yuborishni rad etdi' };
      }
    } catch (err: any) {
      console.error('Failed to send test message to Telegram:', err);
      return { ok: false, message: err.message || 'Tarmoq ulanishida xatolik yuz berdi' };
    }
  },

  /**
   * Retrieves the latest updates from the bot to automatically detect Chat ID
   */
  async detectChatId(token: string): Promise<{ id: number; name: string; error?: string } | null> {
    if (!token) return null;
    try {
      let response = await fetch(`https://api.telegram.org/bot${token}/getUpdates?limit=10`);
      let data = await response.json();

      // If webhook is active, delete webhook first and retry
      if (!data.ok && data.description && data.description.toLowerCase().includes('webhook')) {
        try {
          await fetch(`https://api.telegram.org/bot${token}/deleteWebhook`);
          response = await fetch(`https://api.telegram.org/bot${token}/getUpdates?limit=10`);
          data = await response.json();
        } catch (we) {
          console.warn('Could not reset webhook:', we);
        }
      }

      if (data.ok && data.result && data.result.length > 0) {
        // Look from the most recent to the oldest
        for (let i = data.result.length - 1; i >= 0; i--) {
          const update = data.result[i];
          const message = update.message || update.edited_message || update.channel_post || update.my_chat_member;
          if (message && message.chat) {
            const chat = message.chat;
            const name = chat.title || [chat.first_name, chat.last_name].filter(Boolean).join(' ') || chat.username || 'Chat';
            return { id: chat.id, name };
          }
        }
      }
      return null;
    } catch (err) {
      console.error('Failed to detect Chat ID:', err);
      return null;
    }
  },

  /**
   * Checks if the app is currently running inside a Telegram Web App
   */
  getTelegramUser(): { id: number; username?: string; first_name?: string } | null {
    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg && tg.initDataUnsafe && tg.initDataUnsafe.user) {
        return tg.initDataUnsafe.user;
      }
    } catch (e) {
      console.error('Error reading Telegram Web App user data:', e);
    }
    return null;
  },

  /**
   * Sends a receipt confirmation message to the customer's personal Telegram chat
   */
  async sendCustomerConfirmation(userTelegramId: number, order: Omit<Order, 'id' | 'status'>, config: AdminConfig): Promise<boolean> {
    const token = config.customerBotToken || config.telegramBotToken;
    const targetChatId = config.customerChatId || userTelegramId;
    if (!token || !targetChatId) return false;

    const messageText = `🎉 <b>Sizning buyurtmangiz muvaffaqiyatli qabul qilindi!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `Hurmatli <b>${order.name}</b>, sizning mahsulotingiz muvaffaqiyatli o'tdi.\n\n` +
      `📐 <b>Buyurtma tafsilotlari:</b>\n` +
      `• Jaluzi turi: ${order.typeOfBlinds}\n` +
      `• Derazalar soni: ${order.numberOfWindows} ta\n` +
      `• Telefoningiz: ${order.phone}\n` +
      `• Manzilingiz: ${order.address}\n\n` +
      `📞 <b>Tez orada siz bilan bog'lanamiz!</b>\n` +
      `Kuningiz xayrli o'tsin!`;

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: targetChatId,
          text: messageText,
          parse_mode: 'HTML',
        }),
      });

      return response.ok;
    } catch (err) {
      console.error('Failed to send customer confirmation to Telegram:', err);
      return false;
    }
  }
};
