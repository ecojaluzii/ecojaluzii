export const ORNATISH_ABLOJKA = "https://storage.googleapis.com/genai-agent-assets/assets/1723222567823_ornatish_jarayoni_ablojka.jpg";
