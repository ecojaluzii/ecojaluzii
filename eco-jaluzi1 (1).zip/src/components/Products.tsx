import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { Product } from '../types';
import { Sparkles, ShoppingCart, Info, Eye } from 'lucide-react';

interface ProductsProps {
  onViewProduct: (product: Product) => void;
  onOrderProduct: (product: Product) => void;
}

export default function Products({ onViewProduct, onOrderProduct }: ProductsProps) {
  const [products, setProducts] = useState<Product[]>([]);

  const fetchProducts = () => {
    const list = dbService.getProducts();
    // Exclude p-1 (pool/water former combo) and plisse products from this specific section
    const filtered = list.filter(
      (p) => p.id !== 'p-1' && !p.name.toLowerCase().includes('plisse') && p.category !== 'Plisse jaluzi'
    );
    setProducts(filtered);
  };

  useEffect(() => {
    fetchProducts();
    window.addEventListener('cms_update', fetchProducts);
    return () => {
      window.removeEventListener('cms_update', fetchProducts);
    };
  }, []);

  return (
    <section id="products" className="py-20 bg-brand-cream border-b border-brand-emerald/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12">
        
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-16 flex flex-col items-center gap-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-emerald/10 text-brand-emerald text-xs font-bold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>PREMIUM KOLLEKSIYA</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brand-emerald-dark">
            Interyeringiz uchun mukammal tanlov.
          </h2>
          <div className="h-1 w-14 bg-brand-emerald rounded-full" />
          <p className="text-brand-charcoal/70 font-light max-w-2xl text-sm sm:text-base leading-relaxed">
            Har bir detalga e'tibor qaratilgan, eng so'nggi Yevropa dizayn tendensiyalari asosida yaratilgan jaluzilar kolleksiyasi.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              id={`product-card-${product.id}`}
              className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-brand-emerald/10 flex flex-col h-full"
            >
              {/* Image Section */}
              <div className="relative h-64 overflow-hidden bg-brand-charcoal/10">
                <img
                  src={product.image}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80";
                  }}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-100 contrast-100"
                />

                {/* Hover Quick Actions */}
                <div className="absolute inset-0 bg-brand-charcoal/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 z-20">
                  <button
                    onClick={() => onViewProduct(product)}
                    className="p-3 bg-brand-cream text-brand-emerald-dark rounded-full shadow-lg hover:scale-110 transition-transform hover:bg-brand-emerald hover:text-brand-cream"
                    title="Batafsil ko'rish"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => onOrderProduct(product)}
                    className="p-3 bg-brand-emerald text-brand-cream rounded-full shadow-lg hover:scale-110 transition-transform hover:bg-brand-emerald-dark"
                    title="Buyurtma berish"
                  >
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Content Section */}
              <div className="p-5 flex flex-col flex-grow justify-between">
                {/* CTAs */}
                <div className="flex items-center justify-between gap-3 pt-2">
                  <button
                    onClick={() => onViewProduct(product)}
                    className="flex-1 justify-center px-4 py-2.5 rounded-xl text-xs font-bold text-brand-emerald-dark bg-brand-emerald/10 hover:bg-brand-emerald/20 transition-colors flex items-center gap-1.5"
                  >
                    <Info className="w-4 h-4" />
                    <span>Tafsilot</span>
                  </button>

                  <button
                    onClick={() => onOrderProduct(product)}
                    className="flex-1 justify-center px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-brand-emerald-dark hover:bg-brand-emerald transition-colors flex items-center gap-1.5 shadow-sm"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>Buyurtma</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
