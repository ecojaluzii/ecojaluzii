import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { Phone, Send, Instagram, Facebook, Menu, X, ArrowUpRight } from 'lucide-react';
import { dbService } from '../services/db';

interface NavbarProps {
  onOrderClick: () => void;
  onAdminClick: () => void;
  isAdmin: boolean;
}

export default function Navbar({ onOrderClick, onAdminClick, isAdmin }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [adminConfig, setAdminConfig] = useState(dbService.getAdminConfig());
  const [currentLang, setCurrentLang] = useState('uz');

  useEffect(() => {
    // Check initial language from cookie
    const match = document.cookie.match(/googtrans=\/uz\/([a-z]{2})/);
    if (match && match[1]) {
      setCurrentLang(match[1]);
    }
    
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    const handleConfigUpdate = () => {
      setAdminConfig(dbService.getAdminConfig());
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('cms_update', handleConfigUpdate);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('cms_update', handleConfigUpdate);
    };
  }, []);

  const navLinks = [
    { name: 'Bosh sahifa', href: '#home' },
    { name: 'Katalog (Mahsulotlar)', href: '#products', action: 'open_products_catalog' },
    { name: 'Qilingan ishlar', href: '#products', action: 'open_portfolio_gallery' },
    { name: 'Otzivlar', href: '#customer-reviews' },
    { name: 'AI Chat', href: '#ai-assistant' },
    { name: 'Nega biz?', href: '#why-us' },
    { name: 'Jarayon', href: '#process' },
  ];

  const handleLinkClick = (href: string, action?: string) => {
    setIsMobileMenuOpen(false);
    if (href === '#ai-assistant') {
      window.dispatchEvent(new CustomEvent('open_ai_chat'));
    }
    if (action) {
      window.dispatchEvent(new CustomEvent(action));
    }
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const changeLang = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const lang = e.target.value;
    setCurrentLang(lang);
    const select = document.querySelector('.goog-te-combo') as HTMLSelectElement;
    if (select) {
      select.value = lang;
      select.dispatchEvent(new Event('change'));
    }
  };

  return (
    <>
      <header
        id="navbar-header"
        className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-7xl transition-all duration-300 rounded-2xl ${
          isScrolled
            ? 'glass shadow-lg border border-brand-emerald/10 py-3 px-6'
            : 'bg-transparent py-5 px-4'
        }`}
      >
        <div className="flex items-center justify-between">
          {/* Logo link */}
          <a href="#home" onClick={(e) => { e.preventDefault(); handleLinkClick('#home'); }} className="flex-shrink-0">
            <Logo size="md" />
          </a>

          {/* Desktop Navigation links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => { e.preventDefault(); handleLinkClick(link.href, link.action); }}
                className="text-sm font-medium text-brand-emerald-dark/80 hover:text-brand-emerald hover:scale-105 transition-all duration-200"
              >
                {link.name}
              </a>
            ))}
            
            {/* Direct access to admin panel inside the navigation for the owner */}
            <button
              onClick={onAdminClick}
              className={`text-xs font-semibold px-2.5 py-1 rounded-full border transition-all duration-200 ${
                isAdmin
                  ? 'bg-brand-emerald text-brand-cream border-brand-emerald'
                  : 'text-brand-emerald/70 border-brand-emerald/20 hover:border-brand-emerald hover:text-brand-emerald'
              }`}
            >
              {isAdmin ? 'Admin Panel Active' : 'Owner CMS'}
            </button>
          </nav>

          {/* Right Action panel */}
          <div className="hidden lg:flex items-center gap-4">
            {/* Language Switcher */}
            <select
              value={currentLang}
              onChange={changeLang}
              className="bg-transparent text-sm font-semibold text-brand-emerald-dark cursor-pointer outline-none border border-brand-emerald/20 rounded-md px-1 py-0.5 hover:bg-brand-emerald/5 transition-colors"
            >
              <option value="uz">UZB</option>
              <option value="ru">RU</option>
              <option value="en">EN</option>
            </select>

            {/* Phone and Social icons */}
            <div className="flex flex-col items-center gap-1.5">
              <a
                href={`tel:${adminConfig.phoneNumber}`}
                className="flex items-center justify-center w-full gap-1.5 text-xs font-semibold text-brand-emerald-dark hover:text-brand-emerald transition-colors px-3 py-1 rounded-md bg-brand-emerald/5 border border-brand-emerald/10"
              >
                <Phone className="w-3.5 h-3.5" />
                <span className="whitespace-nowrap tracking-wide">{adminConfig.phoneNumber}</span>
              </a>
              <div className="flex items-center justify-between w-full px-1">
                <a
                  href={adminConfig.telegramLink}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1 rounded-full hover:bg-brand-emerald/10 text-brand-emerald transition-colors"
                  title="Telegram"
                >
                  <Send className="w-4 h-4" />
                </a>
                <a
                  href={adminConfig.instagramLink}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1 rounded-full hover:bg-brand-emerald/10 text-brand-emerald transition-colors"
                  title="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href={adminConfig.facebookLink}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1 rounded-full hover:bg-brand-emerald/10 text-brand-emerald transition-colors"
                  title="Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Order Action Button */}
            <button
              id="nav-order-button"
              onClick={onOrderClick}
              className="shimmer bg-brand-emerald text-brand-cream hover:bg-brand-emerald-dark px-5 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all duration-300 shadow-md flex items-center gap-1.5 hover:scale-[1.03]"
            >
              <span>Buyurtma Berish</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile controls */}
          <div className="flex items-center gap-2 lg:hidden">
            {/* Language Switcher */}
            <select
              value={currentLang}
              onChange={changeLang}
              className="bg-transparent text-sm font-semibold text-brand-emerald-dark cursor-pointer outline-none border border-brand-emerald/20 rounded-md px-1 py-1 hover:bg-brand-emerald/5 transition-colors"
            >
              <option value="uz">UZB</option>
              <option value="ru">RU</option>
              <option value="en">EN</option>
            </select>

            {/* Quick call button */}
            <a
              href={`tel:${adminConfig.phoneNumber}`}
              className="p-2.5 rounded-xl bg-brand-emerald/10 text-brand-emerald hover:bg-brand-emerald/20 transition-all"
              title="Call Now"
            >
              <Phone className="w-4 h-4" />
            </a>

            {/* Hamburger menu */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2.5 rounded-xl bg-brand-emerald/5 text-brand-emerald-dark transition-all hover:bg-brand-emerald/10"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer menu */}
      <div
        className={`fixed inset-0 z-40 bg-brand-charcoal/40 backdrop-blur-sm lg:hidden transition-opacity duration-300 ${
          isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsMobileMenuOpen(false)}
      >
        <div
          className={`absolute top-0 right-0 h-full w-[80%] max-w-sm bg-brand-cream p-6 shadow-2xl transition-transform duration-300 ${
            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between border-b border-brand-emerald/10 pb-4 mb-6">
            <Logo size="sm" />
            <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2 rounded-lg hover:bg-brand-emerald/5 text-brand-emerald-dark"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="flex flex-col gap-4 mb-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => { e.preventDefault(); handleLinkClick(link.href, link.action); }}
                className="text-base font-medium text-brand-emerald-dark/80 hover:text-brand-emerald border-b border-brand-emerald/5 pb-2 hover:pl-2 transition-all"
              >
                {link.name}
              </a>
            ))}
            
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onAdminClick();
              }}
              className="text-left text-sm font-semibold text-brand-emerald/80 hover:text-brand-emerald border-b border-brand-emerald/5 pb-2 hover:pl-2 transition-all"
            >
              ⚙️ {isAdmin ? 'Admin Panel Active' : 'Owner CMS Panel'}
            </button>
          </nav>

          <div className="flex flex-col gap-5">
            {/* Direct quick contact links */}
            <div className="flex items-center gap-3">
              <a
                href={adminConfig.telegramLink}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center w-10 h-10 rounded-xl bg-brand-emerald/10 text-brand-emerald hover:bg-brand-emerald/20 transition-all"
              >
                <Send className="w-5 h-5" />
              </a>
              <a
                href={adminConfig.instagramLink}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center w-10 h-10 rounded-xl bg-brand-emerald/10 text-brand-emerald hover:bg-brand-emerald/20 transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <div className="text-xs text-brand-emerald-dark/60">
                Bizni ijtimoiy tarmoqlarda kuzating
              </div>
            </div>

            <a
              href={`tel:${adminConfig.phoneNumber}`}
              className="flex items-center justify-center gap-3 w-full py-3 rounded-xl bg-brand-beige border border-brand-emerald/20 text-brand-emerald-dark font-semibold text-sm hover:bg-brand-emerald/5 transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>{adminConfig.phoneNumber}</span>
            </a>

            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOrderClick();
              }}
              className="w-full py-3 rounded-xl bg-brand-emerald text-brand-cream hover:bg-brand-emerald-dark font-semibold text-sm tracking-wide uppercase transition-all shadow-md hover:shadow-lg"
            >
              Õlcham olishga buyurtma berish
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
