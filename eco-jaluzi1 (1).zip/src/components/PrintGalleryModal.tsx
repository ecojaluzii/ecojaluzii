import React, { useState, useEffect } from 'react';
import { PortfolioProject } from '../types';
import { PRINT_GALLERY_PROJECTS, PrintProjectItem } from '../data/printGallery';
import {
  X, Camera, ChevronLeft, ChevronRight, ShoppingCart,
  Maximize2, Sparkles, CheckCircle2, Phone, ShieldCheck,
  Search, Filter, Eye, ZoomIn, ZoomOut, RotateCcw,
  Palette, Send, ArrowUpRight
} from 'lucide-react';

interface PrintGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderProject: (project: PortfolioProject) => void;
}

export default function PrintGalleryModal({
  isOpen,
  onClose,
  onOrderProject,
}: PrintGalleryModalProps) {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Lock body scroll when modal or lightbox is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Reset zoom level whenever lightbox photo changes
  useEffect(() => {
    setZoomLevel(1);
  }, [lightboxIndex]);

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') setLightboxIndex(null);
      if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : PRINT_GALLERY_PROJECTS.length - 1));
      }
      if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev !== null && prev < PRINT_GALLERY_PROJECTS.length - 1 ? prev + 1 : 0));
      }
      if (e.key === '+' || e.key === '=') {
        setZoomLevel((z) => Math.min(z + 0.5, 3));
      }
      if (e.key === '-') {
        setZoomLevel((z) => Math.max(z - 0.5, 1));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex]);

  if (!isOpen) return null;

  // Filter projects by search
  const filteredProjects = PRINT_GALLERY_PROJECTS.filter((proj) => {
    if (!searchQuery.trim()) return true;
    return (
      proj.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (proj.roomType && proj.roomType.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (proj.printTheme && proj.printTheme.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-brand-cream overflow-y-auto animate-fadeIn flex flex-col">
      {/* Sticky Top Header */}
      <div className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur-md border-b border-brand-emerald/10 px-4 sm:px-8 py-3.5 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white flex items-center justify-center shadow-md flex-shrink-0">
              <span className="text-xl sm:text-2xl">🎨</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-purple-500 to-pink-500 text-white text-[10px] font-extrabold uppercase tracking-wider shadow-sm">
                  Print (Foto) Jaluzilar Galereyasi
                </span>
                <span className="text-xs text-brand-emerald font-bold hidden sm:inline-block">
                  • {PRINT_GALLERY_PROJECTS.length} ta eksklyuziv real montaj
                </span>
              </div>
              <h2 className="font-serif text-base sm:text-xl md:text-2xl font-bold text-brand-emerald-dark leading-tight line-clamp-1">
                Print va Foto Jaluzilar — Real Qilingan Ishlar
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={onClose}
              className="px-3.5 sm:px-4 py-2 rounded-xl bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark border border-brand-emerald/15 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs hover:scale-105"
            >
              <span>Ortga / Yopish</span>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 py-6 sm:py-8 flex-grow w-full space-y-6 sm:space-y-8">
        
        {/* Top Info & Trust Banner */}
        <div className="bg-gradient-to-br from-purple-950 via-slate-900 to-indigo-950 rounded-3xl p-5 sm:p-7 text-white border border-purple-500/20 shadow-xl space-y-4">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-500/30">
                <Palette className="w-3.5 h-3.5 text-purple-400" />
                <span>7-O‘rindagi Maxsus Mahsulot: UV-Print Foto Jaluzilar</span>
              </div>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-white">
                Istalgan Foto, Rasm yoki Logo Bosilgan Zamonaviy Jaluzilar
              </h3>
              <p className="text-xs sm:text-sm text-purple-200/80 font-light max-w-2xl leading-relaxed">
                Bolalar xonalari, oshxona, restoran, ofis va yotoqxona derazalari uchun quyoshda so‘nmaydigan ekologik toza UV-bo‘yoqlarda chop etilgan eng sifatli foto jaluzi ishlarimiz.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>3 Yil Kafolat</span>
              </div>
              <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 text-xs">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Ultra HD / 4K Chop</span>
              </div>
            </div>
          </div>

          {/* Search bar inside banner */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-grow">
              <Search className="w-4 h-4 text-white/50 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Mavzu bo‘yicha qidirish (masalan: Oshxona, Meva, Manzara, Bolalar...)"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/10 border border-white/15 text-white placeholder-white/50 text-xs sm:text-sm focus:outline-none focus:border-purple-400 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white text-xs"
                >
                  Tozalash
                </button>
              )}
            </div>

            <span className="text-xs text-purple-200/70 font-medium self-center sm:self-auto flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5" />
              <span>{filteredProjects.length} ta montaj ko‘rsatilmoqda</span>
            </span>
          </div>
        </div>

        {/* Gallery Grid */}
        {filteredProjects.length === 0 ? (
          <div className="text-center py-16 bg-brand-beige/50 rounded-3xl border border-brand-emerald/10 p-8 space-y-3">
            <p className="text-brand-charcoal/70 text-sm font-medium">
              «{searchQuery}» so‘rovi bo‘yicha montajlar topilmadi.
            </p>
            <button
              onClick={() => setSearchQuery('')}
              className="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold"
            >
              Barcha suratlarni ko‘rsatish
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
            {filteredProjects.map((project, idx) => (
              <div
                key={project.id}
                onClick={() => setLightboxIndex(idx)}
                className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-brand-emerald/15 flex flex-col aspect-[4/5] hover:-translate-y-1 cursor-pointer"
              >
                {/* Image */}
                <img
                  src={project.image}
                  alt={project.title}
                  loading="eager"
                  decoding="async"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80";
                  }}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 contrast-[1.03] saturate-[1.03]"
                />

                {/* Ambient dark gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

                {/* Top Badges */}
                <div className="absolute top-2.5 sm:top-3 left-2.5 sm:left-3 right-2.5 sm:right-3 flex items-center justify-between pointer-events-none z-10">
                  <span className="px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md text-white text-[10px] sm:text-xs font-bold shadow-md border border-white/10 flex items-center gap-1">
                    <Palette className="w-3 h-3 text-purple-400" />
                    <span>Print #{idx + 1}</span>
                  </span>
                  {project.roomType && (
                    <span className="px-2 py-0.5 rounded-md bg-purple-500/80 backdrop-blur-md text-white text-[9px] font-semibold">
                      {project.roomType}
                    </span>
                  )}
                </div>

                {/* Bottom Info Overlay */}
                <div className="absolute bottom-0 inset-x-0 p-3 sm:p-4 z-10 space-y-1 text-white">
                  <h4 className="font-serif text-xs sm:text-sm font-bold text-white line-clamp-2 leading-snug group-hover:text-purple-300 transition-colors">
                    {project.title}
                  </h4>
                  {project.printTheme && (
                    <p className="text-[10px] text-purple-200/90 font-medium line-clamp-1">
                      Mavzu: {project.printTheme}
                    </p>
                  )}
                  <div className="pt-1 flex items-center justify-between text-[10px] text-white/70">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-purple-400" />
                      <span>Kattalashtirish</span>
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOrderProject(project);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold flex items-center gap-1 transition-all active:scale-95"
                    >
                      <ShoppingCart className="w-3 h-3" />
                      <span>Buyurtma</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox / Fullscreen Modal */}
      {lightboxIndex !== null && filteredProjects[lightboxIndex] && (
        <div 
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between p-3 sm:p-6 animate-fadeIn"
          onClick={() => setLightboxIndex(null)}
        >
          {/* Lightbox Header Bar */}
          <div 
            className="flex items-center justify-between text-white z-20 max-w-7xl mx-auto w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-xl bg-purple-600 text-white font-bold text-xs">
                {lightboxIndex + 1} / {filteredProjects.length}
              </span>
              <div>
                <h3 className="font-serif text-xs sm:text-base font-bold text-white line-clamp-1">
                  {filteredProjects[lightboxIndex].title}
                </h3>
                <p className="text-[10px] sm:text-xs text-purple-300">
                  {filteredProjects[lightboxIndex].printTheme} • {filteredProjects[lightboxIndex].roomType}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Zoom In/Out controls */}
              <button
                type="button"
                onClick={() => setZoomLevel((z) => Math.min(z + 0.5, 3))}
                className="p-2 sm:p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
                title="Kattalashtirish (+)"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setZoomLevel((z) => Math.max(z - 0.5, 1))}
                className="p-2 sm:p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
                title="Kichraytirish (-)"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              {zoomLevel > 1 && (
                <button
                  type="button"
                  onClick={() => setZoomLevel(1)}
                  className="p-2 sm:p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors text-xs font-bold"
                  title="Asliga qaytarish"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}

              {/* Order this project button */}
              <button
                type="button"
                onClick={() => {
                  const chosen = filteredProjects[lightboxIndex];
                  setLightboxIndex(null);
                  onOrderProject(chosen);
                }}
                className="px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg transition-transform active:scale-95"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Shu modelga buyurtma</span>
              </button>

              {/* Close Button */}
              <button
                type="button"
                onClick={() => setLightboxIndex(null)}
                className="p-2 sm:p-2.5 rounded-xl bg-white/15 hover:bg-rose-600 text-white transition-colors"
                title="Yopish (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Lightbox Center Image Container */}
          <div 
            className="relative flex items-center justify-center flex-grow my-2 overflow-hidden select-none"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Prev Button */}
            <button
              type="button"
              onClick={() =>
                setLightboxIndex((lightboxIndex - 1 + filteredProjects.length) % filteredProjects.length)
              }
              className="fixed left-2 sm:left-6 z-30 p-3 sm:p-4 rounded-full bg-black/70 hover:bg-purple-600 hover:text-white text-white backdrop-blur-md transition-all border border-white/20 hover:scale-110 shadow-2xl cursor-pointer"
              aria-label="Oldingi rasm"
            >
              <ChevronLeft className="w-6 h-6 sm:w-8 sm:h-8" />
            </button>

            {/* Scaled Image */}
            <div 
              className="transition-transform duration-200 cursor-zoom-in flex items-center justify-center"
              onClick={() => setZoomLevel((z) => (z > 1 ? 1 : 1.75))}
              style={{ 
                transform: `scale(${zoomLevel})`,
                transformOrigin: 'center center',
              }}
            >
              <img
                src={filteredProjects[lightboxIndex].image}
                alt={filteredProjects[lightboxIndex].title}
                loading="eager"
                decoding="sync"
                referrerPolicy="no-referrer"
                className="max-h-[72vh] sm:max-h-[76vh] max-w-[92vw] object-contain rounded-2xl shadow-2xl contrast-[1.04] saturate-[1.03]"
              />
            </div>

            {/* Next Button */}
            <button
              type="button"
              onClick={() =>
                setLightboxIndex((lightboxIndex + 1) % filteredProjects.length)
              }
              className="fixed right-2 sm:right-6 z-30 p-3 sm:p-4 rounded-full bg-black/70 hover:bg-purple-600 hover:text-white text-white backdrop-blur-md transition-all border border-white/20 hover:scale-110 shadow-2xl cursor-pointer"
              aria-label="Keyingi rasm"
            >
              <ChevronRight className="w-6 h-6 sm:w-8 sm:h-8" />
            </button>
          </div>

          {/* Lightbox Bottom Info & Thumbnails */}
          <div className="text-center text-white space-y-2 max-w-4xl mx-auto w-full z-20">
            <div>
              <h3 className="font-serif text-sm sm:text-base font-bold text-purple-300">
                Print (Foto) Jaluzi Loyihasi #{lightboxIndex + 1}
              </h3>
              <p className="text-[11px] sm:text-xs text-purple-200/90 font-medium">
                Rasmni bosib 175% kattalashtirib tafsilotlarni ko‘ring
              </p>
            </div>

            {/* Thumbnail Strip */}
            <div className="flex items-center justify-center gap-1.5 sm:gap-2 overflow-x-auto py-1 scrollbar-none max-w-full">
              {filteredProjects.map((proj, idx) => (
                <button
                  key={proj.id}
                  type="button"
                  onClick={() => setLightboxIndex(idx)}
                  className={`w-11 h-11 sm:w-14 sm:h-14 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all cursor-pointer ${
                    lightboxIndex === idx
                      ? 'border-purple-400 scale-110 shadow-lg'
                      : 'border-white/30 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={proj.image}
                    alt={proj.title}
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover contrast-[1.03]"
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
