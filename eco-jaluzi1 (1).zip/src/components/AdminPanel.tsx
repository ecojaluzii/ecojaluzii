import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { telegramService } from '../services/telegram';
import { compressImage } from '../services/imageCompressor';
import { Product, PortfolioProject, ProcessStep, Order, ConsultationRequest, AdminConfig } from '../types';
import {
  Settings, ShoppingBag, FolderOpen, Mail, ClipboardList,
  Plus, Trash2, Check, CheckCircle2, UserCheck, PhoneCall,
  Save, X, Globe, DollarSign, Layout, Pencil, ChevronRight, Eye, Menu,
  Search, Send, Upload, RefreshCw, AlertCircle, ExternalLink, Image as ImageIcon
} from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
}

const PORTFOLIO_CATEGORIES = [
  'Dikey pardalar',
  'Combo jaluzi',
  'Plisse jaluzi',
  'Roller jaluzi',
  'Wood (Yog‘och) jaluzi',
  'Bambuk jaluzi',
  'Alyumin gorizontal',
  'Honeycomb jaluzi',
  'Rim pardalari',
  'Boshqa'
];

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'orders' | 'consultations' | 'products' | 'portfolio' | 'settings'>('orders');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Database States
  const [products, setProducts] = useState<Product[]>([]);
  const [projects, setProjects] = useState<PortfolioProject[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [consultations, setConsultations] = useState<ConsultationRequest[]>([]);
  const [config, setConfig] = useState<AdminConfig>(dbService.getAdminConfig());
  const [visitCount, setVisitCount] = useState<number>(0);

  // Form Editing States
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [editingProject, setEditingProject] = useState<Partial<PortfolioProject> | null>(null);
  const [editingProcessStep, setEditingProcessStep] = useState<Partial<ProcessStep> | null>(null);

  // Category filter and search states
  const [adminProjectCategoryFilter, setAdminProjectCategoryFilter] = useState<string>('Barchasi');
  const [adminProjectSearch, setAdminProjectSearch] = useState<string>('');
  const [adminProductCategoryFilter, setAdminProductCategoryFilter] = useState<string>('Barchasi');

  // Media processing & Feedback States
  const [isCompressingImage, setIsCompressingImage] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);

  // Manual Order Creation Modal State
  const [showNewOrderModal, setShowNewOrderModal] = useState<boolean>(false);
  const [newOrderData, setNewOrderData] = useState<Partial<Order>>({
    name: '',
    phone: '',
    typeOfBlinds: 'Dikey pardalar',
    numberOfWindows: 1,
    address: '',
    comments: ''
  });

  // Telegram Connection Test State
  const [testStatus, setTestStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [testResultMsg, setTestResultMsg] = useState<string | null>(null);
  const [sampleOrderStatus, setSampleOrderStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [sendingOrderId, setSendingOrderId] = useState<string | null>(null);

  // Telegram Auto-Detect Chat ID State
  const [detectStatus, setDetectStatus] = useState<'idle' | 'loading' | 'success' | 'error' | 'not_found'>('idle');
  const [detectedUser, setDetectedUser] = useState<string>('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleDetectChatId = async () => {
    if (!config.telegramBotToken) {
      alert("Iltimos, avval Telegram Bot Token-ni kiriting!");
      return;
    }
    setDetectStatus('loading');
    setDetectedUser('');
    const result = await telegramService.detectChatId(config.telegramBotToken);
    if (result) {
      setConfig(prev => ({ ...prev, telegramChatId: String(result.id) }));
      setDetectedUser(result.name);
      setDetectStatus('success');
      showToast(`Chat ID aniqlandi: ${result.id} (${result.name})`);
      setTimeout(() => setDetectStatus('idle'), 6000);
    } else {
      setDetectStatus('not_found');
      setTimeout(() => setDetectStatus('idle'), 6000);
    }
  };

  const handleTestTelegram = async () => {
    if (!config.telegramBotToken || !config.telegramChatId) {
      alert("Iltimos, Bot Token va Chat ID maydonlarini to'ldiring!");
      return;
    }
    setTestStatus('loading');
    setTestResultMsg(null);
    const result = await telegramService.sendTestMessage(config.telegramBotToken, config.telegramChatId);
    if (result.ok) {
      setTestStatus('success');
      setTestResultMsg(result.message || 'Xabar muvaffaqiyatli ketdi!');
      showToast('Telegram test xabari muvaffaqiyatli yuborildi!');
      setTimeout(() => setTestStatus('idle'), 5000);
    } else {
      setTestStatus('error');
      setTestResultMsg(result.message || 'Telegram xatosi');
      setTimeout(() => setTestStatus('idle'), 7000);
    }
  };

  const handleSendSampleOrder = async () => {
    if (!config.telegramBotToken || !config.telegramChatId) {
      alert("Iltimos, avval Bot Token va Chat ID maydonlarini to'ldiring!");
      return;
    }
    setSampleOrderStatus('loading');
    const result = await telegramService.sendOrder({
      name: 'Sinov Xaridori (Test)',
      phone: '+998 90 123 45 67',
      typeOfBlinds: 'Combo jaluzi',
      numberOfWindows: 2,
      address: 'Toshkent sh., Yunusobod 4-mavze',
      comments: 'Telegram bot to‘g‘ri ishlayotganini sinash uchun namunaviy buyurtma.',
      date: new Date().toISOString().split('T')[0]
    }, config);

    if (result.ok) {
      setSampleOrderStatus('success');
      showToast('Namuna buyurtma Telegramga muvaffaqiyatli yuborildi!');
      setTimeout(() => setSampleOrderStatus('idle'), 5000);
    } else {
      setSampleOrderStatus('error');
      alert(`Telegramga yuborishda xatolik: ${result.error || 'Xatolik yuz berdi'}`);
      setTimeout(() => setSampleOrderStatus('idle'), 4000);
    }
  };

  const handleSendExistingOrderToTelegram = async (ord: Order) => {
    if (!config.telegramBotToken || !config.telegramChatId) {
      alert("Iltimos, avval Sozlamalar bo‘limida Bot Token va Chat ID ni kiriting!");
      return;
    }
    setSendingOrderId(ord.id);
    const result = await telegramService.sendOrder(ord, config);
    setSendingOrderId(null);
    if (result.ok) {
      showToast(`Buyurtma (#${ord.id}) Telegramga qayta yuborildi!`);
    } else {
      alert(`Telegramga yuborishda xatolik: ${result.error || 'Xatolik yuz berdi'}`);
    }
  };

  const reloadData = () => {
    setProducts(dbService.getProducts());
    setProjects(dbService.getProjects());
    setOrders(dbService.getOrders());
    setConsultations(dbService.getConsultations());
    setConfig(dbService.getAdminConfig());
    setVisitCount(dbService.getVisitCount());
  };

  useEffect(() => {
    reloadData();
    // Re-load on local updates
    window.addEventListener('cms_update', reloadData);
    return () => {
      window.removeEventListener('cms_update', reloadData);
    };
  }, []);

  // Products CRUD
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name || !editingProduct?.category || !editingProduct?.pricePerSqm) return;

    dbService.saveProduct({
      name: editingProduct.name,
      category: editingProduct.category,
      pricePerSqm: Number(editingProduct.pricePerSqm),
      description: editingProduct.description || '',
      material: editingProduct.material || 'Standard material',
      availableColors: editingProduct.availableColors || ['Krem', 'Oq', 'Bej'],
      image: editingProduct.image || 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
      videoUrl: editingProduct.videoUrl || '',
      mediaType: editingProduct.mediaType || 'image',
      id: editingProduct.id
    });

    setEditingProduct(null);
    showToast('Mahsulot muvaffaqiyatli saqlandi!');
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Haqiqatdan ham ushbu mahsulotni o‘chirmoqchimisiz?')) {
      dbService.deleteProduct(id);
      showToast('Mahsulot o‘chirildi!');
    }
  };

  // Projects CRUD
  const handleSaveProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject?.title || !editingProject?.category) {
      alert("Iltimos, loyiha sarlavhasi va kategoriyasini kiriting!");
      return;
    }

    if (!editingProject.image && !editingProject.videoUrl) {
      alert("Iltimos, loyiha uchun rasm yuklang yoki rasm havolasini kiriting!");
      return;
    }

    dbService.saveProject({
      title: editingProject.title.trim(),
      category: editingProject.category,
      description: editingProject.description || '',
      image: editingProject.image || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
      videoUrl: editingProject.videoUrl || '',
      mediaType: editingProject.mediaType || (editingProject.videoUrl ? 'video' : 'image'),
      id: editingProject.id
    });

    setEditingProject(null);
    showToast(editingProject.id ? 'Portfolio loyihasi yangilandi!' : 'Yangi loyiha muvaffaqiyatli qo‘shildi!');
  };

  const handleDeleteProject = (id: string, title?: string) => {
    if (window.confirm(`"${title || 'Ushbu loyiha'}"ni haqiqatdan ham portfolio ro‘yxatidan o‘chirmoqchimisiz?`)) {
      dbService.deleteProject(id);
      showToast('Loyiha portfoliodan o‘chirildi!');
    }
  };

  // Universal Media File Handlers with auto-compression
  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>, target: 'product' | 'project') => {
    const file = e.target.files?.[0];
    if (file) {
      setIsCompressingImage(true);
      try {
        const compressedBase64 = await compressImage(file, 1280, 0.82);
        if (target === 'product') {
          setEditingProduct(prev => prev ? { ...prev, image: compressedBase64 } : null);
        } else if (target === 'project') {
          setEditingProject(prev => prev ? { ...prev, image: compressedBase64 } : null);
        }
        showToast('Rasm muvaffaqiyatli yuklandi va optimallashtirildi!');
      } catch (err) {
        console.error("Image processing error:", err);
        alert("Rasmni qayta ishlashda xatolik yuz berdi. Iltimos, boshqa rasm tanlab ko'ring.");
      } finally {
        setIsCompressingImage(false);
      }
    }
  };

  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>, target: 'product' | 'project') => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 25 * 1024 * 1024) {
        alert("Video fayl hajmi 25MB dan oshmasligi kerak!");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        if (target === 'product') {
          setEditingProduct(prev => prev ? { ...prev, videoUrl: base64String, mediaType: 'video' } : null);
        } else if (target === 'project') {
          setEditingProject(prev => prev ? { ...prev, videoUrl: base64String, mediaType: 'video' } : null);
        }
        showToast('Video biriktirildi!');
      };
      reader.readAsDataURL(file);
    }
  };

  // Manual Order Creation Handler
  const handleCreateManualOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrderData.name || !newOrderData.phone) {
      alert("Mijoz ismi va telefon raqamini kiritish shart!");
      return;
    }

    const payload = {
      name: newOrderData.name.trim(),
      phone: newOrderData.phone.trim(),
      typeOfBlinds: newOrderData.typeOfBlinds || 'Dikey pardalar',
      numberOfWindows: Number(newOrderData.numberOfWindows) || 1,
      address: newOrderData.address || 'Kiritilmadi',
      comments: newOrderData.comments || 'Admin paneldan kiritilgan',
      date: new Date().toISOString().split('T')[0]
    };

    const savedOrder = dbService.addOrder(payload);
    setShowNewOrderModal(false);
    setNewOrderData({
      name: '',
      phone: '',
      typeOfBlinds: 'Dikey pardalar',
      numberOfWindows: 1,
      address: '',
      comments: ''
    });

    showToast('Yangi buyurtma ro‘yxatga qo‘shildi!');

    // Optionally forward to Telegram
    if (config.telegramBotToken && config.telegramChatId) {
      telegramService.sendOrder(savedOrder, config);
    }
  };

  // Config Update
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    dbService.updateAdminConfig(config);
    showToast('Barcha sozlamalar muvaffaqiyatli saqlandi!');
  };

  // Quick helper to change status of Order or Consult
  const handleUpdateOrderStatus = (id: string, status: Order['status']) => {
    dbService.updateOrderStatus(id, status);
  };

  const handleUpdateConsultStatus = (id: string, status: ConsultationRequest['status']) => {
    dbService.updateConsultationStatus(id, status);
  };

  const handleDeleteOrder = (id: string) => {
    if (window.confirm('Buyurtmani o‘chirishni xohlaysizmi?')) {
      dbService.deleteOrder(id);
    }
  };

  const handleDeleteConsult = (id: string) => {
    if (window.confirm('Arizani o‘chirishni xohlaysizmi?')) {
      dbService.deleteConsultation(id);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', { style: 'currency', currency: 'UZS', maximumFractionDigits: 0 }).format(price);
  };

  return (
    <div className="fixed inset-0 z-50 bg-brand-charcoal/40 backdrop-blur-md flex items-center justify-center md:p-6 p-0 select-none">
      
      {/* Absolute closer backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Central Board Area */}
      <div className="relative bg-brand-cream w-full max-w-6xl rounded-none md:rounded-3xl overflow-hidden shadow-2xl border-0 md:border border-brand-emerald/10 z-10 flex flex-col h-full md:h-[90vh]">
        
        {/* Header Block */}
        <div className="bg-brand-emerald p-4 sm:p-6 text-brand-cream flex items-center justify-between border-b border-brand-emerald-dark shrink-0">
          <div className="flex items-center gap-3">
            {/* Hamburger button on mobile */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-brand-cream flex items-center justify-center"
              title="Menyu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="p-2.5 rounded-xl bg-white/10 text-amber-200 hidden sm:block">
              <Settings className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <h2 className="font-serif text-sm sm:text-xl font-bold tracking-tight text-white leading-tight"><span translate="no" className="notranslate">ECO JALUZI</span> — CMS Boshqaruv Markazi</h2>
              <p className="text-[10px] sm:text-xs text-brand-beige/70 font-light hidden xs:block">Veb-sayt tarkibini o‘zgartirish va buyurtmalar paneli</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-white/10 hover:bg-white/20 text-brand-cream rounded-full transition-colors flex items-center justify-center"
            title="Markazni yopish"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection Row & Body Wrapper */}
        <div className="flex flex-col md:flex-row flex-grow overflow-hidden relative">
          
          {/* Mobile Overlay Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden absolute inset-0 z-40 bg-brand-charcoal/60 backdrop-blur-sm flex flex-col justify-start">
              <div className="bg-brand-beige border-b border-brand-emerald/15 p-4 space-y-2 shadow-xl animate-fade-in animate-duration-200">
                <div className="flex items-center justify-between border-b border-brand-emerald/10 pb-2 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-brand-emerald-dark">Bo‘limni tanlang</span>
                  <button 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="p-1 text-brand-emerald-dark hover:bg-brand-emerald/10 rounded-lg"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                
                {/* Tab: Orders */}
                <button
                  onClick={() => {
                    setActiveTab('orders');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full py-3 px-4 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-3 rounded-xl transition-all ${
                    activeTab === 'orders'
                      ? 'bg-brand-emerald text-brand-cream'
                      : 'text-brand-emerald-dark hover:bg-brand-emerald/5'
                  }`}
                >
                  <ClipboardList className="w-4 h-4" />
                  <span>Buyurtmalar</span>
                  {orders.filter(o => o.status === 'Kutilmoqda').length > 0 && (
                    <span className="ml-auto bg-amber-500 text-brand-cream text-[10px] px-2 py-0.5 rounded-full">
                      {orders.filter(o => o.status === 'Kutilmoqda').length}
                    </span>
                  )}
                </button>

                {/* Tab: Consultations */}
                <button
                  onClick={() => {
                    setActiveTab('consultations');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full py-3 px-4 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-3 rounded-xl transition-all ${
                    activeTab === 'consultations'
                      ? 'bg-brand-emerald text-brand-cream'
                      : 'text-brand-emerald-dark hover:bg-brand-emerald/5'
                  }`}
                >
                  <Mail className="w-4 h-4" />
                  <span>Arizalar (Maslahat)</span>
                  {consultations.filter(c => c.status === 'Kutilmoqda').length > 0 && (
                    <span className="ml-auto bg-amber-500 text-brand-cream text-[10px] px-2 py-0.5 rounded-full">
                      {consultations.filter(c => c.status === 'Kutilmoqda').length}
                    </span>
                  )}
                </button>

                {/* Tab: Products */}
                <button
                  onClick={() => {
                    setActiveTab('products');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full py-3 px-4 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-3 rounded-xl transition-all ${
                    activeTab === 'products'
                      ? 'bg-brand-emerald text-brand-cream'
                      : 'text-brand-emerald-dark hover:bg-brand-emerald/5'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Mahsulotlar katalogi</span>
                </button>

                {/* Tab: Portfolio */}
                <button
                  onClick={() => {
                    setActiveTab('portfolio');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full py-3 px-4 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-3 rounded-xl transition-all ${
                    activeTab === 'portfolio'
                      ? 'bg-brand-emerald text-brand-cream'
                      : 'text-brand-emerald-dark hover:bg-brand-emerald/5'
                  }`}
                >
                  <FolderOpen className="w-4 h-4" />
                  <span>Portfolio loyihalari</span>
                </button>



                {/* Tab: Settings */}
                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full py-3 px-4 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-3 rounded-xl transition-all ${
                    activeTab === 'settings'
                      ? 'bg-brand-emerald text-brand-cream'
                      : 'text-brand-emerald-dark hover:bg-brand-emerald/5'
                  }`}
                >
                  <Globe className="w-4 h-4" />
                  <span>Aloqa sozlamalari</span>
                </button>

                {/* Live Visitors Count */}
                <div className="flex items-center gap-2 p-3 bg-brand-emerald/5 rounded-xl border border-brand-emerald/10">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-[11px] font-semibold text-brand-emerald-dark">
                    Kuzatuvchilar soni: <span className="font-mono font-bold">{visitCount}</span>
                  </span>
                </div>
              </div>
              <div className="flex-grow" onClick={() => setIsMobileMenuOpen(false)} />
            </div>
          )}

          {/* Tab Sidebar Column (Desktop Only) */}
          <div className="hidden md:flex w-64 bg-brand-beige border-r border-brand-emerald/10 flex-col overflow-y-auto shrink-0">
            
            {/* Tab: Orders */}
            <button
              onClick={() => setActiveTab('orders')}
              className={`py-4 px-6 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-2.5 border-r-4 transition-all ${
                activeTab === 'orders'
                  ? 'bg-brand-emerald/5 border-brand-emerald text-brand-emerald'
                  : 'border-transparent text-brand-emerald-dark/60 hover:bg-brand-emerald/5'
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              <span>Buyurtmalar</span>
              {orders.filter(o => o.status === 'Kutilmoqda').length > 0 && (
                <span className="ml-auto bg-amber-500 text-brand-cream text-[10px] px-2 py-0.5 rounded-full">
                  {orders.filter(o => o.status === 'Kutilmoqda').length}
                </span>
              )}
            </button>

            {/* Tab: Consultations */}
            <button
              onClick={() => setActiveTab('consultations')}
              className={`py-4 px-6 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-2.5 border-r-4 transition-all ${
                activeTab === 'consultations'
                  ? 'bg-brand-emerald/5 border-brand-emerald text-brand-emerald'
                  : 'border-transparent text-brand-emerald-dark/60 hover:bg-brand-emerald/5'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>Arizalar (Maslahat)</span>
              {consultations.filter(c => c.status === 'Kutilmoqda').length > 0 && (
                <span className="ml-auto bg-amber-500 text-brand-cream text-[10px] px-2 py-0.5 rounded-full">
                  {consultations.filter(c => c.status === 'Kutilmoqda').length}
                </span>
              )}
            </button>

            {/* Tab: Products */}
            <button
              onClick={() => setActiveTab('products')}
              className={`py-4 px-6 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-2.5 border-r-4 transition-all ${
                activeTab === 'products'
                  ? 'bg-brand-emerald/5 border-brand-emerald text-brand-emerald'
                  : 'border-transparent text-brand-emerald-dark/60 hover:bg-brand-emerald/5'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Mahsulotlar katalogi</span>
            </button>

            {/* Tab: Portfolio */}
            <button
              onClick={() => setActiveTab('portfolio')}
              className={`py-4 px-6 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-2.5 border-r-4 transition-all ${
                activeTab === 'portfolio'
                  ? 'bg-brand-emerald/5 border-brand-emerald text-brand-emerald'
                  : 'border-transparent text-brand-emerald-dark/60 hover:bg-brand-emerald/5'
              }`}
            >
              <FolderOpen className="w-4 h-4" />
              <span>Portfolio loyihalari</span>
            </button>



            {/* Tab: Settings */}
            <button
              onClick={() => setActiveTab('settings')}
              className={`py-4 px-6 text-xs font-bold uppercase tracking-wider text-left flex items-center gap-2.5 border-r-4 transition-all ${
                activeTab === 'settings'
                  ? 'bg-brand-emerald/5 border-brand-emerald text-brand-emerald'
                  : 'border-transparent text-brand-emerald-dark/60 hover:bg-brand-emerald/5'
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>Aloqa sozlamalari</span>
            </button>

            {/* Live Visitors Status for Desktop */}
            <div className="mt-auto p-5 border-t border-brand-emerald/10 bg-brand-emerald/5">
              <div className="flex items-center gap-2 text-brand-emerald-dark mb-1.5">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-brand-emerald">Sizni kuzatmoqda</span>
              </div>
              <p className="text-xs text-brand-charcoal/70 font-light leading-relaxed">
                Saytga tashrif buyurganlar soni: <strong className="font-bold text-brand-emerald-dark font-mono text-sm">{visitCount}</strong> nafar
              </p>
            </div>
          </div>

          {/* Tab Work Panel Container (Scrollable) */}
          <div className="flex-grow p-4 sm:p-6 overflow-y-auto bg-brand-cream">
            
            {/* TAB CONTENT: CUSTOMER ORDERS */}
            {activeTab === 'orders' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between border-b border-brand-emerald/10 pb-3 gap-3">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-brand-emerald-dark">Mijozlar buyurtmalari ({orders.length} ta)</h3>
                    <p className="text-[11px] text-brand-charcoal/60">Sayt yoki bot orqali tushgan barcha o‘lchov va montaj buyurtmalari</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowNewOrderModal(true)}
                      className="px-3.5 py-1.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-all"
                    >
                      <Plus className="w-4 h-4" /> Yangi buyurtma kiritish
                    </button>
                    <button
                      onClick={reloadData}
                      className="p-1.5 bg-brand-beige border border-brand-emerald/20 text-brand-emerald-dark hover:bg-brand-emerald/10 rounded-xl transition-colors"
                      title="Ro‘yxatni yangilash"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Manual Order Creation Modal */}
                {showNewOrderModal && (
                  <form onSubmit={handleCreateManualOrder} className="p-5 bg-brand-beige rounded-2xl border-2 border-brand-emerald/20 space-y-4 shadow-md">
                    <div className="flex justify-between items-center border-b border-brand-emerald/15 pb-2">
                      <div className="flex items-center gap-2">
                        <ClipboardList className="w-4 h-4 text-brand-emerald" />
                        <h4 className="font-bold text-brand-emerald-dark text-xs uppercase tracking-wider">
                          Qo‘lda yangi buyurtma qo‘shish
                        </h4>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowNewOrderModal(false)}
                        className="p-1 text-brand-charcoal/50 hover:text-brand-charcoal"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Mijoz ismi</label>
                        <input
                          type="text" required
                          value={newOrderData.name || ''}
                          onChange={(e) => setNewOrderData({ ...newOrderData, name: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3 py-2"
                          placeholder="Masalan: Sardor aka"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Telefon raqam</label>
                        <input
                          type="text" required
                          value={newOrderData.phone || ''}
                          onChange={(e) => setNewOrderData({ ...newOrderData, phone: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3 py-2"
                          placeholder="+998 90 123 45 67"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Jaluzi turi</label>
                        <select
                          value={newOrderData.typeOfBlinds || 'Dikey pardalar'}
                          onChange={(e) => setNewOrderData({ ...newOrderData, typeOfBlinds: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3 py-2"
                        >
                          {PORTFOLIO_CATEGORIES.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Derazalar soni</label>
                        <input
                          type="number" min="1"
                          value={newOrderData.numberOfWindows || 1}
                          onChange={(e) => setNewOrderData({ ...newOrderData, numberOfWindows: Number(e.target.value) })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3 py-2"
                        />
                      </div>

                      <div className="space-y-1 sm:col-span-2">
                        <label className="font-bold text-brand-emerald-dark">Manzil</label>
                        <input
                          type="text"
                          value={newOrderData.address || ''}
                          onChange={(e) => setNewOrderData({ ...newOrderData, address: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3 py-2"
                          placeholder="Toshkent sh., Yunusobod tumani..."
                        />
                      </div>

                      <div className="space-y-1 sm:col-span-2">
                        <label className="font-bold text-brand-emerald-dark">Izoh / Eslatma</label>
                        <textarea
                          rows={2}
                          value={newOrderData.comments || ''}
                          onChange={(e) => setNewOrderData({ ...newOrderData, comments: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl p-2.5"
                          placeholder="Mijoz bilan kelishilgan vaqt yoki xohishlari..."
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowNewOrderModal(false)}
                        className="flex-1 py-2 bg-brand-cream border border-brand-emerald/15 text-brand-charcoal font-bold text-xs rounded-xl"
                      >
                        Bekor qilish
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
                      >
                        <Save className="w-4 h-4" /> Buyurtmani saqlash
                      </button>
                    </div>
                  </form>
                )}

                {orders.length === 0 ? (
                  <p className="text-xs text-brand-charcoal/50 text-center py-12 font-light">Xarid buyurtmalari hozircha mavjud emas.</p>
                ) : (
                  <div className="space-y-4">
                    {orders.map((ord) => (
                      <div key={ord.id} className="p-5 bg-brand-beige rounded-2xl border border-brand-emerald/10 space-y-4 shadow-sm hover:border-brand-emerald/25 transition-all">
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-brand-emerald/5 pb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-serif font-bold text-brand-emerald-dark text-sm">{ord.name}</span>
                            <span className="text-[10px] font-mono text-brand-charcoal/40">#{ord.id}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              ord.status === 'Kutilmoqda' ? 'bg-amber-100 text-amber-800' : ord.status === 'Bogʻlanildi' ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800'
                            }`}>
                              {ord.status}
                            </span>
                          </div>
                        </div>

                        {/* Details Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                          <div>
                            <span className="text-brand-charcoal/40 block text-[11px]">Telefon raqam:</span>
                            <a href={`tel:${ord.phone}`} className="font-bold text-brand-emerald hover:underline flex items-center gap-1 mt-0.5">
                              <PhoneCall className="w-3.5 h-3.5" />
                              <span>{ord.phone}</span>
                            </a>
                          </div>
                          <div>
                            <span className="text-brand-charcoal/40 block text-[11px]">Jaluzi turi & Oyna soni:</span>
                            <span className="font-bold text-brand-emerald-dark block mt-0.5">{ord.typeOfBlinds} ({ord.numberOfWindows} ta deraza)</span>
                          </div>
                          <div>
                            <span className="text-brand-charcoal/40 block text-[11px]">Buyurtma sanasi:</span>
                            <span className="font-bold text-brand-emerald-dark block mt-0.5">{ord.date}</span>
                          </div>
                        </div>

                        {/* Address & Comments */}
                        {(ord.address || ord.comments) && (
                          <div className="text-xs bg-brand-cream p-3 rounded-xl space-y-1 border border-brand-emerald/5">
                            {ord.address && <div><span className="font-bold text-brand-emerald-dark">Manzil:</span> {ord.address}</div>}
                            {ord.comments && <div><span className="font-bold text-brand-emerald-dark">Izoh:</span> {ord.comments}</div>}
                          </div>
                        )}

                        {/* Status update actions & Telegram Forward */}
                        <div className="flex flex-wrap items-center gap-2 pt-2 justify-between border-t border-brand-emerald/5">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] uppercase font-bold text-brand-charcoal/40 mr-1">Status:</span>
                            <button
                              onClick={() => {
                                handleUpdateOrderStatus(ord.id, 'Kutilmoqda');
                                showToast("Status 'Kutilmoqda' ga o‘zgardi");
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                                ord.status === 'Kutilmoqda'
                                  ? 'bg-amber-500 text-white border-amber-600'
                                  : 'bg-brand-cream hover:bg-amber-50 text-brand-charcoal border-brand-emerald/10'
                              }`}
                            >
                              Kutilmoqda
                            </button>
                            <button
                              onClick={() => {
                                handleUpdateOrderStatus(ord.id, 'Bogʻlanildi');
                                showToast("Status 'Bog‘lanildi' ga o‘zgardi");
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                                ord.status === 'Bogʻlanildi'
                                  ? 'bg-blue-600 text-white border-blue-700'
                                  : 'bg-brand-cream hover:bg-blue-50 text-brand-charcoal border-brand-emerald/10'
                              }`}
                            >
                              Bog‘lanildi
                            </button>
                            <button
                              onClick={() => {
                                handleUpdateOrderStatus(ord.id, 'Bajarildi');
                                showToast("Status 'Bajarildi' ga o‘zgardi");
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                                ord.status === 'Bajarildi'
                                  ? 'bg-emerald-600 text-white border-emerald-700'
                                  : 'bg-brand-cream hover:bg-emerald-50 text-brand-charcoal border-brand-emerald/10'
                              }`}
                            >
                              Bajarildi
                            </button>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleSendExistingOrderToTelegram(ord)}
                              disabled={sendingOrderId === ord.id}
                              className="px-2.5 py-1.5 bg-brand-emerald/10 hover:bg-brand-emerald/20 text-brand-emerald-dark font-bold text-[10px] rounded-lg border border-brand-emerald/20 flex items-center gap-1 transition-all disabled:opacity-50"
                              title="Ushbu buyurtmani Telegramga qayta yuborish"
                            >
                              {sendingOrderId === ord.id ? (
                                <>
                                  <div className="w-3 h-3 border-2 border-brand-emerald border-t-transparent rounded-full animate-spin" />
                                  <span>Yuborilmoqda...</span>
                                </>
                              ) : (
                                <>
                                  <Send className="w-3 h-3" />
                                  <span>Telegramga yuborish</span>
                                </>
                              )}
                            </button>

                            <button
                              onClick={() => handleDeleteOrder(ord.id)}
                              className="p-1.5 bg-brand-cream hover:bg-red-50 text-red-600 rounded-lg border border-red-200 transition-colors"
                              title="O‘chirish"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: CONSULTATIONS */}
            {activeTab === 'consultations' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-brand-emerald/10 pb-3">
                  <h3 className="font-serif text-lg font-bold text-brand-emerald-dark">Consultation Requests ({consultations.length} ta)</h3>
                  <button onClick={reloadData} className="text-xs text-brand-emerald hover:underline">Ro‘yxatni yangilash</button>
                </div>

                {consultations.length === 0 ? (
                  <p className="text-xs text-brand-charcoal/50 text-center py-12 font-light">Ariza va so‘rovlar hozircha mavjud emas.</p>
                ) : (
                  <div className="space-y-4">
                    {consultations.map((cons) => (
                      <div key={cons.id} className="p-5 bg-brand-beige rounded-2xl border border-brand-emerald/5 space-y-3 shadow-sm">
                        <div className="flex items-center justify-between border-b border-brand-emerald/5 pb-2">
                          <span className="font-serif font-bold text-brand-emerald-dark">{cons.name}</span>
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                            cons.status === 'Kutilmoqda' ? 'bg-amber-100 text-amber-800' : cons.status === 'Bogʻlanildi' ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {cons.status}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-xs">
                          <div>
                            <span className="text-brand-charcoal/40 block">Telefon raqam:</span>
                            <a href={`tel:${cons.phone}`} className="font-bold text-brand-emerald hover:underline">{cons.phone}</a>
                          </div>
                          <div>
                            <span className="text-brand-charcoal/40 block">Ariza sanasi:</span>
                            <span className="font-bold text-brand-emerald-dark">{cons.date}</span>
                          </div>
                        </div>

                        {cons.comments && (
                          <p className="text-xs text-brand-charcoal/80 bg-brand-cream p-3 rounded-xl border border-brand-emerald/5">
                            <span className="font-bold block text-[10px] text-brand-charcoal/40 uppercase">Mijoz so‘rovi:</span>
                            {cons.comments}
                          </p>
                        )}

                        <div className="flex items-center justify-between pt-2">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] uppercase font-bold text-brand-charcoal/40">Statusni yangilash:</span>
                            <button
                              onClick={() => handleUpdateConsultStatus(cons.id, 'Kutilmoqda')}
                              className="px-2 py-0.5 bg-brand-cream text-brand-charcoal border border-brand-emerald/10 rounded text-[9px] font-medium"
                            >
                              Kutilmoqda
                            </button>
                            <button
                              onClick={() => handleUpdateConsultStatus(cons.id, 'Bogʻlanildi')}
                              className="px-2 py-0.5 bg-brand-cream text-brand-charcoal border border-brand-emerald/10 rounded text-[9px] font-medium"
                            >
                              Bog‘lanildi
                            </button>
                            <button
                              onClick={() => handleUpdateConsultStatus(cons.id, 'Bajarildi')}
                              className="px-2 py-0.5 bg-brand-cream text-brand-charcoal border border-brand-emerald/10 rounded text-[9px] font-medium"
                            >
                              Bajarildi
                            </button>
                          </div>

                          <button
                            onClick={() => handleDeleteConsult(cons.id)}
                            className="p-1.5 bg-brand-cream text-red-600 rounded border border-red-200"
                            title="O'chirish"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: PRODUCTS EDITOR */}
            {activeTab === 'products' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between border-b border-brand-emerald/10 pb-3 gap-2">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-brand-emerald-dark">Katalog mahsulotlari ({products.length} ta)</h3>
                    <p className="text-[11px] text-brand-charcoal/60">Saytning "Mahsulotlar" bo‘limidagi katalog ro‘yxati</p>
                  </div>
                  <button
                    onClick={() => setEditingProduct({
                      name: '', category: 'Combo jaluzi', pricePerSqm: 150000,
                      description: '', material: 'Turkiya sifati, 100% poliester', availableColors: ['Krem', 'Oq', 'Bej'],
                      image: ''
                    })}
                    className="px-3.5 py-1.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold rounded-lg flex items-center gap-1 shadow"
                  >
                    <Plus className="w-4 h-4" /> Yangi mahsulot qo‘shish
                  </button>
                </div>

                {/* Category Quick Filter */}
                <div className="flex flex-wrap gap-1.5 bg-brand-beige p-2 rounded-xl border border-brand-emerald/10 text-xs">
                  {['Barchasi', 'Combo jaluzi', 'Dikey pardalar', 'Plisse jaluzi', 'Roller Jaluzi', 'Yog‘och Jaluzi', 'Rim Jaluzi'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setAdminProductCategoryFilter(cat)}
                      className={`px-3 py-1 rounded-lg font-bold transition-all ${
                        adminProductCategoryFilter === cat
                          ? 'bg-brand-emerald text-brand-cream shadow-sm'
                          : 'text-brand-emerald-dark hover:bg-brand-cream'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Edit or Add Product inline form */}
                {editingProduct && (
                  <form onSubmit={handleSaveProduct} className="p-5 bg-brand-beige rounded-2xl border border-brand-emerald/15 space-y-4">
                    <div className="flex justify-between items-center border-b border-brand-emerald/10 pb-2">
                      <h4 className="font-bold text-brand-emerald-dark text-xs uppercase tracking-wider">
                        {editingProduct.id ? 'Mahsulotni tahrirlash' : 'Yangi mahsulot qo‘shish'}
                      </h4>
                      <button type="button" onClick={() => setEditingProduct(null)} className="p-1 rounded hover:bg-brand-cream">
                        <X className="w-4 h-4 text-brand-charcoal/60" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Nomi</label>
                        <input
                          type="text" required
                          value={editingProduct.name || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg px-3 py-2"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <label className="font-bold text-brand-emerald-dark">Turkum / Kategoriya</label>
                          <select
                            value={editingProduct.category || 'Combo jaluzi'}
                            onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                            className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg px-2 py-2"
                          >
                            <option>Combo jaluzi</option>
                            <option>Dikey pardalar</option>
                            <option>Plisse jaluzi</option>
                            <option>Roller Jaluzi</option>
                            <option>Yog‘och Jaluzi</option>
                            <option>Rim Jaluzi</option>
                            <option>Boshqa</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="font-bold text-brand-emerald-dark">1 m² narxi (UZS)</label>
                          <input
                            type="number" required
                            value={editingProduct.pricePerSqm || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, pricePerSqm: Number(e.target.value) })}
                            className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg px-2 py-2 font-mono font-bold"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Materiallar tarkibi</label>
                        <input
                          type="text"
                          value={editingProduct.material || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, material: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg px-3 py-2"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark flex justify-between">
                          <span>Rasm (URL yoki Fayl yuklash)</span>
                        </label>
                        <div className="space-y-2">
                          <input
                            type="text"
                            value={editingProduct.image || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                            className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg px-3 py-2 font-mono"
                            placeholder="https://images.unsplash.com/... yoki rasm yo'li"
                          />
                          <div className="flex items-center gap-2">
                            <label className="flex-1 cursor-pointer bg-brand-emerald/5 hover:bg-brand-emerald/10 border border-brand-emerald/20 text-brand-emerald-dark font-semibold py-1.5 px-3 rounded-lg text-center transition-all">
                              <span>📁 Rasm yuklash</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleImageFileChange(e, 'product')}
                                className="hidden"
                              />
                            </label>
                            {editingProduct.image && (
                              <img 
                                src={editingProduct.image} 
                                alt="Preview" 
                                referrerPolicy="no-referrer"
                                className="w-9 h-9 rounded object-cover border border-brand-emerald/25"
                              />
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-1 sm:col-span-2">
                        <label className="font-bold text-brand-emerald-dark">Video (Havola silka yoki Video fayl yuklash)</label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={editingProduct.videoUrl || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, videoUrl: e.target.value, mediaType: e.target.value ? 'video' : 'image' })}
                            className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg px-3 py-2 font-mono"
                            placeholder="Video ssilkasi (masalan: /factory.mp4 yoki https://...)"
                          />
                          <div className="flex items-center gap-2">
                            <label className="flex-1 cursor-pointer bg-brand-emerald/5 hover:bg-brand-emerald/10 border border-brand-emerald/20 text-brand-emerald-dark font-semibold py-1.5 px-3 rounded-lg text-center transition-all">
                              <span>📹 Video fayl yuklash (MP4)</span>
                              <input
                                type="file"
                                accept="video/*"
                                onChange={(e) => handleVideoFileChange(e, 'product')}
                                className="hidden"
                              />
                            </label>
                            {editingProduct.videoUrl && (
                              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-1 rounded font-bold">Video biriktirildi</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1 text-xs">
                      <label className="font-bold text-brand-emerald-dark">Tavsif (Description)</label>
                      <textarea
                        rows={3}
                        value={editingProduct.description || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                        className="w-full bg-brand-cream border border-brand-emerald/15 rounded-lg p-3"
                      />
                    </div>

                    <div className="flex gap-3">
                      <button
                        type="button"
                        onClick={() => setEditingProduct({
                          name: '',
                          category: 'Combo jaluzi',
                          pricePerSqm: 0,
                          description: '',
                          material: '',
                          availableColors: ['Oq', 'Krem', 'Bej'],
                          image: ''
                        })}
                        className="flex-1 py-2.5 bg-brand-beige border border-brand-emerald/25 hover:bg-brand-emerald/5 text-brand-emerald font-bold text-xs uppercase tracking-wider rounded-xl transition-all"
                      >
                        Tozalash
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream font-bold text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-1.5 shadow"
                      >
                        <Save className="w-4 h-4" /> Saqlash
                      </button>
                    </div>
                  </form>
                )}

                {/* List products table */}
                <div className="space-y-3">
                  {products
                    .filter(p => adminProductCategoryFilter === 'Barchasi' || p.category.toLowerCase().includes(adminProductCategoryFilter.toLowerCase()) || adminProductCategoryFilter.toLowerCase().includes(p.category.toLowerCase()))
                    .map((p) => (
                    <div key={p.id} className="p-4 bg-brand-beige rounded-xl border border-brand-emerald/5 flex flex-wrap items-center justify-between gap-4 text-xs shadow-sm">
                      <div className="flex items-center gap-3">
                        <img src={p.image} alt={p.name} referrerPolicy="no-referrer" className="w-12 h-12 rounded-lg object-cover border bg-brand-charcoal" />
                        <div>
                          <span className="font-serif font-bold text-brand-emerald-dark text-sm block">{p.name}</span>
                          <span className="text-[10px] text-brand-charcoal/50 block font-medium uppercase tracking-wider">{p.category} | {p.material}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <span className="text-[10px] text-brand-charcoal/40 block font-semibold uppercase">1 m² narxi</span>
                          <span className="font-bold text-brand-emerald font-display">{formatPrice(p.pricePerSqm)}</span>
                        </div>

                        <div className="flex gap-1.5">
                          <button
                            onClick={() => setEditingProduct(p)}
                            className="p-1.5 bg-brand-cream text-brand-emerald hover:bg-brand-emerald/5 border border-brand-emerald/20 rounded transition-colors"
                            title="Tahrirlash"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1.5 bg-brand-cream text-red-600 hover:bg-red-50 border border-red-200 rounded transition-colors"
                            title="O'chirish"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB CONTENT: PORTFOLIO EDITOR */}
            {activeTab === 'portfolio' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between border-b border-brand-emerald/10 pb-3 gap-3">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-brand-emerald-dark">Portfolio loyihalari ({projects.length} ta)</h3>
                    <p className="text-[11px] text-brand-charcoal/60">Saytning "Qilingan ishlar" (Portfolio) galereyasidagi real ishlar boshqaruvi</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setEditingProject({
                          title: '',
                          category: 'Dikey pardalar',
                          description: '',
                          image: '',
                          videoUrl: '',
                          mediaType: 'image'
                        });
                      }}
                      className="px-4 py-2 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-all hover:scale-[1.02]"
                    >
                      <Plus className="w-4 h-4" /> Yangi ish qo‘shish
                    </button>
                  </div>
                </div>

                {/* Search & Filter Bar */}
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="w-4 h-4 text-brand-charcoal/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={adminProjectSearch}
                      onChange={(e) => setAdminProjectSearch(e.target.value)}
                      placeholder="Loyihalarni nomi yoki kategoriyasi bo‘yicha qidirish..."
                      className="w-full bg-brand-beige/80 border border-brand-emerald/15 rounded-xl pl-10 pr-10 py-2.5 text-xs text-brand-charcoal focus:outline-none focus:border-brand-emerald/40 transition-colors"
                    />
                    {adminProjectSearch && (
                      <button
                        onClick={() => setAdminProjectSearch('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-brand-charcoal/40 hover:text-brand-charcoal"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Category Quick Filter */}
                  <div className="flex flex-wrap gap-1.5 bg-brand-beige/60 p-2 rounded-xl border border-brand-emerald/10 text-xs">
                    {['Barchasi', ...PORTFOLIO_CATEGORIES].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setAdminProjectCategoryFilter(cat)}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all ${
                          adminProjectCategoryFilter === cat
                            ? 'bg-brand-emerald text-brand-cream shadow-sm'
                            : 'text-brand-emerald-dark hover:bg-brand-cream/80'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Project Add / Edit Form Modal or Inline */}
                {editingProject && (
                  <form onSubmit={handleSaveProject} className="p-5 sm:p-6 bg-brand-beige rounded-2xl border-2 border-brand-emerald/20 space-y-4 shadow-md">
                    <div className="flex justify-between items-center border-b border-brand-emerald/15 pb-2.5">
                      <div className="flex items-center gap-2">
                        <FolderOpen className="w-4 h-4 text-brand-emerald" />
                        <h4 className="font-bold text-brand-emerald-dark text-xs uppercase tracking-wider">
                          {editingProject.id ? 'Portfolio elementini tahrirlash' : 'Yangi portfolio loyihasi qo‘shish'}
                        </h4>
                      </div>
                      <button
                        type="button"
                        onClick={() => setEditingProject(null)}
                        className="p-1 rounded-lg hover:bg-brand-cream text-brand-charcoal/60 hover:text-brand-charcoal transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Loyiha sarlavhasi (Masalan: Mehmonxona uchun Dikey parda)</label>
                        <input
                          type="text" required
                          value={editingProject.title || ''}
                          onChange={(e) => setEditingProject({ ...editingProject, title: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-brand-emerald"
                          placeholder="Loyiha nomini kiriting..."
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-brand-emerald-dark">Jaluzi turi (Kategoriya)</label>
                        <select
                          value={editingProject.category || 'Dikey pardalar'}
                          onChange={(e) => setEditingProject({ ...editingProject, category: e.target.value })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3.5 py-2.5 font-medium focus:outline-none focus:border-brand-emerald"
                        >
                          {PORTFOLIO_CATEGORIES.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Image Management Section */}
                    <div className="p-4 bg-brand-cream/80 border border-brand-emerald/15 rounded-xl space-y-3 text-xs">
                      <div className="flex items-center justify-between">
                        <label className="font-bold text-brand-emerald-dark flex items-center gap-1.5">
                          <ImageIcon className="w-4 h-4 text-brand-emerald" />
                          <span>Loyiha fotosurati (Rasm)</span>
                        </label>
                        {isCompressingImage && (
                          <span className="text-[10px] text-amber-700 font-semibold animate-pulse">
                            ⏳ Rasm siqilmoqda va yuklanmoqda...
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                        <div className="sm:col-span-8">
                          <input
                            type="text"
                            value={editingProject.image || ''}
                            onChange={(e) => setEditingProject({ ...editingProject, image: e.target.value })}
                            className="w-full bg-white border border-brand-emerald/15 rounded-xl px-3.5 py-2.5 font-mono text-[11px] focus:outline-none focus:border-brand-emerald"
                            placeholder="Rasm havolasi (https://i.ibb.co/... yoki fayl yuklang)"
                          />
                        </div>

                        <div className="sm:col-span-4">
                          <label className="w-full cursor-pointer bg-brand-emerald/10 hover:bg-brand-emerald/20 border border-brand-emerald/25 text-brand-emerald-dark font-bold py-2.5 px-3 rounded-xl text-center flex items-center justify-center gap-1.5 transition-all text-xs">
                            <Upload className="w-3.5 h-3.5" />
                            <span>Fayldan yuklash</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImageFileChange(e, 'project')}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>

                      {/* Image Preview & Delete Action */}
                      {editingProject.image && (
                        <div className="flex items-center justify-between gap-3 p-2 bg-white rounded-xl border border-brand-emerald/15">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={editingProject.image}
                              alt="Loyiha rasmi"
                              referrerPolicy="no-referrer"
                              className="w-14 h-14 rounded-lg object-cover border border-brand-emerald/20 shadow-xs"
                            />
                            <div>
                              <span className="font-bold text-[11px] text-brand-emerald-dark block">Rasm biriktirildi</span>
                              <button
                                type="button"
                                onClick={() => setPreviewImageUrl(editingProject.image || null)}
                                className="text-[10px] text-brand-emerald hover:underline flex items-center gap-1 mt-0.5"
                              >
                                <Eye className="w-3 h-3" /> To‘liq ochib ko‘rish
                              </button>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => setEditingProject({ ...editingProject, image: '' })}
                            className="px-2.5 py-1 text-[11px] bg-red-50 hover:bg-red-100 text-red-600 rounded-lg border border-red-200 flex items-center gap-1 transition-colors"
                          >
                            <Trash2 className="w-3 h-3" /> Rasmni o‘chirish
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Video Attachment (Optional) */}
                    <div className="space-y-1 text-xs">
                      <label className="font-bold text-brand-emerald-dark">Video (Ixtiyoriy — MP4 havola yoki video fayl)</label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={editingProject.videoUrl || ''}
                          onChange={(e) => setEditingProject({ ...editingProject, videoUrl: e.target.value, mediaType: e.target.value ? 'video' : 'image' })}
                          className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-3.5 py-2 font-mono text-[11px]"
                          placeholder="Masalan: /videos/loyihamiz.mp4 yoki URL"
                        />
                        <div className="flex items-center gap-2">
                          <label className="flex-1 cursor-pointer bg-brand-emerald/5 hover:bg-brand-emerald/10 border border-brand-emerald/20 text-brand-emerald-dark font-semibold py-2 px-3 rounded-xl text-center transition-all">
                            <span>📹 Video fayl yuklash</span>
                            <input
                              type="file"
                              accept="video/*"
                              onChange={(e) => handleVideoFileChange(e, 'project')}
                              className="hidden"
                            />
                          </label>
                          {editingProject.videoUrl && (
                            <button
                              type="button"
                              onClick={() => setEditingProject({ ...editingProject, videoUrl: '', mediaType: 'image' })}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg border border-red-200"
                              title="Videoni o‘chirish"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="space-y-1 text-xs">
                      <label className="font-bold text-brand-emerald-dark">Loyiha haqida batafsil ma’lumot (Izoh)</label>
                      <textarea
                        rows={2}
                        value={editingProject.description || ''}
                        onChange={(e) => setEditingProject({ ...editingProject, description: e.target.value })}
                        className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl p-3 focus:outline-none focus:border-brand-emerald"
                        placeholder="Masalan: Ushbu xonadonga o‘rnatilgan dikey pardalar quyosh nurini 180° qaytarib, xonada mukammal qulaylik yaratadi."
                      />
                    </div>

                    {/* Action buttons */}
                    <div className="flex gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setEditingProject(null)}
                        className="flex-1 py-2.5 bg-brand-cream border border-brand-emerald/20 hover:bg-brand-cream/70 text-brand-charcoal font-bold text-xs uppercase tracking-wider rounded-xl transition-all"
                      >
                        Bekor qilish
                      </button>
                      <button
                        type="submit"
                        disabled={isCompressingImage}
                        className="flex-1 py-2.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream font-bold text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-1.5 shadow transition-all disabled:opacity-50"
                      >
                        <Save className="w-4 h-4" />
                        <span>{editingProject.id ? 'O‘zgarishlarni Saqlash' : 'Portfolio ga Qo‘shish'}</span>
                      </button>
                    </div>
                  </form>
                )}

                {/* Portfolio Projects Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {projects
                    .filter(proj => {
                      const matchesCategory = adminProjectCategoryFilter === 'Barchasi' ||
                        proj.category.toLowerCase().includes(adminProjectCategoryFilter.toLowerCase()) ||
                        adminProjectCategoryFilter.toLowerCase().includes(proj.category.toLowerCase());
                      const matchesSearch = !adminProjectSearch.trim() ||
                        proj.title.toLowerCase().includes(adminProjectSearch.toLowerCase()) ||
                        proj.category.toLowerCase().includes(adminProjectSearch.toLowerCase()) ||
                        (proj.description && proj.description.toLowerCase().includes(adminProjectSearch.toLowerCase()));
                      return matchesCategory && matchesSearch;
                    })
                    .map((proj) => (
                      <div key={proj.id} className="p-4 bg-brand-beige rounded-2xl border border-brand-emerald/10 flex flex-col justify-between gap-3 text-xs shadow-xs hover:border-brand-emerald/25 transition-all">
                        <div className="flex items-start gap-3">
                          <div className="relative group shrink-0">
                            <img
                              src={proj.image}
                              alt={proj.title}
                              referrerPolicy="no-referrer"
                              className="w-16 h-16 rounded-xl object-cover bg-brand-charcoal border border-brand-emerald/15 shadow-xs cursor-pointer"
                              onClick={() => setPreviewImageUrl(proj.image)}
                              title="Kattalashtirib ko‘rish"
                            />
                            <div
                              onClick={() => setPreviewImageUrl(proj.image)}
                              className="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity cursor-pointer"
                            >
                              <Eye className="w-4 h-4" />
                            </div>
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 mb-1">
                              <span className="bg-brand-emerald/10 text-brand-emerald-dark border border-brand-emerald/15 px-2 py-0.5 rounded-md text-[9px] font-bold">
                                {proj.category}
                              </span>
                              {proj.videoUrl && (
                                <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded text-[8px] font-bold">
                                  Video
                                </span>
                              )}
                            </div>
                            <h5 className="font-serif font-bold text-brand-emerald-dark text-xs leading-snug line-clamp-2">
                              {proj.title}
                            </h5>
                            {proj.description && (
                              <p className="text-[11px] text-brand-charcoal/60 mt-1 line-clamp-2 font-light">
                                {proj.description}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Bottom Actions */}
                        <div className="flex items-center justify-between pt-2 border-t border-brand-emerald/5">
                          <button
                            type="button"
                            onClick={() => setPreviewImageUrl(proj.image)}
                            className="text-[10px] text-brand-emerald hover:underline flex items-center gap-1"
                          >
                            <Eye className="w-3 h-3" /> Rasmni ochish
                          </button>

                          <div className="flex gap-1.5">
                            <button
                              onClick={() => {
                                setEditingProject(proj);
                                // Scroll into view smoothly
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              }}
                              className="px-2.5 py-1.5 bg-brand-cream text-brand-emerald hover:bg-brand-emerald/10 border border-brand-emerald/20 rounded-lg flex items-center gap-1 font-semibold transition-colors"
                              title="Tahrirlash"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              <span>Tahrirlash</span>
                            </button>
                            <button
                              onClick={() => handleDeleteProject(proj.id, proj.title)}
                              className="p-1.5 bg-brand-cream text-red-600 hover:bg-red-50 border border-red-200 rounded-lg transition-colors"
                              title="O‘chirish"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>

                {/* Empty State */}
                {projects.filter(proj => {
                  const matchesCategory = adminProjectCategoryFilter === 'Barchasi' ||
                    proj.category.toLowerCase().includes(adminProjectCategoryFilter.toLowerCase()) ||
                    adminProjectCategoryFilter.toLowerCase().includes(proj.category.toLowerCase());
                  const matchesSearch = !adminProjectSearch.trim() ||
                    proj.title.toLowerCase().includes(adminProjectSearch.toLowerCase()) ||
                    proj.category.toLowerCase().includes(adminProjectSearch.toLowerCase()) ||
                    (proj.description && proj.description.toLowerCase().includes(adminProjectSearch.toLowerCase()));
                  return matchesCategory && matchesSearch;
                }).length === 0 && (
                  <div className="text-center py-12 bg-brand-beige/50 rounded-2xl border border-brand-emerald/10 p-6">
                    <FolderOpen className="w-8 h-8 text-brand-charcoal/30 mx-auto mb-2" />
                    <p className="text-xs text-brand-charcoal/60 font-medium">Bunday loyihalar topilmadi.</p>
                    <p className="text-[11px] text-brand-charcoal/40 mt-1">Filtrni o‘zgartiring yoki yangi ish qo‘shing.</p>
                  </div>
                )}
              </div>
            )}



            {/* TAB CONTENT: GLOBAL CONTACT SETTINGS */}
            {activeTab === 'settings' && (
              <form onSubmit={handleSaveConfig} className="space-y-6">
                <div className="border-b border-brand-emerald/10 pb-3">
                  <h3 className="font-serif text-lg font-bold text-brand-emerald-dark">Veb-sayt aloqa va ijtimoiy kanallar sozlamalari</h3>
                  <p className="text-[11px] text-brand-charcoal/50 font-light mt-1">Ushbu maydonlarni tahrir qilsangiz, saytdagi barcha tugmalar va kontaktlar avtomatik yangilanadi.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
                  <div className="space-y-1.5">
                    <label className="font-bold text-brand-emerald-dark">Aloqa telefon raqami</label>
                    <input
                      type="text" required
                      value={config.phoneNumber}
                      onChange={(e) => setConfig({ ...config, phoneNumber: e.target.value })}
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="font-bold text-brand-emerald-dark">Telegram kanal/guruh havolasi</label>
                    <input
                      type="text" required
                      value={config.telegramLink}
                      onChange={(e) => setConfig({ ...config, telegramLink: e.target.value })}
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
                  <div className="space-y-1.5">
                    <label className="font-bold text-brand-emerald-dark">Instagram profil havolasi</label>
                    <input
                      type="text" required
                      value={config.instagramLink}
                      onChange={(e) => setConfig({ ...config, instagramLink: e.target.value })}
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="font-bold text-brand-emerald-dark">Telegram Admin havolasi (Muloqot uchun)</label>
                    <input
                      type="text" required
                      value={config.adminTelegram || ''}
                      onChange={(e) => setConfig({ ...config, adminTelegram: e.target.value })}
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1.5 text-xs">
                  <label className="font-bold text-brand-emerald-dark">
                    Bosh ofis/Do‘kon manzili <span className="font-normal text-brand-charcoal/50">(ixtiyoriy, kiritilmasa saytda yashiriladi)</span>
                  </label>
                  <input
                    type="text"
                    value={config.address || ''}
                    onChange={(e) => setConfig({ ...config, address: e.target.value })}
                    className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3"
                  />
                </div>

                <div className="space-y-1.5 text-xs">
                  <label className="font-bold text-brand-emerald-dark">
                    Fabrika va Ishlab Chiqarish Video havolasi (.mp4 URL yoki video fayl) <span className="font-normal text-brand-charcoal/50">(ixtiyoriy, to‘g‘ridan-to‘g‘ri video havolasini qo‘yishingiz mumkin)</span>
                  </label>
                  <input
                    type="text"
                    value={config.factoryVideoUrl || ''}
                    onChange={(e) => setConfig({ ...config, factoryVideoUrl: e.target.value })}
                    className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                    placeholder="Masalan: https://example.com/video.mp4 (bo‘sh qoldirilsa rasmiy HD poster va interaktiv namoyish turadi)"
                  />
                </div>

                {/* TELEGRAM BOT INTEGRATION SECTION */}
                <div className="border-t border-brand-emerald/15 pt-5 space-y-4">
                  <div>
                    <h4 className="font-serif font-bold text-brand-emerald-dark text-sm">Telegram buyurtmalar bot sozlamalari</h4>
                    <p className="text-[11px] text-brand-charcoal/50 font-light mt-0.5">Ushbu tizim saytdan kelgan har bir yangi buyurtmani avtomatik ravishda sizning shaxsiy Telegramingizga yoki guruhga yuboradi.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
                    <div className="space-y-1.5">
                      <label className="font-bold text-brand-emerald-dark">Admin Bot Token (API Token)</label>
                      <input
                        type="password" required
                        value={config.telegramBotToken || ''}
                        onChange={(e) => setConfig({ ...config, telegramBotToken: e.target.value })}
                        className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                        placeholder="Masalan: 12345678:ABCDefGh..."
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="font-bold text-brand-emerald-dark">Sizning Chat ID (Shaxsiy yoki Guruh)</label>
                        <a 
                          href="https://t.me/userinfobot" 
                          target="_blank" 
                          rel="noreferrer" 
                          className="text-[10px] text-brand-emerald font-semibold hover:underline"
                        >
                          ID aniqlash (@userinfobot)
                        </a>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={config.telegramChatId || ''}
                          onChange={(e) => setConfig({ ...config, telegramChatId: e.target.value })}
                          className="flex-1 bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                          placeholder="Masalan: 123456789"
                        />
                        <button
                          type="button"
                          onClick={handleDetectChatId}
                          disabled={detectStatus === 'loading' || !config.telegramBotToken}
                          className="px-3 bg-brand-emerald/10 hover:bg-brand-emerald/20 text-brand-emerald-dark font-bold text-[10px] uppercase rounded-xl border border-brand-emerald/10 transition-all disabled:opacity-50"
                          title="Botingizga /start deb yozing va ushbu tugmani bosing"
                        >
                          {detectStatus === 'loading' ? 'Qidirilmoqda...' : 'Avtomat aniqlash ⚡'}
                        </button>
                      </div>
                      {detectStatus === 'success' && (
                        <p className="text-[10px] text-emerald-600 font-semibold animate-pulse">
                          ✅ Aniqlandi! Mijoz: {detectedUser} (Chat ID: {config.telegramChatId})
                        </p>
                      )}
                      {detectStatus === 'not_found' && (
                        <p className="text-[10px] text-red-500 font-medium">
                          ❌ Hech kim topilmadi. Avval botingizga kiring va <strong>/start</strong> tugmasini bosing!
                        </p>
                      )}
                    </div>

                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="font-bold text-brand-emerald-dark">
                        Mijozlar boti API Tokeni (Telegram Web App boti) <span className="font-normal text-brand-charcoal/50">(ixtiyoriy)</span>
                      </label>
                      <input
                        type="password"
                        value={config.customerBotToken || ''}
                        onChange={(e) => setConfig({ ...config, customerBotToken: e.target.value })}
                        className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                        placeholder="Bo'sh qolsa yuqoridagi Admin boti ishlatiladi (Yangi yulduzli botga joylasangiz o'shaning tokenini yozing)"
                      />
                      <p className="text-[10px] text-brand-charcoal/50 font-light">Saytni yangi mijozlar botiga ulaganingizda, mijozga o'sha yangi botdan xabar borishi uchun uning tokenini shu yerga yozib qo'ying.</p>
                    </div>

                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="font-bold text-brand-emerald-dark">
                        Mijozlar Chat ID (ixtiyoriy)
                      </label>
                      <input
                        type="text"
                        value={config.customerChatId || ''}
                        onChange={(e) => setConfig({ ...config, customerChatId: e.target.value })}
                        className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 font-mono"
                        placeholder="Masalan: 123456789. Bo'sh qolsa mijozning o'ziga boradi (WebApp dan)"
                      />
                      <p className="text-[10px] text-brand-charcoal/50 font-light">Mijozlarga xabar yuborishda muammo bo'lmasligi uchun aniq bitta Chat ID kiritishingiz mumkin.</p>
                    </div>
                  </div>

                  <div className="p-4 bg-brand-beige/50 border border-brand-emerald/10 rounded-2xl text-[11px] space-y-2 text-brand-charcoal/80 leading-relaxed">
                    <span className="font-bold text-brand-emerald-dark block text-xs">💡 Qisqa yo'riqnoma:</span>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>Botdan xabarlar kela boshlashi uchun birinchi navbatda o'sha botga kirib <strong className="text-brand-emerald-dark">/start</strong> buyrug'ini yuboring.</li>
                      <li>Agar xabarlarni shaxsiy profilingizga olmoqchi bo'lsangiz, <a href="https://t.me/userinfobot" target="_blank" rel="noreferrer" className="text-brand-emerald font-bold underline">@userinfobot</a> botiga kirib ID raqamingizni oling va yuqoridagi <strong>Chat ID</strong> maydoniga kiriting.</li>
                      <li>Agar guruhga olmoqchi bo'lsangiz, botingizni guruhga <strong className="text-brand-emerald-dark">Admin</strong> qilib qo'shing va guruh ID raqamini kiriting.</li>
                    </ol>
                  </div>

                  {testResultMsg && (
                    <div className={`p-3 rounded-xl border text-xs font-medium ${
                      testStatus === 'success'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-red-50 text-red-700 border-red-200'
                    }`}>
                      {testResultMsg}
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={handleTestTelegram}
                      disabled={testStatus === 'loading' || !config.telegramBotToken || !config.telegramChatId}
                      className="px-5 py-2.5 bg-brand-beige border border-brand-emerald/25 hover:bg-brand-emerald/5 disabled:opacity-50 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5"
                    >
                      {testStatus === 'loading' ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-brand-emerald border-t-transparent rounded-full animate-spin" />
                          <span>Yuborilmoqda...</span>
                        </>
                      ) : testStatus === 'success' ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-600" />
                          <span className="text-emerald-600 font-bold">Xabar bordi!</span>
                        </>
                      ) : testStatus === 'error' ? (
                        <>
                          <X className="w-4 h-4 text-red-600" />
                          <span className="text-red-600 font-bold">Ulanish xatosi</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>1. Oddiy Test xabar yuborish</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleSendSampleOrder}
                      disabled={sampleOrderStatus === 'loading' || !config.telegramBotToken || !config.telegramChatId}
                      className="px-5 py-2.5 bg-brand-emerald/10 hover:bg-brand-emerald/20 disabled:opacity-50 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider rounded-xl transition-all border border-brand-emerald/20 shadow-sm flex items-center justify-center gap-1.5"
                    >
                      {sampleOrderStatus === 'loading' ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-brand-emerald border-t-transparent rounded-full animate-spin" />
                          <span>Buyurtma yuborilmoqda...</span>
                        </>
                      ) : sampleOrderStatus === 'success' ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-600" />
                          <span className="text-emerald-600 font-bold">Buyurtma bordi!</span>
                        </>
                      ) : (
                        <>
                          <ClipboardList className="w-3.5 h-3.5" />
                          <span>2. Namuna buyurtma yuborib ko‘rish</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 hover:scale-[1.01]"
                >
                  <Save className="w-4 h-4" />
                  <span>Barcha Sozlamalarni Saqlash</span>
                </button>
              </form>
            )}

          </div>
        </div>

        {/* Floating Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 bg-brand-emerald-dark text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2 border border-white/20 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Full Image Preview Modal */}
        {previewImageUrl && (
          <div
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setPreviewImageUrl(null)}
          >
            <div
              className="relative max-w-3xl max-h-[90vh] bg-brand-beige rounded-2xl overflow-hidden shadow-2xl p-2 border border-white/20"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setPreviewImageUrl(null)}
                className="absolute top-4 right-4 p-2 bg-black/60 hover:bg-black/80 text-white rounded-full z-10 transition-colors"
                title="Yopish"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={previewImageUrl}
                alt="Ko‘rish"
                referrerPolicy="no-referrer"
                className="max-h-[82vh] w-auto mx-auto rounded-xl object-contain"
              />
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
