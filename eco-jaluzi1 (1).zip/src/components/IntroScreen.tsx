import React, { useState, useEffect } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Spline from '@splinetool/react-spline';

interface IntroScreenProps {
  onEnter: () => void;
}

export default function IntroScreen({ onEnter }: IntroScreenProps) {
  const [isDesktop, setIsDesktop] = useState(false);
  const [splineLoaded, setSplineLoaded] = useState(false);

  useEffect(() => {
    const checkScreen = () => {
      setIsDesktop(window.innerWidth >= 1024);
    };
    checkScreen();
    window.addEventListener('resize', checkScreen);
    return () => window.removeEventListener('resize', checkScreen);
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-[#9bf4b4] overflow-hidden select-none font-sans text-[#022a1a] w-full h-full">
      
      {isDesktop ? (
        /* ================= DESKTOP VIEW (FULL SCREEN SPLINE INTERACTIVE) ================= */
        <div className="relative w-full h-full">
          {/* Spline Canvas */}
          <div className="absolute inset-0 w-full h-full z-10 overflow-hidden">
            <Spline
              scene="https://prod.spline.design/4wtR6BFaFRs864rz/scene.splinecode"
              onLoad={() => setSplineLoaded(true)}
              className="w-full h-full scale-[1.02] origin-center"
            />
            {/* Seamless cover to hide the 'Built with Spline' watermark */}
            <div className="absolute bottom-0 right-0 w-[170px] h-[48px] bg-[#9bf4b4] z-20 pointer-events-none" />
          </div>

          {/* Loader Overlay */}
          <AnimatePresence>
            {!splineLoaded && (
              <motion.div 
                key="loader"
                initial={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6, ease: "easeInOut" }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-[#9bf4b4] z-30 text-[#022a1a]"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="relative flex items-center justify-center">
                    <div className="animate-ping absolute inline-flex h-14 w-14 rounded-full bg-[#022a1a]/20 opacity-75"></div>
                    <div className="relative rounded-full h-10 w-10 bg-[#022a1a] flex items-center justify-center">
                      <div className="w-3 h-3 rounded-full bg-[#b5ff1a]" />
                    </div>
                  </div>
                  <div className="text-center animate-pulse">
                    <p className="font-black text-xl tracking-wide uppercase text-[#022a1a]">
                      <span translate="no" className="notranslate">Eco Jaluzi</span>
                    </p>
                    <p className="text-xs opacity-75 mt-1 font-semibold text-[#022a1a]/80">Yuklanmoqda...</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Floating Desktop Kirish Button Overlay */}
          <AnimatePresence>
            {splineLoaded && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.8 }}
                className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 pointer-events-auto"
              >
                <button
                  onClick={onEnter}
                  className="group flex items-center justify-between gap-12 bg-[#022a1a]/95 backdrop-blur-md text-[#a3f7bf] pl-10 pr-3 py-3 rounded-full shadow-[0_20px_50px_rgba(2,42,26,0.4)] border border-white/10 transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer hover:bg-[#022a1a]"
                >
                  <span className="font-extrabold text-base md:text-lg tracking-wider uppercase">
                    Kirish
                  </span>
                  <div className="w-11 h-11 rounded-full bg-[#b5ff1a] text-[#022a1a] flex items-center justify-center transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 shadow-md">
                    <ArrowUpRight className="w-5 h-5 stroke-[3]" />
                  </div>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : (
        /* ================= MOBILE / TABLET VIEW (PIXEL-PERFECT HUDDI SHUNAQA DIZAYN) ================= */
        <div className="relative w-full h-full flex flex-col justify-between p-6 sm:p-8 select-none bg-[#9bf4b4] overflow-hidden">
          
          {/* Subtle Ambient Radial Light */}
          <div className="absolute top-1/3 -right-20 w-80 h-80 rounded-full bg-[#5cff9c]/40 blur-3xl pointer-events-none" />
          <div className="absolute bottom-10 -left-20 w-72 h-72 rounded-full bg-[#05df59]/20 blur-3xl pointer-events-none" />

          {/* Top Floating Glass Navigation Header */}
          <div className="w-full flex items-center justify-between relative z-30 pt-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#022a1a]" />
              <span className="text-[11px] font-bold tracking-widest uppercase text-[#022a1a]/70">ECO JALUZI</span>
            </div>

            {/* Top Right Floating Menu Icon */}
            <div className="w-11 h-11 rounded-full bg-white/40 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-sm cursor-pointer hover:bg-white/60 transition-all active:scale-95">
              <div className="space-y-1 w-5">
                <div className="h-0.5 bg-[#022a1a] rounded-full w-full"></div>
                <div className="h-0.5 bg-[#022a1a] rounded-full w-3/4 ml-auto"></div>
                <div className="h-0.5 bg-[#022a1a] rounded-full w-full"></div>
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 w-full max-w-md mx-auto flex flex-col justify-center relative z-10 py-6">
            
            {/* Header Brand Title Typography */}
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-0.5 relative z-20"
            >
              <h1 className="text-[42px] sm:text-[52px] font-black tracking-tighter leading-[0.9] text-[#022a1a] uppercase">
                Eco
              </h1>
              <h1 className="text-[42px] sm:text-[52px] font-black tracking-tighter leading-[0.9] text-[#022a1a] uppercase">
                Jaluzi
              </h1>
              <h1 className="text-[42px] sm:text-[52px] font-black tracking-tighter leading-[0.9] text-[#022a1a] uppercase">
                Sifatli va
              </h1>
              <h1 className="text-[42px] sm:text-[52px] font-black tracking-tighter leading-[0.9] text-[#022a1a] uppercase">
                Hamyonbob
              </h1>
            </motion.div>

            {/* Punctuation & Contact Block */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="mt-5 space-y-1 relative z-20"
            >
              <div className="text-2xl font-bold text-[#022a1a] ml-0.5 opacity-60">:</div>
              <div className="text-base sm:text-lg font-bold tracking-wide text-[#022a1a]/90 font-mono">
                +998940009977
              </div>
              <div className="text-base sm:text-lg font-bold text-[#022a1a]/80">
                @eco_jaluzishtor
              </div>
            </motion.div>

            {/* 3D Visual Composition (Glass Ribs & Glowing Sphere) positioned on the right */}
            <div className="absolute right-[-15px] sm:right-[-25px] top-1/2 -translate-y-1/2 w-[55%] max-w-[240px] h-[300px] sm:h-[360px] z-10 pointer-events-none">
              
              {/* Volumetric Bright Green Glowing Sphere behind glass */}
              <motion.div 
                animate={{ 
                  y: [-6, 6, -6],
                  scale: [1, 1.04, 1]
                }}
                transition={{ 
                  y: { duration: 4.5, repeat: Infinity, ease: "easeInOut" },
                  scale: { duration: 5.5, repeat: Infinity, ease: "easeInOut" }
                }}
                className="absolute right-3 top-10 w-28 h-28 sm:w-36 sm:h-36 rounded-full shadow-[0_0_70px_rgba(2,223,89,0.7)] z-0"
                style={{
                  background: 'radial-gradient(circle at 35% 35%, #5cff9c 0%, #05df59 30%, #034b22 70%, #011d0d 100%)'
                }}
              />

              {/* Vertical Ribbed Glass Overlay (Simulated vertical slats/jaluzi sheets) */}
              <div className="absolute inset-y-0 right-0 w-32 sm:w-40 z-10 flex border-x border-white/30 shadow-2xl rounded-sm overflow-hidden">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div 
                    key={i} 
                    className="flex-1 h-full border-r border-white/25 backdrop-blur-[4px]"
                    style={{
                      background: 'linear-gradient(90deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.0) 100%)'
                    }}
                  />
                ))}
              </div>

              {/* Liquid Metallic Chrome Bubble at Base */}
              <motion.div
                animate={{ y: [2, -2, 2] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute bottom-6 right-12 w-8 h-8 sm:w-10 sm:h-10 rounded-full z-20 shadow-[inset_-2px_-2px_6px_rgba(0,0,0,0.6),0_6px_14px_rgba(0,0,0,0.3)]"
                style={{
                  background: 'radial-gradient(circle at 30% 30%, #a2ff54 0%, #10b981 40%, #043b25 80%, #01150c 100%)'
                }}
              />

            </div>

          </div>

          {/* Bottom Fixed Kirish CTA Button */}
          <div className="w-full flex flex-col items-center justify-end z-20 pb-4 pt-2">
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="w-full flex justify-center pointer-events-auto"
            >
              <button
                onClick={onEnter}
                className="group flex items-center justify-between gap-12 bg-[#022a1a] text-[#a3f7bf] pl-8 pr-3 py-3 rounded-full w-full max-w-[290px] shadow-[0_15px_35px_rgba(2,42,26,0.35)] border border-white/10 transition-all duration-300 hover:scale-102 active:scale-95 cursor-pointer"
              >
                <span className="font-extrabold text-base tracking-wider uppercase ml-3">
                  Kirish
                </span>
                <div className="w-10 h-10 rounded-full bg-[#b5ff1a] text-[#022a1a] flex items-center justify-center transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 shadow-md">
                  <ArrowUpRight className="w-5 h-5 stroke-[3.5]" />
                </div>
              </button>
            </motion.div>
          </div>

        </div>
      )}

    </div>
  );
}
