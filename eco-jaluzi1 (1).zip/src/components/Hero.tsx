import React, { useState, useEffect, useRef } from 'react';
import { ArrowDown, Ruler, Eye } from 'lucide-react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import heroInterior from '../assets/images/hero_interior_1784368946795.jpg';

interface HeroProps {
  onMeasureClick: () => void;
  onExploreClick: () => void;
}

export default function Hero({ onMeasureClick, onExploreClick }: HeroProps) {
  // Animation states for the entrance sequence
  const [step, setStep] = useState(0);
  const [blindsOpenAmount, setBlindsOpenAmount] = useState(0.2); // 0 = closed, 1 = fully open

  // Mouse move parallax tracking using Motion values
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  // Springs for sifting motion smoothly
  const springX = useSpring(mouseX, { stiffness: 100, damping: 20 });
  const springY = useSpring(mouseY, { stiffness: 100, damping: 20 });

  // Parallax transform layers
  const backgroundTranslateX = useTransform(springX, [-0.5, 0.5], [-8, 8]);
  const backgroundTranslateY = useTransform(springY, [-0.5, 0.5], [-8, 8]);

  const lightTranslateX = useTransform(springX, [-0.5, 0.5], [-35, 35]);
  const lightTranslateY = useTransform(springY, [-0.5, 0.5], [-35, 35]);

  const heroRef = useRef<HTMLDivElement>(null);

  // 1. Entrance Sequence Timers
  useEffect(() => {
    // Step 0: Loading / Logo appears
    const timer1 = setTimeout(() => {
      setStep(1); // Step 1: Interior scene fades in
    }, 800);

    const timer2 = setTimeout(() => {
      setStep(2); // Step 2: Blinds slowly open
      // Animate blinds opening
      let currentOpen = 0.2;
      const openInterval = setInterval(() => {
        currentOpen += 0.05;
        if (currentOpen >= 0.75) {
          setBlindsOpenAmount(0.75);
          clearInterval(openInterval);
        } else {
          setBlindsOpenAmount(currentOpen);
        }
      }, 50);
    }, 1800);

    const timer3 = setTimeout(() => {
      setStep(3); // Step 3: Sunlight enters and text appears
    }, 2800);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  // Mouse move handler
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!heroRef.current) return;
    const rect = heroRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5; // range [-0.5, 0.5]
    const y = (e.clientY - rect.top) / rect.height - 0.5; // range [-0.5, 0.5]
    mouseX.set(x);
    mouseY.set(y);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <section
      id="home"
      ref={heroRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative w-full min-h-screen bg-brand-cream overflow-hidden flex flex-col justify-between pt-24"
      style={{ perspective: '1000px' }}
    >
      {/* Dotted background grid representing the user's mockup style */}
      <div 
        className="animate-dots absolute right-[4%] top-[8%] w-[120px] h-[120px] z-0 pointer-events-none select-none opacity-25" 
        style={{ 
          backgroundImage: 'radial-gradient(var(--color-brand-emerald) 1.4px, transparent 1.4px)', 
          backgroundSize: '16px 16px' 
        }} 
      />

      {/* Decorative ambient background curves and organic thread SVGs */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <svg viewBox="0 0 1440 800" fill="none" className="w-full h-full opacity-15">
          <path d="M-100,200 C300,100 500,400 900,300 C1300,200 1500,600 1600,500" stroke="#0A5C39" strokeWidth="1.5" strokeDasharray="5 5" opacity="0.3" />
          <path d="M-50,400 C400,300 600,600 1100,500 C1500,400 1600,700 1700,600" stroke="#0A5C39" strokeWidth="1" opacity="0.2" />
          <path d="M100,-50 C300,150 200,350 500,250 C800,150 700,450 950,350" stroke="#0A5C39" strokeWidth="1.2" opacity="0.25" />
          <path d="M100,0 C250,100 150,300 450,200 C750,100 650,400 900,300" stroke="#0A5C39" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.15" />
        </svg>
      </div>

      {/* 3D Visual Stage Container (Occupies full viewport in background) */}
      <div className="absolute inset-0 w-full h-full z-0 pointer-events-none">
        {/* Layer 1: Room Background with high quality soft opacity */}
        <motion.div
          className="absolute inset-0 w-[104%] h-[104%] -left-[2%] -top-[2%] bg-cover bg-center transition-opacity duration-1000"
          style={{
            backgroundImage: `url(${heroInterior})`,
            x: backgroundTranslateX,
            y: backgroundTranslateY,
            opacity: step >= 1 ? 0.35 : 0.05,
          }}
        />

        {/* Layer 2: Scenic Sunlight Beam Overlay */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-tr from-transparent via-amber-100/10 to-transparent mix-blend-color-dodge transition-opacity duration-[1500ms]"
          style={{
            x: lightTranslateX,
            y: lightTranslateY,
            opacity: step >= 3 ? (blindsOpenAmount > 0.1 ? blindsOpenAmount : 0.05) : 0,
          }}
        />
      </div>

      {/* Elegant Light Cream Ambient Vignette to keep typography perfectly legible */}
      <div className="absolute inset-0 bg-gradient-to-r from-brand-cream via-brand-cream/80 to-transparent z-10 w-full h-full pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-t from-brand-cream via-transparent to-brand-cream/10 z-10 w-full h-full pointer-events-none" />

      {/* Responsive Content Container */}
      <div className="relative z-20 w-full max-w-4xl mx-auto px-6 sm:px-12 flex flex-col items-center justify-center gap-12 pt-28 pb-12 flex-grow">
        
        {/* Left Column: Branding and Texts */}
        <div className="w-full flex flex-col items-center text-center gap-4 sm:gap-6">
          
          {/* Dynamic Drop-down Logo Wrapper */}
          <div className="animate-logo-wrap w-44 h-44 sm:w-52 sm:h-52 select-none perspective-[1000px] z-10">
            <div className="animate-logo-img w-full h-full rounded-full bg-brand-cream border-4 border-brand-emerald shadow-lg overflow-hidden flex items-center justify-center relative">
              <img 
                src="https://i.ibb.co/ddQsPr1/photo-2024-03-09-20-26-07-2.jpg" 
                alt="Eco Jaluzi logo" 
                className="absolute inset-0 w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80";
                }}
              />
            </div>
          </div>

          {/* Letter unfolding Wordmark */}
          <div translate="no" className="notranslate wordmark flex justify-center gap-1 sm:gap-2 select-none perspective-[900px] flex-wrap" aria-label="ECO JALUZI">
            {"ECO".split("").map((letter, index) => (
              <span
                key={`eco-${index}`}
                className="animate-slat inline-block font-archivo text-4xl sm:text-5xl md:text-6xl text-brand-emerald-dark tracking-wide leading-none"
                style={{ animationDelay: `${1.02 + index * 0.08}s` }}
              >
                {letter}
              </span>
            ))}
            <span className="w-4 sm:w-6" />
            {"JALUZI".split("").map((letter, index) => (
              <span
                key={`jaluzi-${index}`}
                className="animate-slat inline-block font-archivo text-4xl sm:text-5xl md:text-6xl text-brand-emerald-dark tracking-wide leading-none"
                style={{ animationDelay: `${1.30 + index * 0.08}s` }}
              >
                {letter}
              </span>
            ))}
          </div>

          {/* Animated tagline & grow divider */}
          <div className="animate-tagline font-ibm-mono text-[10px] sm:text-xs tracking-[0.24em] uppercase text-brand-emerald font-semibold opacity-0">
            Qulay hayot uchun aqlli yechimlar
          </div>
          <div className="animate-line w-0 h-[2px] bg-brand-emerald" />

          {/* Majestic Hero Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: step >= 3 ? 1 : 0, y: step >= 3 ? 0 : 30 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-brand-emerald-dark leading-tight"
          >
            Har bir derazaga — <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-emerald via-brand-emerald-light to-brand-emerald-dark">
              o‘ziga xos uslub.
            </span>
          </motion.h1>

          {/* Subheading */}
          <motion.p
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: step >= 3 ? 1 : 0, y: step >= 3 ? 0 : 25 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-sm sm:text-base text-brand-charcoal/80 font-light leading-relaxed font-sans max-w-xl"
          >
            Zamonaviy interyerlar uchun premium jaluzi va pardalar. Tabiiy materiallar, innovatsion avtomatika va mukammal montaj xizmati.
          </motion.p>

          {/* Hero CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: step >= 3 ? 1 : 0, y: step >= 3 ? 0 : 20 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-wrap items-center justify-center gap-4 mt-2"
          >
            <button
              onClick={onMeasureClick}
              className="shimmer bg-brand-emerald hover:bg-brand-emerald-light text-brand-cream font-semibold tracking-wider text-[10px] sm:text-xs uppercase px-6 sm:px-8 py-4 rounded-xl transition-all duration-300 shadow-lg flex items-center gap-2 hover:scale-[1.03]"
            >
              <Ruler className="w-4 h-4" />
              <span>Õlcham olishga buyurtma berish</span>
            </button>

            <button
              onClick={onExploreClick}
              className="bg-brand-beige/80 hover:bg-brand-beige text-brand-emerald-dark border border-brand-emerald/10 font-semibold tracking-wider text-[10px] sm:text-xs uppercase px-5 sm:px-6 py-4 rounded-xl transition-all duration-300 flex items-center gap-2 hover:scale-[1.03]"
            >
              <Eye className="w-4 h-4" />
              <span>Mahsulotlarni ko‘rish</span>
            </button>
          </motion.div>
        </div>
      </div>

      {/* Floating Scroll indicator */}
      <div className="hidden lg:flex absolute bottom-32 left-1/2 -translate-x-1/2 z-20 flex-col items-center gap-1 text-brand-emerald/60 text-[10px] uppercase tracking-widest pointer-events-none">
        <span>Explore the collection</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <ArrowDown className="w-4 h-4 text-brand-emerald-light mt-1" />
        </motion.div>
      </div>

      {/* Rising Green Wavy Footer with Premium Features from User's Mockup */}
      <div className="animate-footer w-full z-20 mt-auto pointer-events-auto">
        <svg className="block w-full h-12 sm:h-16 md:h-20 -mb-[1px]" viewBox="0 0 1440 100" preserveAspectRatio="none">
          <defs>
            <linearGradient id="beltGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0A5C39" />
              <stop offset="55%" stopColor="#07572F" />
              <stop offset="100%" stopColor="#04321C" />
            </linearGradient>
          </defs>
          <path 
            d="M0,55 C220,5 380,90 620,45 C860,5 980,85 1230,40 C1330,25 1400,32 1440,30 L1440,100 L0,100 Z" 
            fill="url(#beltGrad)" 
          />
        </svg>
        
        <div className="bg-gradient-to-br from-[#0a5c39] via-[#07572f] to-[#04321c] pb-8 pt-2">
          <div className="max-w-7xl mx-auto px-6 sm:px-12 flex flex-wrap justify-center gap-8 sm:gap-16">
            {/* Feature 1 */}
            <div className="animate-feature flex flex-col items-center gap-2 text-white group cursor-pointer" style={{ animationDelay: '2.55s' }}>
              <div className="w-11 h-11 border border-white/80 rounded-full flex items-center justify-center transition-transform duration-500 group-hover:rotate-[180deg]">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="w-5 h-5">
                  <path d="M12 3c-4 2-7 6-7 10a7 7 0 0 0 14 0c0-4-3-8-7-10Z" />
                  <path d="M12 21V9" />
                </svg>
              </div>
              <span className="font-ibm-mono text-[10px] tracking-wider uppercase text-center max-w-[110px] leading-tight">
                Ekologik toza
              </span>
            </div>

            {/* Feature 2 */}
            <div className="animate-feature flex flex-col items-center gap-2 text-white group cursor-pointer" style={{ animationDelay: '2.7s' }}>
              <div className="w-11 h-11 border border-white/80 rounded-full flex items-center justify-center transition-transform duration-500 group-hover:rotate-[180deg]">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="w-5 h-5">
                  <path d="M12 3l7 3v5c0 5-3.2 8.4-7 10-3.8-1.6-7-5-7-10V6l7-3Z" />
                  <path d="M9 12l2 2 4-4" />
                </svg>
              </div>
              <span className="font-ibm-mono text-[10px] tracking-wider uppercase text-center max-w-[110px] leading-tight">
                Premium sifat
              </span>
            </div>

            {/* Feature 3 */}
            <div className="animate-feature flex flex-col items-center gap-2 text-white group cursor-pointer" style={{ animationDelay: '2.85s' }}>
              <div className="w-11 h-11 border border-white/80 rounded-full flex items-center justify-center transition-transform duration-500 group-hover:rotate-[180deg]">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="w-5 h-5">
                  <circle cx="12" cy="12" r="3.4" />
                  <path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" />
                </svg>
              </div>
              <span className="font-ibm-mono text-[10px] tracking-wider uppercase text-center max-w-[110px] leading-tight">
                Yorug'likni boshqarish
              </span>
            </div>

            {/* Feature 4 */}
            <div className="animate-feature flex flex-col items-center gap-2 text-white group cursor-pointer" style={{ animationDelay: '3.0s' }}>
              <div className="w-11 h-11 border border-white/80 rounded-full flex items-center justify-center transition-transform duration-500 group-hover:rotate-[180deg]">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="w-5 h-5">
                  <path d="M4 11l8-7 8 7" />
                  <path d="M6 10v9h12v-9" />
                  <path d="M10 19v-5h4v5" />
                </svg>
              </div>
              <span className="font-ibm-mono text-[10px] tracking-wider uppercase text-center max-w-[110px] leading-tight">
                Energiya tejash
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
