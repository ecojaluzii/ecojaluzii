import React from 'react';
import { Sun, Shield, Ruler, Home, Award, Sparkles, Heart } from 'lucide-react';

export default function WhyUs() {
  const features = [
    {
      icon: <Award className="w-6 h-6 text-amber-500" />,
      title: 'Premium materiallar',
      description: 'Yevropadan keltirilgan, quyoshda so‘nmaydigan, ekologik toza va bardoshli matolar hamda tabiiy yog‘ochlardan foydalanamiz.'
    },
    {
      icon: <Sparkles className="w-6 h-6 text-brand-emerald" />,
      title: 'Individual dizayn',
      description: 'Har bir buyurtma mijoz xohishi, xonaning o‘ziga xosligi va oyna o‘lchamlaridan kelib chiqib, mutaxassislarimiz tomonidan loyihalanadi.'
    },
    {
      icon: <Ruler className="w-6 h-6 text-brand-emerald" />,
      title: 'Aniq o‘lchov va Maslahat',
      description: 'Bizning professional o‘lchovchimiz xonadagi yorug‘lik burchagini o‘rganib, siz uchun eng optimal yechimni taklif qiladi.'
    },
    {
      icon: <Home className="w-6 h-6 text-brand-emerald" />,
      title: 'Aniqlik va Sifat nazorati',
      description: 'Har bir jaluzi oyna o‘lchamiga millimetrigacha aniqlikda tayyorlanadi va qat’iy sifat nazoratidan o‘tadi.'
    },
    {
      icon: <Shield className="w-6 h-6 text-emerald-600" />,
      title: 'Uzoq muddatli sifat kafolati',
      description: 'Mexanizmlarimiz va materiallarimizga 1 yillik rasmiy kafolat beramiz. Har bir jaluzi ko‘p yillar davomida silliq va ishonchli ishlaydi.'
    },
    {
      icon: <Sun className="w-6 h-6 text-amber-500 animate-spin-slow" />,
      title: 'Zamonaviy smart yechimlar',
      description: 'Siz uchun "Aqlli uy" (Smart Home) tizimlariga mos keluvchi, masofadan boshqariladigan avtomatik va sensorli zamonaviy jaluzilar.'
    }
  ];

  return (
    <section id="why-us" className="py-24 bg-brand-cream border-b border-brand-emerald/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-12">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-brand-emerald/5 text-brand-emerald text-xs font-semibold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5" />
            <span>Bizning ustunliklarimiz</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brand-emerald-dark">
            Nega aynan <span translate="no" className="notranslate">ECO JALUZI</span>?
          </h2>
          <div className="h-1 w-12 bg-brand-emerald-light rounded" />
          <p className="text-brand-charcoal/60 font-light max-w-xl text-sm leading-relaxed">
            Biz shunchaki quyoshdan himoyalamaymiz, balki uyingiz yoki ofisingizda iliq shinamlik va hashamatli atmosfera yaratamiz.
          </p>
        </div>

        {/* Feature Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feat, i) => (
            <div
              key={i}
              className="group p-8 bg-brand-beige rounded-2xl border border-brand-emerald/5 hover:border-brand-emerald/20 transition-all duration-300 shadow-sm hover:shadow-md flex flex-col gap-4 hover:scale-[1.01]"
            >
              {/* Icon element wrapped in glassy circular frame */}
              <div className="w-12 h-12 rounded-xl bg-brand-cream border border-brand-emerald/10 flex items-center justify-center shadow-inner transition-transform group-hover:scale-110">
                {feat.icon}
              </div>

              {/* Text detail */}
              <div className="space-y-2">
                <h3 className="font-serif text-lg font-bold text-brand-emerald-dark group-hover:text-brand-emerald transition-colors">
                  {feat.title}
                </h3>
                <p className="text-brand-charcoal/70 text-xs font-light leading-relaxed">
                  {feat.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Stats Indicator */}
        <div className="mt-16 p-8 bg-brand-emerald rounded-3xl text-brand-cream text-center shadow-xl grid grid-cols-1 sm:grid-cols-3 gap-8 sm:divide-x sm:divide-brand-cream/15">
          <div className="space-y-1">
            <span className="font-display text-3xl sm:text-4xl font-bold text-amber-200">10,000+</span>
            <span className="text-xs uppercase tracking-wider font-light text-brand-beige/80 block">Tayyorlangan oyna jaluzilari</span>
          </div>
          <div className="space-y-1">
            <span className="font-display text-3xl sm:text-4xl font-bold text-amber-200">99.4%</span>
            <span className="text-xs uppercase tracking-wider font-light text-brand-beige/80 block">Mamnun mijozlar ulushi</span>
          </div>
          <div className="space-y-1">
            <span className="font-display text-3xl sm:text-4xl font-bold text-amber-200">1 yillik</span>
            <span className="text-xs uppercase tracking-wider font-light text-brand-beige/80 block">Rasmiy shartnomaviy kafolat</span>
          </div>
        </div>

      </div>
    </section>
  );
}
