import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { Product } from '../types';
import { Calculator, HelpCircle, ArrowRight, Sparkles, Check } from 'lucide-react';

interface PriceCalculatorProps {
  onOrderWithEstimate: (estimateSummary: string) => void;
}

export default function PriceCalculator({ onOrderWithEstimate }: PriceCalculatorProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [width, setWidth] = useState<number>(1.5);
  const [height, setHeight] = useState<number>(1.8);
  const [count, setCount] = useState<number>(1);
  const [needsInstallation, setNeedsInstallation] = useState<boolean>(true);
  const [calculatedPrice, setCalculatedPrice] = useState<number | null>(null);

  useEffect(() => {
    const fetchProds = () => {
      const activeProds = dbService.getProducts();
      setProducts(activeProds);
      if (activeProds.length > 0) {
        setSelectedProductId(activeProds[0].id);
      }
    };
    fetchProds();
    window.addEventListener('cms_update', fetchProds);
    return () => {
      window.removeEventListener('cms_update', fetchProds);
    };
  }, []);

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    const area = width * height;
    const pricePerSqm = product.pricePerSqm;
    let basePrice = area * pricePerSqm * count;

    // Optional subtle installation charge or discount logic
    // Here we treat standard installation as FREE as part of our premium campaign, or add a token fee
    // Let's specify that ECO JALUZI offers FREE premium installation, but toggle shows value
    if (needsInstallation) {
      // Free or token 20,000 UZS fee per window. Let's make it free and show "0 UZS (Bonus!)"
    }

    setCalculatedPrice(Math.round(basePrice));
  };

  const getEstimateSummary = () => {
    const product = products.find(p => p.id === selectedProductId);
    if (!product) return '';
    return `${product.name} (Eni: ${width}m, Bo‘yi: ${height}m, Soni: ${count} ta, O‘rnatish: ${needsInstallation ? 'Ha' : 'Yo‘q'}) — Taxminiy narx: ${calculatedPrice ? formatPrice(calculatedPrice) : ''}`;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', { style: 'currency', currency: 'UZS', maximumFractionDigits: 0 }).format(price);
  };

  return (
    <section id="calculator" className="py-24 bg-brand-cream border-b border-brand-emerald/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-12">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-brand-emerald/5 text-brand-emerald text-xs font-semibold uppercase tracking-wider">
            <Calculator className="w-3.5 h-3.5" />
            <span>Budjet rejalashtirish</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brand-emerald-dark">
            Smart narx hisoblagich.
          </h2>
          <div className="h-1 w-12 bg-brand-emerald-light rounded" />
          <p className="text-brand-charcoal/60 font-light max-w-xl text-sm leading-relaxed">
            Derazalaringiz o‘lchamlarini kiriting va bir soniyada taxminiy narxlarni bilib oling. Shaffof hisob-kitob va yashirin to‘lovlarsiz.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start max-w-5xl mx-auto">
          
          {/* Left panel: Input parameters */}
          <form onSubmit={handleCalculate} className="lg:col-span-7 bg-brand-beige p-6 sm:p-8 rounded-3xl border border-brand-emerald/10 shadow-sm space-y-5">
            <h3 className="font-serif text-lg font-bold text-brand-emerald-dark border-b border-brand-emerald/10 pb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-brand-emerald-light" />
              <span>O‘lchamlarni kiriting</span>
            </h3>

            {/* Parameter: Blinds select */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-brand-emerald-dark uppercase tracking-wider block">Jaluzi turi</label>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  setCalculatedPrice(null); // Reset calculated states on change
                }}
                className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} — {formatPrice(p.pricePerSqm)} / m²
                  </option>
                ))}
              </select>
            </div>

            {/* Parameter: Width & Height inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-brand-emerald-dark uppercase tracking-wider block">Deraza eni (Metrda)</label>
                <input
                  type="number"
                  step="0.05"
                  min="0.2"
                  max="5.0"
                  value={width}
                  onChange={(e) => {
                    setWidth(parseFloat(e.target.value) || 0);
                    setCalculatedPrice(null);
                  }}
                  className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald font-semibold"
                  placeholder="Masalan: 1.5"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-brand-emerald-dark uppercase tracking-wider block">Deraza bo‘yi (Metrda)</label>
                <input
                  type="number"
                  step="0.05"
                  min="0.2"
                  max="5.0"
                  value={height}
                  onChange={(e) => {
                    setHeight(parseFloat(e.target.value) || 0);
                    setCalculatedPrice(null);
                  }}
                  className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald font-semibold"
                  placeholder="Masalan: 1.8"
                  required
                />
              </div>
            </div>

            {/* Parameter: Windows count & Installation checkbox */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center pt-2">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-brand-emerald-dark uppercase tracking-wider block">Derazalar soni (dona)</label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={count}
                  onChange={(e) => {
                    setCount(parseInt(e.target.value) || 1);
                    setCalculatedPrice(null);
                  }}
                  className="w-full bg-brand-cream border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald font-semibold"
                  required
                />
              </div>

              {/* Install Checkbox */}
              <div className="flex items-center h-full pt-4">
                <label className="relative flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={needsInstallation}
                    onChange={(e) => {
                      setNeedsInstallation(e.target.checked);
                      setCalculatedPrice(null);
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-5 h-5 bg-brand-cream border border-brand-emerald/20 peer-checked:bg-brand-emerald peer-checked:border-brand-emerald rounded-md flex items-center justify-center transition-all">
                    {needsInstallation && <Check className="w-3.5 h-3.5 text-brand-cream" />}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-brand-emerald-dark">O‘rnatish xizmati</span>
                    <span className="text-[10px] text-brand-charcoal/50"></span>
                  </div>
                </label>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
            >
              <span>Taxminiy narxni hisoblash</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Right panel: Live calculated estimates */}
          <div className="lg:col-span-5 flex flex-col justify-between h-full bg-brand-cream rounded-3xl border border-brand-emerald/10 p-6 sm:p-8 shadow-sm text-center">
            {calculatedPrice === null ? (
              <div className="py-16 flex flex-col items-center justify-center gap-4">
                <div className="w-16 h-16 rounded-full bg-brand-beige flex items-center justify-center text-brand-emerald/30 border border-brand-emerald/5 animate-pulse">
                  <Calculator className="w-8 h-8" />
                </div>
                <h4 className="font-serif text-base font-bold text-brand-emerald-dark">Hisob-kitobni boshlash</h4>
                <p className="text-xs text-brand-charcoal/50 font-light max-w-xs">
                  Chap tomondagi oyna o‘lchamlari va jaluzi turini tanlab, hisoblash tugmasini bosing.
                </p>
              </div>
            ) : (
              <div className="space-y-6 py-6">
                <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                  <Check className="w-7 h-7" />
                </div>
                
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-widest text-brand-charcoal/50 font-bold block">Taxminiy narx tayyor.</span>
                  <span className="text-3xl font-extrabold text-brand-emerald font-display block">
                    {formatPrice(calculatedPrice)}
                  </span>
                  <span className="text-[11px] text-brand-charcoal/40 block">Barcha soliqlar va material narxlari kiritilgan</span>
                </div>

                <div className="p-4 bg-brand-beige rounded-xl border border-brand-emerald/5 text-xs text-left text-brand-charcoal/70 leading-relaxed font-light space-y-1.5">
                  <div className="flex justify-between font-semibold border-b border-brand-emerald/5 pb-1">
                    <span>O‘lcham maydoni:</span>
                    <span>{(width * height * count).toFixed(2)} m²</span>
                  </div>
                  <p className="pt-1.5 text-[10px]">
                    * Ushbu kalkulyatordagi narx taxminiy hisoblanadi. Mutaxassisimiz aniq narxni tasdiqlash uchun siz bilan bog‘lanadi.
                  </p>
                </div>

                <button
                  onClick={() => onOrderWithEstimate(getEstimateSummary())}
                  className="w-full py-4 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
                >
                  <span>Buyurtmani rasmiylashtirish</span>
                  <ArrowRight className="w-4 h-4 text-amber-200" />
                </button>
              </div>
            )}

            <div className="border-t border-brand-emerald/5 pt-4 text-[10px] text-brand-charcoal/40 flex items-center justify-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-brand-emerald/40" />
              <span>Aniq narx o‘lchovdan so‘ng belgilanadi</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
