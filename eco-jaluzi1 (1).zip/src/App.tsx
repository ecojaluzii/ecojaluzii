import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MainCatalogsGateway from './components/MainCatalogsGateway';
import ProductDetailModal from './components/ProductDetailModal';
import WhyUs from './components/WhyUs';
import OurProcess from './components/OurProcess';
import OrderForm from './components/OrderForm';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';
import IntroScreen from './components/IntroScreen';
import AIAssistant from './components/AIAssistant';
import CustomerVideoReviews from './components/CustomerVideoReviews';
import { dbService } from './services/db';
import { Product } from './types';
import { ShieldAlert, X, Eye, Lock, ArrowRight } from 'lucide-react';

export default function App() {
  const [hasEntered, setHasEntered] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Increment visit count on load
    try {
      dbService.incrementVisitCount();
    } catch (e) {
      console.error(e);
    }

    // Initialize Telegram WebApp if available
    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg) {
        tg.ready();
        tg.expand();
      }
    } catch (e) {
      console.error('Telegram WebApp initialization error:', e);
    }
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [orderNotes, setOrderNotes] = useState<string>('');
  
  // Admin CMS States
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Handle viewing detailed info modal
  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product);
  };

  // Handle direct ordering from product card or modal
  const handleOrderProduct = (product: Product) => {
    setOrderNotes(`Men uchun o‘lcham olishga buyurtma berish: [${product.name}] modeli.`);
    setSelectedProduct(null); // Close modal if open

    // Smooth scroll to order form
    const formSection = document.querySelector('#order-form');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Handle consultations
  const handleConsultProduct = (product: Product) => {
    setSelectedProduct(null);
    window.dispatchEvent(new CustomEvent('open_ai_chat', { 
      detail: `${product.name} jaluzisi haqida batafsil ma'lumot va maslahat bering` 
    }));
  };

  // Handle dynamic quote from 3D Designer or Price Calculator
  const handleQuoteWithSummary = (summary: string) => {
    setOrderNotes(`Dizayn va kalkulyatordan olingan parametrlar: \n- ${summary}`);
    
    const formSection = document.querySelector('#order-form');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Admin login check
  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === 'SXUK546KV') {
      setShowAdminPanel(true);
      setShowAdminLogin(false);
      setLoginError('');
      setPasswordInput('');
    } else {
      setLoginError('Noto‘g‘ri parol! Iltimos, qayta urinib ko‘ring.');
    }
  };

  // Handle ordering from portfolio project
  const handleOrderPortfolioProject = (project: any) => {
    setOrderNotes(`Men uchun o‘rnatilgan [${project.title}] (${project.category}) loyihasidagi kabi jaluziga o‘lchov olish.`);
    const formSection = document.querySelector('#order-form');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Handle ordering from customer video reviews
  const handleOrderCustomerReview = (note?: string) => {
    if (note) {
      setOrderNotes(note);
    }
    const formSection = document.querySelector('#order-form');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToOrderForm = () => {
    const formSection = document.querySelector('#order-form');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToPortfolio = () => {
    const portSection = document.querySelector('#portfolio');
    if (portSection) {
      portSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToProducts = () => {
    const prodSection = document.querySelector('#products');
    if (prodSection) {
      prodSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleEnter = () => {
    setHasEntered(true);
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'instant' });
    }, 10);
  };

  if (!hasEntered) {
    return <IntroScreen onEnter={handleEnter} />;
  }

  return (
    <div className="min-h-screen bg-brand-cream text-brand-charcoal selection:bg-brand-emerald selection:text-brand-cream relative">
      
      {/* 1. Header Navigation */}
      <Navbar
        onAdminClick={() => setShowAdminLogin(true)}
        onOrderClick={handleScrollToOrderForm}
        isAdmin={showAdminPanel}
      />

      {/* 2. Interactive 3D Parallax Hero */}
      <Hero
        onMeasureClick={handleScrollToOrderForm}
        onExploreClick={handleScrollToProducts}
      />

      {/* 3. Asosiy 2 ta Katalog Bo'limi (Katalog Mahsulotlar & Qilingan Ishlar) */}
      <MainCatalogsGateway
        onViewProduct={handleViewProduct}
        onOrderProduct={handleOrderProduct}
        onOrderProject={handleOrderPortfolioProject}
      />

      {/* 4. Why ECO JALUZI Feature overview */}
      <WhyUs />

      {/* 8. Service timeline step tracker */}
      <OurProcess />

      {/* 9. Mijozlar Video Otzivlari (3 ta ketma-ket yonma-yon video sharh) */}
      <CustomerVideoReviews onOrderClick={handleOrderCustomerReview} />

      {/* AI Assistant Section */}
      <AIAssistant />

      {/* 10. Client Booking Lead Capture Form */}
      <OrderForm prefilledNotes={orderNotes} />

      {/* 11. Footer details */}
      <Footer />

      {/* ----------------- POP-UPS & MODALS ----------------- */}

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onOrder={handleOrderProduct}
          onConsult={handleConsultProduct}
        />
      )}

      {/* Administrative CMS Lock Login Screen */}
      {showAdminLogin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-brand-charcoal/60 backdrop-blur-md">
          <div className="absolute inset-0" onClick={() => setShowAdminLogin(false)} />
          
          <div className="relative bg-brand-cream w-full max-w-md rounded-2xl p-6 sm:p-8 shadow-2xl border border-brand-emerald/10 z-10 space-y-6">
            <button
              onClick={() => setShowAdminLogin(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-brand-beige text-brand-charcoal/60 hover:text-brand-charcoal transition-all"
              title="Yopish"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-xl bg-brand-emerald/10 text-brand-emerald flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-brand-emerald-dark">Tizimga kirish</h3>
              <p className="text-xs text-brand-charcoal/50 font-light">Tarkibni o‘zgartirish uchun parolingizni kiriting</p>
            </div>

            <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Admin paroli</label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value);
                    setLoginError('');
                  }}
                  placeholder="Parolni kiriting"
                  className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald text-center tracking-widest font-bold"
                />
              </div>

              {loginError && (
                <p className="text-xs text-red-600 font-semibold text-center bg-red-50 py-2 rounded-lg border border-red-100 flex items-center justify-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  <span>{loginError}</span>
                </p>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5"
              >
                <span>Tasdiqlash</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Full-screen CMS Boshqaruv Markazi Panel */}
      {showAdminPanel && (
        <AdminPanel onClose={() => setShowAdminPanel(false)} />
      )}

    </div>
  );
}
