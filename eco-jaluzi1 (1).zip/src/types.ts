export interface Product {
  id: string;
  name: string;
  description: string;
  material: string;
  availableColors: string[];
  pricePerSqm: number;
  image: string;
  mediaType?: 'image' | 'video';
  videoUrl?: string;
  category: string;
  benefits?: string[];
  installationInfo?: string;
}

export interface PortfolioProject {
  id: string;
  title: string;
  category: string;
  image: string;
  mediaType?: 'image' | 'video';
  videoUrl?: string;
  description: string;
}

export interface ProcessStep {
  id: string;
  stepNumber: string;
  title: string;
  description: string;
  mediaType?: 'image' | 'video';
  mediaUrl?: string;
  image?: string;
  videoUrl?: string;
  iconName?: string;
}

export interface Order {
  id: string;
  name: string;
  phone: string;
  address: string;
  typeOfBlinds: string;
  numberOfWindows: number;
  comments: string;
  date: string;
  status: 'Kutilmoqda' | 'Bogʻlanildi' | 'Bajarildi';
}

export interface ConsultationRequest {
  id: string;
  name: string;
  phone: string;
  comments?: string;
  date: string;
  status: 'Kutilmoqda' | 'Bogʻlanildi' | 'Bajarildi';
}

export interface AdminConfig {
  phoneNumber: string;
  telegramLink: string;
  instagramLink: string;
  facebookLink?: string;
  adminTelegram: string;
  address: string;
  telegramBotToken?: string;
  telegramChatId?: string;
  customerBotToken?: string;
  customerChatId?: string;
  factoryVideoUrl?: string;
  factoryVideoPoster?: string;
}
