import { PortfolioProject } from '../types';

export interface DikeyProjectItem extends PortfolioProject {
  roomType?: string;
  fabricType?: string;
}

export const DIKEY_GALLERY_PROJECTS: DikeyProjectItem[] = [
  {
    id: "dikey-real-1",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№1)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/zTTkNdF2/photo-2026-08-28-11-39-23.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-2",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№2)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/JFRMRW0F/photo-2026-08-28-11-39-22.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-3",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№3)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/67p0Jpgc/photo-2026-08-28-11-39-20.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-4",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№4)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/LdKdNfPn/photo-2026-08-28-11-39-19.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-5",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№5)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/SDYrxK1S/photo-2026-08-28-11-39-18.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-6",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№6)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/HT4NrvfP/photo-2026-08-28-11-39-17.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-7",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№7)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/DPj0Qxy5/photo-2026-08-28-11-39-15.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-8",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№8)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/HpfYkL2y/photo-2026-08-28-11-39-14.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-9",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№9)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/b5WF4kt6/photo-2026-08-28-11-39-13.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-10",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№10)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/CKwWqtV2/photo-2026-08-28-11-39-11.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-11",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№11)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/bgk3sMym/photo-2026-08-28-11-39-10.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-12",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№12)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/7dLKRG0b/photo-2026-08-28-11-39-09.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-13",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№13)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/yFJ9LwFV/photo-2026-08-28-11-39-07.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-14",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№14)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/9mY09GHM/photo-2026-06-06-17-47-56-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-15",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№15)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/NdPm66DW/photo-2026-08-28-11-39-06.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-16",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№16)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/DfJJfRM2/photo-2026-08-28-11-38-59.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-17",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№17)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/MDHLVHMG/photo-2026-08-28-11-38-57.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-18",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№18)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Kxpk553w/photo-2026-08-28-11-38-56.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-19",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№19)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/d4F14Wy4/photo-2026-08-28-11-38-55.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-20",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№20)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/twnH7xH8/photo-2026-07-13-17-00-56-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-21",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№21)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/fVhD0Rcq/photo-2026-07-13-17-00-56-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-22",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№22)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/vyZ56vg/photo-2026-07-13-17-00-56.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-23",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№23)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/8gbV9P5m/photo-2026-07-13-17-00-55-7.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-24",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№24)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/yFw6x2ft/photo-2026-07-13-17-00-55-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-25",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№25)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/1SvqtWv/photo-2026-07-13-17-00-55-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-26",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№26)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/bD0VD8C/photo-2026-07-13-17-00-55-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-27",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№27)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/KxBQQ0Vv/photo-2026-07-13-17-00-55-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-28",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№28)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Zzr2PKTm/photo-2026-07-13-17-00-55-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-29",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№29)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/WpRJBvVk/photo-2026-07-07-11-53-34.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-30",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№30)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/C50jK8dn/photo-2026-06-06-18-05-54.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-31",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№31)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/LWmMZyc/photo-2026-06-06-17-56-05.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-32",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№32)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/gM3JbnSc/photo-2026-04-29-09-42-00-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-33",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№33)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/DgRf5RjH/photo-2026-04-29-09-42-00.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-34",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№34)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/08Tjg9y/photo-2026-04-29-09-40-44-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-35",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№35)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/rRF1K2P1/photo-2026-04-29-09-40-44.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-36",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№36)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/C5Gy0gvy/photo-2026-04-29-09-34-49.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-37",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№37)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/8DB1Y0yG/photo-2026-04-29-09-34-48.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-38",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№38)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/pvtx8Ygm/photo-2026-04-29-11-21-46.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-39",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№39)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/kVyH2d4N/photo-2026-04-29-11-21-10.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-40",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№40)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/wN2PF6RD/photo-2026-04-29-11-19-54.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-41",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№41)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/S77mtGFd/photo-2025-08-15-14-32-10-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-42",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№42)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/dsNMwQJM/photo-2025-08-15-14-32-10-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-43",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№43)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Mk1dVHHz/photo-2025-08-15-14-32-10-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-44",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№44)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/fVjfpXd1/photo-2025-08-15-14-32-10.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-45",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№45)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/q3fwvqvX/photo-2025-08-15-14-32-09-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-46",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№46)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/jPKGW7pN/photo-2025-08-15-14-32-09-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-47",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№47)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/6JRR4JmF/photo-2025-08-15-14-32-09.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-48",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№48)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/TBPW853C/photo-2025-04-22-15-19-51-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-49",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№49)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/TxP5Sky7/photo-2025-04-22-15-19-51-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-50",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№50)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/3YyFpKrG/photo-2025-04-22-15-19-51-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-51",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№51)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/BKgpbxFp/photo-2025-04-22-15-19-51-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-52",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№52)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Knnrmzx/photo-2025-04-22-15-19-51.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-53",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№53)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/mFRzrs3f/photo-2025-09-03-11-12-55-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-54",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№54)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/pvG4Rh7C/photo-2025-09-03-11-12-55-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-55",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№55)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/dJWTwjsV/photo-2025-09-03-11-12-55-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-56",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№56)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/KxMT4jLY/photo-2025-09-03-11-12-55-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-57",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№57)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/svVPgMDq/photo-2025-09-03-11-12-55-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-58",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№58)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/1Yv0Sw5D/photo-2025-09-03-11-12-55.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-59",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№59)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Df3JgfrM/photo-2025-09-03-11-12-54.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-60",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№60)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/vxb2r4J8/photo-2025-09-03-11-12-53-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-61",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№61)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/5fbNc49/photo-2025-09-03-11-12-53-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-62",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№62)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Nn3F9Zpq/photo-2025-09-03-17-49-14-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-63",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№63)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/7NdD1BXt/photo-2025-09-03-11-12-52-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-64",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№64)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/0yRRtq67/photo-2025-12-10-18-24-36-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-65",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№65)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/N2myZ7HB/photo-2025-12-10-18-24-36-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-66",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№66)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/ksKmYWf7/photo-2025-12-10-18-24-36-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-67",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№67)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/23x32rr4/photo-2025-12-10-18-24-35-8.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-68",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№68)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/hF8WHXM2/photo-2025-12-10-18-24-35-7.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-69",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№69)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/s9ks7Wtv/photo-2025-12-10-18-24-35-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-70",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№70)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/BH7q76bL/photo-2025-12-10-18-24-35-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-71",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№71)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/6cb6jCZc/photo-2025-12-10-18-23-47-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-72",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№72)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/CKHgsR6w/photo-2025-12-10-18-23-47-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-73",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№73)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/934GS38H/photo-2025-12-10-18-23-47-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-74",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№74)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/27xY9k6Y/photo-2025-12-10-18-23-47-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-75",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№75)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Tjskkym/photo-2025-12-10-18-23-47.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-76",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№76)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/jkyT95cB/photo-2025-12-10-18-23-46.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-77",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№77)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/BH15dJpy/photo-2025-12-10-18-23-45.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-78",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№78)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/CgKm9gn/photo-2025-12-10-18-23-44-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  }
];
