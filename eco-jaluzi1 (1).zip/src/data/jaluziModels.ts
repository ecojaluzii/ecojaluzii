import { Product, PortfolioProject } from '../types';

export interface JaluziCategoryModel {
  id: string;
  keyword: string;
  categoryName: string;
  icon: string;
  badge: string;
  description: string;
  models: Product[];
}

export const JALUZI_MODELS_BY_CATEGORY: Record<string, Product[]> = {
  plisse: [
    {
      id: 'jaluzi-plisse-1',
      name: 'Klassik 20mm Plisse (Akkordeon) Jaluzi',
      description: 'Oyna romiga zich o‘rnatiluvchi, pastdan yuqoriga va yuqoridan pastga 2 tomonlama ochiladigan zamonaviy plisse tizimi.',
      material: 'Antistatik chang qaytaruvchi gofre to‘qima',
      availableColors: ['Oq marvarid', 'Och krem', 'Klassik bej', 'Grafit', 'Sut rang'],
      pricePerSqm: 190000,
      image: 'https://i.ibb.co/wZbGNGPR/photo-2026-01-27-14-02-21-2.jpg',
      category: 'Plisse jaluzi',
      benefits: ['2 tomonlama (pastdan va yuqoridan) ochilish', 'Oyna ochilganda xalaqit bermaydi', 'Chang va namlikka chidamli'],
      installationInfo: 'Deraza qanoti romiga mahkamlanadi.'
    },
    {
      id: 'jaluzi-plisse-2',
      name: 'Mansarda va Qiya Oynalar Uchun Plisse',
      description: 'Qiya, uchburchak va nostandart mansarda oynalari uchun maxsus trossli osilib qolmaydigan plisse tizimi.',
      material: 'Yevropa termo-himoyali zich gofre matosi',
      availableColors: ['Klassik bej', 'Oq', 'Zangori pastel', 'Kulrang'],
      pricePerSqm: 210000,
      image: 'https://i.ibb.co/YBwjyH24/photo-2024-03-08-10-46-04.jpg',
      category: 'Plisse jaluzi',
      benefits: ['Har qanday nostandart shakldagi oynalarga tushadi', 'Qiya holatda ham osilib ketmaydi', 'Kuchli issiqlik qaytarish'],
      installationInfo: 'Maxsus yo‘naltiruvchi trosslar bilan montaj qilinadi.'
    },
    {
      id: 'jaluzi-plisse-3',
      name: 'Day & Night (Kun va Tun) Ikki Qavatli Plisse',
      description: 'Bitta tizimda 2 xil mato: kunduzi shaffof tyul matosi, kechasi esa 100% zich qorong‘ulashtiruvchi blackout mato.',
      material: 'Kombinatsiyalangan tyul va blackout gofre matolari',
      availableColors: ['Oq + Bej', 'Oq + Grafit', 'Krem + Shokolad', 'Marvarid + Antratsit'],
      pricePerSqm: 240000,
      image: 'https://i.ibb.co/S4kfX91J/photo-2026-09-03-21-24-41.jpg',
      category: 'Plisse jaluzi',
      benefits: ['2 tasi 1 da: tyul va qorong‘i parda', 'Yorug‘likni istalgan darajada sozlash', 'O‘zgacha premium dizayn'],
      installationInfo: 'Oyna romiga to‘liq qoplanadi.'
    },
    {
      id: 'jaluzi-plisse-4',
      name: '100% Blackout Termo Plisse Jaluzi',
      description: 'Ichki tomoni alyumin folga qatlami bilan qoplangan, yozda issiqlikni xonaga kiritmaydigan 100% qorong‘ulashtiruvchi plisse.',
      material: '3 qavatli alyuminiylashgan termo-blackout mato',
      availableColors: ['To‘q kulrang', 'Bej', 'Qora mat', 'Oq qor'],
      pricePerSqm: 220000,
      image: 'https://i.ibb.co/x4L5T8p/photo-2026-09-03-21-24-37.jpg',
      category: 'Plisse jaluzi',
      benefits: ['100% to‘liq qorong‘ulik', 'Yozda 5-7°C xonani salqin saqlaydi', 'Shovqinni pasaytiruvchi termo qatlam'],
      installationInfo: 'Yotoqxona va kinozallar uchun ayni muddao.'
    },
    {
      id: 'jaluzi-plisse-5',
      name: 'Plisse 22DX Original Gofre Jaluzi',
      description: 'Turkiya va Germaniya texnologiyasida tayyorlangan, elastik akkordeon shaklini 10 yil yo‘qotmaydigan yuqori sifatli plisse.',
      material: '22DX maxsus to‘qimali antistatik poliester',
      availableColors: ['22DX-102 Bej', '22DX-503 Kulrang', '22DX-801 Oq', '22DX-802 Krem'],
      pricePerSqm: 200000,
      image: 'https://i.ibb.co/yFfWskm6/photo-2026-05-04-14-50-40.jpg',
      category: 'Plisse jaluzi',
      benefits: ['10 yil akkordeon shakli buzilmaydi', 'Yuvish va tozalash juda oson', 'Estetik jihatdan nafis'],
      installationInfo: 'Oyna ramkasiga bevosita o‘rnatiladi.'
    },
    {
      id: 'jaluzi-plisse-6',
      name: 'Arka va Dumaloq Oynalar Uchun Figurali Plisse',
      description: 'Yarim doira (arka) va doirasimon gumbazli oynalar uchun maxsus yelpig‘ich shaklida ochiladigan plisse tizimi.',
      material: 'Maxsus yelpig‘ich shaklida buklanuvchi termo-mato',
      availableColors: ['Oq', 'Krem', 'Och sariq', 'Klassik bej'],
      pricePerSqm: 250000,
      image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
      category: 'Plisse jaluzi',
      benefits: ['Arka shaklidagi derazalar uchun ideal yechim', 'Yelpig‘ichsimon nafis harakat', 'Interyerga hashamat beradi'],
      installationInfo: 'Arka oyna markaziga fiksator bilan qotiriladi.'
    }
  ],

  combo: [
    {
      id: 'jaluzi-combo-1',
      name: 'Klassik Kun va Tun (Zebra) Combo Jaluzi',
      description: 'Shaffof va qorong‘i mato chiziqlarining navbatma-navbat almashinuvi orqali xonaga kiruvchi yorug‘likni bir harakatda sozlash.',
      material: 'Zich tolali antistatik mato va alyuminiy kasset tizimi',
      availableColors: ['Klassik bej', 'Oq marvarid', 'Shokolad', 'Och kulrang', 'Antratsit'],
      pricePerSqm: 165000,
      image: 'https://i.ibb.co/VY4Hk2by/photo-2024-09-06-12-32-19.jpg',
      category: 'Combo jaluzi',
      benefits: ['Kun-tun yorug‘lik nazorati', 'Chang va kirlanishdan himoya qiluvchi qoplama', 'Har qanday interyerga mos zamonaviy ko‘rinish'],
      installationInfo: 'Deraza ochiladigan qanotiga yoki teshigiga o‘rnatiladi.'
    },
    {
      id: 'jaluzi-combo-2',
      name: 'Naqshli Relyefli Lux Combo Jaluzi',
      description: 'Yangi binodagi zamonaviy oshxona va xonalar oynalari uchun relyefli nafis to‘qimali Combo jaluzilari.',
      material: 'Maxsus relyefli to‘qimali poliester matosi',
      availableColors: ['Oltin-krem', 'Oq', 'Shampan', 'Kofe'],
      pricePerSqm: 175000,
      image: 'https://i.ibb.co/j95KQNG0/photo-2026-02-27-10-40-43.jpg',
      category: 'Combo jaluzi',
      benefits: ['O‘zgacha nafis relyefli dizayn', 'Yorug‘likni yumshoq taratish', 'Oson artib tozalash'],
      installationInfo: 'Oyna romiga yoki devorga mahkamlanadi.'
    },
    {
      id: 'jaluzi-combo-3',
      name: 'Kassetali Mini Combo (Plastik Oyna Romiga)',
      description: 'Yon tomonlarida yo‘naltiruvchi alyumin lentalar bilan oyna ochilganda va shamollatish rejimida tushib ketmaydigan kassetali combo.',
      material: 'Kassetali alyumin korpus va antistatik mato',
      availableColors: ['Oq', 'Krem', 'Jigarrang', 'Antratsit'],
      pricePerSqm: 185000,
      image: 'https://i.ibb.co/zTfLD9Fv/photo-2026-09-01-12-13-43.jpg',
      category: 'Combo jaluzi',
      benefits: ['Oyna ochilganda shamolda qimirlamaydi', 'Kassetasi changdan asraydi', 'Ixcham va qulay'],
      installationInfo: 'Plastik oyna ramkasiga burg‘ulashsiz yoki o‘z rezbasi bilan o‘rnatiladi.'
    },
    {
      id: 'jaluzi-combo-4',
      name: '100% Blackout Zebra Combo Jaluzi',
      description: 'Zich qora qatlamli chiziqlari yordamida yopiq holatda xonani butunlay qorong‘i qiluvchi maxsus combo jaluzi.',
      material: '3 qavatli zich qorong‘ulashtiruvchi combo tola',
      availableColors: ['To‘q kulrang', 'Qora', 'To‘q bej', 'Grafit'],
      pricePerSqm: 195000,
      image: 'https://i.ibb.co/jvPzG1Dd/photo-2026-09-03-21-24-44.jpg',
      category: 'Combo jaluzi',
      benefits: ['100% quyosh nuri to‘silishi', 'Chiziqli qulay boshqaruv', 'Konditsioner yukini kamaytiradi'],
      installationInfo: 'Devor yoki oyna romiga qotiriladi.'
    }
  ],

  roller: [
    {
      id: 'jaluzi-roller-1',
      name: '100% Blackout Roller (Rulonli) Parda',
      description: 'Yotoqxona va kino zallari oynalariga o‘rnatilgan 100% Blackout quyosh nurini to‘suvchi maxsus rulonli jaluzi.',
      material: '3 qavatli Yevropa Blackout matosi',
      availableColors: ['Qora mat', 'To‘q kulrang', 'Antratsit', 'Bej', 'Oq'],
      pricePerSqm: 160000,
      image: 'https://i.ibb.co/ksV062W4/photo-2025-10-11-10-42-27.jpg',
      category: 'Roller jaluzi',
      benefits: ['Xonani 100% to‘liq qorong‘ulashtirish', 'Oson tozalanish va yuvilish', 'Ixcham zamonaviy dizayn'],
      installationInfo: 'Deraza ochilish qismiga bevosita o‘rnatiladi.'
    },
    {
      id: 'jaluzi-roller-2',
      name: 'Teksturali Zig‘ir (Linen) Rulonli Parda',
      description: 'Tabiiy mato to‘qimasiga ega, quyosh nurini muloyim va iliq qilib xonaga o‘tkazuvchi ekologik rulonli parda.',
      material: 'Tabiiy zig‘ir va poliester aralashmali to‘qima',
      availableColors: ['Tabiiy bej', 'Qum rang', 'Sutli krem', 'Och zaytun'],
      pricePerSqm: 155000,
      image: 'https://i.ibb.co/wZbGNGPR/photo-2026-01-27-14-02-21-2.jpg',
      category: 'Roller jaluzi',
      benefits: ['Iliq va shinam atmosfera', '100% ekologik toza material', 'Oson boshqariluvchi zanjir'],
      installationInfo: 'Shiftga yoki oyna romiga o‘rnatiladi.'
    },
    {
      id: 'jaluzi-roller-3',
      name: 'Quyosh Qaytaruvchi Sunscreen Roller Jaluzi',
      description: 'Ofis va ish xonalarida monitorga quyosh jilosi tushmasligi uchun maxsus mikrotexnolgiya asosida to‘qilgan ekranli parda.',
      material: 'Poliefir va PVX qoplamali Screen to‘r mato',
      availableColors: ['Kulrang grafit', 'Kumush', 'Oq-bej', 'Qora'],
      pricePerSqm: 170000,
      image: 'https://i.ibb.co/x4L5T8p/photo-2026-09-03-21-24-37.jpg',
      category: 'Roller jaluzi',
      benefits: ['Tashqi manzarani ko‘rib turish imkoniyati', 'Quyoshning ko‘zni qamashtiruvchi nurini to‘sish', 'Ofislar uchun ideal'],
      installationInfo: 'Devor yoki deraza tepasiga mustahkam kranis bilan mahkamlanadi.'
    }
  ],

  wood: [
    {
      id: 'jaluzi-wood-1',
      name: 'Hashamatli Tabiiy Yog‘och (Wood) 50mm Jaluzi',
      description: 'Tabiiy eman yog‘ochidan ishlangan olijanob va nufuzli ko‘rinishga ega 50mm premium gorizontal jaluzi.',
      material: '100% Tabiiy Eman va Bambuk yog‘ochi (50mm)',
      availableColors: ['To‘q Yong‘oq', 'Klassik eman', 'Och jigarrang', 'Oq mat'],
      pricePerSqm: 350000,
      image: 'https://i.ibb.co/WQW4V4K/photo-2025-10-11-10-42-27-2.jpg',
      category: 'Wood (Yog‘och) jaluzi',
      benefits: ['100% ekologik tabiiy yog‘och', 'Yuqori darajadagi issiqlik izolyatsiyasi', 'Uzoq muddatli mustahkamlik'],
      installationInfo: 'Devor yoki shiftga mustahkam po‘lat kranislar bilan qotiriladi.'
    },
    {
      id: 'jaluzi-wood-2',
      name: '25mm Oyna Romiga Yog‘och Jaluzi',
      description: 'Plastik va yog‘och oynalar qanotiga moslashtirilgan, ixcham va yengil 25mm yog‘och gorizontal lamel jaluzilari.',
      material: 'Yengil ishlov berilgan Kanada lipa yog‘ochi',
      availableColors: ['Oq lak', 'Krem', 'Tabiiy eman', 'Shokolad'],
      pricePerSqm: 320000,
      image: 'https://i.ibb.co/ZznV0Zc2/photo-2026-09-01-12-14-47.jpg',
      category: 'Wood (Yog‘och) jaluzi',
      benefits: ['Oyna ochilishiga xalaqit bermaydi', 'Yuqori darajadagi estetik ko‘rk', 'Namlikka chidamli lak qoplamasi'],
      installationInfo: 'Oyna romiga trossli fiksator bilan mahkamlanadi.'
    }
  ],

  bambuk: [
    {
      id: 'jaluzi-bambuk-1',
      name: 'Tabiiy Karamel Bambuk Jaluzi',
      description: 'Sharqona shinamlik va tabiiy tabiat havosini baxsh etuvchi karamel rangli tabiiy bosilgan bambuk jaluzilar.',
      material: '100% Tabiiy bosilgan bambuk tolasi',
      availableColors: ['Karamel', 'Tabiiy bambuk', 'Qovurilgan yong‘oq', 'Zaytun'],
      pricePerSqm: 270000,
      image: 'https://i.ibb.co/v64TTBkS/photo-2026-02-27-10-41-16.jpg',
      category: 'Bambuk jaluzi',
      benefits: ['100% tabiiy va ekologik xavfsiz', 'Yengil vazn va tabiiy havo aylanishi', 'Antiallergik tabiiy material'],
      installationInfo: 'Devor, shift yoki oyna ramkasiga mustahkam o‘rnatiladi.'
    },
    {
      id: 'jaluzi-bambuk-2',
      name: 'To‘qilgan Bambuk Rulonli Parda',
      description: 'Yupqa bambuk cho‘plari va iplaridan to‘qilgan, yorug‘likni chiroyli chertib o‘tkazuvchi o‘rama bambuk parda.',
      material: 'Tabiiy to‘qilgan bambuk poyalari',
      availableColors: ['Tabiiy qum', 'Qorong‘i yong‘oq', 'Yashil bambuk'],
      pricePerSqm: 240000,
      image: 'https://i.ibb.co/ZznV0Zc2/photo-2026-09-01-12-14-47.jpg',
      category: 'Bambuk jaluzi',
      benefits: ['Balkon va ayvonlar uchun ajoyib yechim', 'Tabiiy salqinlik', 'Oson o‘raluvchi mexanizm'],
      installationInfo: 'Shiftga yoki oyna romiga qulay ilinadi.'
    }
  ],

  dikey: [
    {
      id: 'jaluzi-dikey-1',
      name: 'Hashamatli Dikey Vertikal Parda — Katta Zal Montaji',
      description: 'Zamonaviy ko‘p qavatli bino va kottejlar uchun nafis vertikal pardalar. Har bir lamel alohida tull va parda vazifasini o‘taydi.',
      material: 'Turkiya va Yevropa baxmal, tyul va ipak matolari',
      availableColors: ['Oq tull', 'Klassik bej', 'Zangori pastel', 'Krem', 'Antratsit'],
      pricePerSqm: 280000,
      image: 'https://i.ibb.co/NdHD2kTj/fgdf.jpg',
      category: 'Dikey pardalar',
      benefits: ['180 daraja yorug‘lik nazorati', 'Alohida lamellarni yuvish qulayligi', 'Hashamatli saroyona ko‘rinish'],
      installationInfo: 'Shift yoki devor kranisiga o‘rnatiladi.'
    },
    {
      id: 'jaluzi-dikey-2',
      name: 'Yotoqxona Uchun Shinam Dikey Pardalar',
      description: 'Nafis rangli matolardan tayyorlangan, xonadonga shinamlik va osoyishtalik ulashuvchi dikey tizimi.',
      material: 'Antistatik chang qaytaruvchi yumshoq parda matosi',
      availableColors: ['Pushti pastel', 'Krem-oltin', 'Bej', 'Fil suyagi'],
      pricePerSqm: 290000,
      image: 'https://i.ibb.co/4wvwSjvV/photo-2026-07-31-19-33-43.jpg',
      category: 'Dikey pardalar',
      benefits: ['Yumshoq yorug‘lik o‘tkazish', 'Parda va tyulning 2 tasi 1 da uyg‘unligi', 'Uzoq muddatli xizmat'],
      installationInfo: 'Shiftga mahkam kranis bilan montaj qilinadi.'
    },
    {
      id: 'jaluzi-dikey-3',
      name: 'Hashamatli Saroyona Dikey Pardasi — Baland Vitraj',
      description: 'Keng va baland derazalar uchun maxsus loyihalashtirilgan hashamatli dikey pardalar tizimi.',
      material: 'Turkiya va Yevropa premium saroyona matolari',
      availableColors: ['Oltin-krem', 'Marvarid oq', 'Zumrad', 'Shampan'],
      pricePerSqm: 310000,
      image: 'https://i.ibb.co/mCKYZBb1/photo-2026-06-30-17-27-22.jpg',
      category: 'Dikey pardalar',
      benefits: ['Baland va keng vitrajlar uchun ideal', 'Saroyona to‘kiluvchi tekstura', 'Oson parvarish'],
      installationInfo: 'Shiftga mustahkam metall kranis bilan o‘rnatiladi.'
    }
  ],

  alyumin: [
    {
      id: 'jaluzi-alyumin-1',
      name: '25mm Klassik Alyumin Gorizontal Jaluzi',
      description: 'Namlik va issiqqa mutlaqo chidamli, oshxona, sanuzel va ofislar uchun mustahkam alyumin jaluzi.',
      material: 'Korroziyaga qarshi termobirlashgan alyumin',
      availableColors: ['Oq', 'Kumush metallik', 'Oltin', 'Och bej', 'Qora'],
      pricePerSqm: 130000,
      image: 'https://i.ibb.co/5WjQr023/photo-2026-08-09-14-18-39.jpg',
      category: 'Alyumin jaluzi',
      benefits: ['100% suv va namlikka chidamli', 'Artib tozalash juda yengil', 'Uzoq yillik xizmat'],
      installationInfo: 'Oyna romiga yoki devorga o‘rnatiladi.'
    }
  ],

  rim: [
    {
      id: 'jaluzi-rim-1',
      name: 'Klassik Teksturali Rim Pardasi',
      description: 'Zanjirli mexanizm orqali gorizontal to‘lqinsimon buklamalar hosil qilib ko‘tariluvchi nafis Rim pardasi.',
      material: 'Tabiiy zig‘ir va ipak tolalari',
      availableColors: ['Tabiiy qum', 'Oq marvarid', 'To‘q jigarrang', 'Kulrang'],
      pricePerSqm: 260000,
      image: 'https://i.ibb.co/tTGYmMTy/photo-2024-09-06-12-32-19-2.jpg',
      category: 'Rim pardalari',
      benefits: ['Nafis to‘lqinsimon buklamalar', 'Oson yechib yuvish imkoniyati', 'Klassik va zamonaviy uslub'],
      installationInfo: 'Shiftga yoki oyna tepasiga o‘rnatiladi.'
    }
  ]
};

// Flattened all jaluzi models list
export const ALL_JALUZI_MODELS: Product[] = Object.values(JALUZI_MODELS_BY_CATEGORY).flat();

// Helper to determine keyword from product name, description or category
export function detectJaluziKeyword(item?: { category?: string; name?: string; description?: string; material?: string }): string {
  if (!item) return 'plisse';
  const text = `${item.category || ''} ${item.name || ''} ${item.description || ''} ${item.material || ''}`.toLowerCase();
  
  if (text.includes('plisse') || text.includes('pleated') || text.includes('gofre') || text.includes('akkordeon') || text.includes('22dx') || text.includes('parma')) {
    return 'plisse';
  }
  if (text.includes('combo') || text.includes('zebra') || text.includes('kun-tun') || text.includes('kun va tun')) {
    return 'combo';
  }
  if (text.includes('wood') || text.includes('yog‘och') || text.includes('yogoch') || text.includes('eman')) {
    return 'wood';
  }
  if (text.includes('bambuk') || text.includes('bamboo')) {
    return 'bambuk';
  }
  if (text.includes('dikey') || text.includes('vertikal') || text.includes('tyul va parda') || text.includes('22xh')) {
    return 'dikey';
  }
  if (text.includes('roller') || text.includes('rollo') || text.includes('rulon') || text.includes('blackout')) {
    return 'roller';
  }
  if (text.includes('alyumin') || text.includes('metall') || text.includes('aluminum')) {
    return 'alyumin';
  }
  if (text.includes('rim') || text.includes('roman') || text.includes('burmali')) {
    return 'rim';
  }
  return 'plisse';
}
