import { PortfolioProject } from '../types';

export interface WoodProjectItem extends PortfolioProject {
  roomType?: string;
  woodType?: string;
}

export const WOOD_GALLERY_PROJECTS: WoodProjectItem[] = [
  {
    id: 'wood-gallery-1',
    title: 'Klassik Premium Wood (Yog‘och) Gorizontal Jaluzi',
    category: 'Wood jaluzi',
    image: 'https://i.ibb.co/jPzb3mgm/photo-2026-07-20-03-54-30-2.jpg',
    description: 'Tabiiy yog‘och teksturasi va boy jilosiga ega hashamatli 25mm / 50mm yog‘och gorizontal jaluzi montaji.',
    roomType: 'Mehmonxona & Kabinet',
    woodType: 'Tabiiy yog‘och / Bambuk'
  },
  {
    id: 'wood-gallery-2',
    title: 'Qora / Qoramtir Elegant Wood Gorizontal Jaluzi Tizimi',
    category: 'Wood jaluzi',
    image: 'https://i.ibb.co/qLpp6qQr/photo-2026-07-20-03-54-30.jpg',
    description: 'Zamonaviy interyerlar, kottejlar va nufuzli ofislar uchun premium yog‘och lamelli sifatli montaj ishi.',
    roomType: 'Kottej & Ofis',
    woodType: 'Premium qora / To‘q yog‘och'
  }
];
