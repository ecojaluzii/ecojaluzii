import { PortfolioProject } from '../types';

export interface ComboProjectItem extends PortfolioProject {
  roomType?: string;
  fabricColor?: string;
}

export const COMBO_GALLERY_PROJECTS: ComboProjectItem[] = [
  {
    id: 'combo-new-1',
    title: 'Hashamatli Mehmonxona Uchun Premium Kun-Tun Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/Kp5XQX4n/photo-2026-10-01-20-53-09.jpg',
    description: 'Quyosh nurini 2 qavatli shaffof va qalin to‘qimalar orqali nozik boshqaruvchi yangi modeldagi Combo jaluzi.',
    roomType: 'Mehmonxona & Zal',
    fabricColor: 'Krem-Oltin'
  },
  {
    id: 'combo-new-2',
    title: 'Keng Panoramik Derazalar Uchun Zamonaviy Combo Montaji',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/yFH4VRgg/photo-2026-10-01-20-52-57.jpg',
    description: 'Katta oynali kottej va xonadonlar uchun qulay zanjirli va pishiq mexanizmli Combo tizimi.',
    roomType: 'Kottej & Zal',
    fabricColor: 'Klassik bej'
  },
  {
    id: 'combo-new-3',
    title: 'Yotoqxona Uchun Sokin va Shinam Combo (Zebra) Pardasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/3tPF198/photo-2026-10-01-20-52-48.jpg',
    description: 'Tungi to‘liq qorong‘ulik va kunduzgi mayin yorug‘lik rejimlariga ega qulay yotoqxona jaluzisi.',
    roomType: 'Yotoqxona',
    fabricColor: 'Pastel Krem'
  },
  {
    id: 'combo-new-4',
    title: 'Klassik va Neoklassik Interyer Uchun Jakard Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/Y4bNTyr6/photo-2026-10-01-20-52-15.jpg',
    description: 'Yevropa sifat standartlariga javob beruvchi antistatik chang tutmaydigan jakard to‘qimali Combo.',
    roomType: 'Mehmonxona',
    fabricColor: 'Marvarid Oq'
  },
  {
    id: 'combo-new-5',
    title: 'Kottej Oshxonasi va Ovqatlanish Zonasi Uchun Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/h17FN87y/photo-2026-10-01-20-51-53.jpg',
    description: 'Namlikka chidamli va oson tozalanuvchi maxsus tolalardan ishlangan zamonaviy Combo tizimi.',
    roomType: 'Oshxona',
    fabricColor: 'Shokolad Bej'
  },
  {
    id: 'combo-new-6',
    title: 'Xonadon Yashash Xonasi Uchun Nafis Kun-Tun Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/TxFFVkL6/photo-2026-10-01-20-51-39.jpg',
    description: 'Xona dizayniga uyg‘un tushuvchi, oynaning har bir qanotiga alohida mustahkam o‘rnatilgan Combo.',
    roomType: 'Yashash xonasi',
    fabricColor: 'Krem'
  },
  {
    id: 'combo-new-7',
    title: 'Zamonaviy Ofis va Kabinet Uchun Jiddiy Grafit Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/xKMgQtTq/photo-2026-10-01-20-51-26.jpg',
    description: 'Ish jarayoni uchun kompyuter ekraniga quyosh nuri tushishini to‘suvchi va qulay muhit yaratuvchi Combo.',
    roomType: 'Ofis & Kabinet',
    fabricColor: 'Kulrang / Grafit'
  },
  {
    id: 'combo-new-8',
    title: 'Balkon va Vitraj Oynalar Uchun Kun-Tun Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/0RJN4k1b/photo-2026-10-01-20-50-45.jpg',
    description: 'Jazirama issiqdan xonani salqin tutuvchi va quyosh nurlarini 100% qaytaruvchi mustahkam tizim.',
    roomType: 'Balkon & Terassa',
    fabricColor: 'Sutli oq'
  },
  {
    id: 'combo-new-9',
    title: 'Bolalar Xonasi Uchun Ekologik Toza Havfsiz Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/HD8pyPd5/photo-2026-10-01-20-50-25.jpg',
    description: 'Gipoallergen, hidsiz va bolalar salomatligi uchun to‘liq xavfsiz materiallardan tayyorlangan Combo.',
    roomType: 'Bolalar xonasi',
    fabricColor: 'Yorqin bej'
  },
  {
    id: 'combo-new-10',
    title: 'Hashamatli Mehmonxona Uchun Oltin Jiloli Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/RWnL0sV/photo-2026-10-01-20-50-04.jpg',
    description: 'Interyerga boy va zamonaviy ko‘rinish bag‘ishlovchi jiloli iplar bilan to‘qilgan oliy sifat Combo.',
    roomType: 'Mehmonxona',
    fabricColor: 'Oltin Bej'
  },
  {
    id: 'combo-new-11',
    title: 'Romga To‘g‘ridan-to‘g‘ri Mahkamlangan Ixcham Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/PvBWxmNj/photo-2026-10-01-20-49-40.jpg',
    description: 'Deraza ochilganda osilib qolmaydigan yon fiksatorli qulay va tartibli mini Combo montaji.',
    roomType: 'Yotoqxona',
    fabricColor: 'Klassik Krem'
  },
  {
    id: 'combo-new-12',
    title: 'Restoran va Qahvaxona Uchun Shinam Combo Jaluzisi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/0jtxgnd1/photo-2026-10-01-20-49-26.jpg',
    description: 'Mijozlar uchun sokin va qulay muhit hosil qiluvchi yarim shaffof chiziqli Combo pardalari.',
    roomType: 'Restoran & Kafe',
    fabricColor: 'Kofe / Bej'
  },
  {
    id: 'combo-new-13',
    title: 'Katta Zallar Uchun Maxsus Keng O‘lchamli Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/Lz8wZLWS/photo-2026-10-01-20-58-40.jpg',
    description: 'Keng maydonli derazalar uchun mustahkamlangan alyumin val va silliq rolik tizimli Combo.',
    roomType: 'Katta zal',
    fabricColor: 'Krem'
  },
  {
    id: 'combo-new-14',
    title: 'Minimalist Interyer Uchun Monoxrom Combo Pardasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/3y3FB3sn/photo-2026-10-01-20-48-17.jpg',
    description: 'Zamonaviy minimalizm uslubidagi xonalar uchun qulay yorug‘lik boshqaruviga ega Combo.',
    roomType: 'Yashash xonasi',
    fabricColor: 'Oq / Neytral'
  }
];
