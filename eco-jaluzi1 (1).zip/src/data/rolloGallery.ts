import { PortfolioProject } from '../types';

export interface RolloProjectItem extends PortfolioProject {
  roomType?: string;
  fabricType?: string;
}

export const ROLLO_GALLERY_PROJECTS: RolloProjectItem[] = [
  {
    id: 'rollo-real-1',
    title: 'Premium Rollo Blackout 100% — To‘liq Qorong‘ilashtiruvchi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/3y3FB3sn/photo-2026-10-01-20-48-17.jpg',
    description: 'Quyosh nurlarini 100% to‘suvchi va xonada mukammal qulaylik, salqinlik yaratuvchi maxsus 3 qatlamli Blackout rollo pardasi.',
    roomType: 'Yotoqxona & Mehmonxona',
    fabricType: '100% Blackout / Termo-himoya'
  },
  {
    id: 'rollo-real-2',
    title: 'Skandinavcha Shinam Rollo Dimout Matoli Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ZRvkB213/photo-2026-10-01-20-45-04-2.jpg',
    description: 'Yorug‘likni muloyim taratuvchi, xonaga nafis tabiiy yorug‘lik va iliqlik bag‘ishlovchi teksturali Dimout matosi.',
    roomType: 'Yashash xonasi & Zal',
    fabricType: 'Dimout / Yumshoq nur'
  },
  {
    id: 'rollo-real-3',
    title: 'Zamonaviy Ofis va Kabinet Uchun Rollo Screen Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/8LTq7QQR/photo-2026-10-01-20-44-41.jpg',
    description: 'Tashqi ko‘rinishni to‘smagan holda kompyuter ekranidagi quyosh aksini (blik) yo‘qotuvchi yuqori texnologiyali Screen matosi.',
    roomType: 'Ofis & Ish kabineti',
    fabricType: 'Screen / Antistatik'
  },
  {
    id: 'rollo-real-4',
    title: 'Klassik Bej Teksturali Rollo Jaluzi — Shinam Xonadon',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/HfC6zdjZ/photo-2026-10-01-20-44-06-2.jpg',
    description: 'Nafis to‘qimasi bilan mehmonxona va yotoqxonalar uchun qulaylik yaratuvchi klassik rulonli parda.',
    roomType: 'Kottej & Mehmonxona',
    fabricType: 'Klassik tekstura'
  },
  {
    id: 'rollo-real-5',
    title: 'Oshxona va Oshxona Zonasi Uchun Namlikka Chidamli Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Q3dNs8Mc/photo-2026-10-01-20-44-14.jpg',
    description: 'Yog‘ va namlikni o‘ziga tortmaydigan, nam latta bilan bir zumda tozalanadigan oshxona uchun ideal rollo parda.',
    roomType: 'Oshxona & Oshxona zonasi',
    fabricType: 'Namlikka chidamli / Gidrofob'
  },
  {
    id: 'rollo-real-6',
    title: 'Hashamatli Jakkar To‘qimali Rollo Parda Modeli',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/bMYCRP30/photo-2026-10-01-20-43-57.jpg',
    description: 'Nafis bo‘rtma naqshli jakkard matosidan ishlangan, xonaga nafislik va did bag‘ishlovchi eksklyuziv model.',
    roomType: 'Mehmonxona & Dam olish xonasi',
    fabricType: 'Jakkard relyefli'
  },
  {
    id: 'rollo-real-7',
    title: 'Zamonaviy Loft & Minimalizm Rollo Parda — Grafit',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/8gQfNcHB/photo-2026-10-01-20-43-43.jpg',
    description: 'Qat’iy geometrik va toza minimalist interyerlar uchun grafit rangdagi zamonaviy rollo jaluzi.',
    roomType: 'Loft xonadon & Ofis',
    fabricType: 'Grafit mat mato'
  },
  {
    id: 'rollo-real-8',
    title: 'Nafis Zig‘ir (Linen) Teksturali Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/9HPTG0LZ/photo-2026-10-01-20-43-28.jpg',
    description: 'Tabiiy zig‘ir matosi ko‘rinishidagi yumshoq to‘qima, ekologik shinamlik va tabiiylik ixlosmandlari uchun.',
    roomType: 'Yotoqxona & Bolalar xonasi',
    fabricType: 'Eko-zig‘ir to‘qima'
  },
  {
    id: 'rollo-real-9',
    title: 'Kassetali Rollo Jaluzi (Uni Tizimi)',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/DHxwwZCc/photo-2026-10-01-20-43-19.jpg',
    description: 'Yon yo‘naltiruvchi plankalari bilan derazaga to‘liq birikuvchi, oyna ochilganda osilib qolmaydigan kassetali tizim.',
    roomType: 'Plastik oyna & Kottej',
    fabricType: 'Kassetali Uni tizim'
  },
  {
    id: 'rollo-real-10',
    title: 'Bolalar Xonasi Uchun Quyoshdan Himoya Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/G3MmBzHC/photo-2026-10-01-20-42-59.jpg',
    description: 'Kunduzgi uyqu paytida bolalar xonasini qulay qorong‘ilatuvchi va havfsiz zanjir fiksatoriga ega parda.',
    roomType: 'Bolalar xonasi',
    fabricType: 'Gipoallergen Blackout'
  },
  {
    id: 'rollo-real-11',
    title: 'Yotoqxona Uchun Shovqin va Termo-Izolyatsion Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Qv9ffWhZ/photo-2026-10-01-20-42-48.jpg',
    description: 'Ko‘cha shovqinini kamaytiruvchi va qishda sovuqdan, yozda jaziramadan saqlovchi ko‘p qatlamli termo-rollo.',
    roomType: 'Yotoqxona',
    fabricType: 'Termo-to‘siq'
  },
  {
    id: 'rollo-real-12',
    title: 'Marvarid Tovlanuvchi Pearl Silk Rollo Pardasi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/bqwxq2B/photo-2026-10-01-20-42-33.jpg',
    description: 'Quyosh nurlari tushganda yengil marvariddek tovlanuvchi, interyerga bayramona jilo beruvchi ipak to‘qimali mato.',
    roomType: 'Mehmonxona & Zal',
    fabricType: 'Pearl ipak jilosi'
  },
  {
    id: 'rollo-real-13',
    title: 'Eko-Minimalist Rollo Parda — Qumrang Dizayn',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/KzxYsJqz/photo-2026-10-01-20-42-26.jpg',
    description: 'Tabiiy qum va tosh tuslaridagi tinchlantiruvchi ranglar uyg‘unligi, skandinavcha va yapon minimalizmi uchun.',
    roomType: 'Yashash xonasi',
    fabricType: 'Qumrang tabiiy'
  },
  {
    id: 'rollo-real-14',
    title: 'Panoramik Oynalar Uchun Keng Qamrovli Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/N6LJsPtS/photo-2026-10-01-20-41-53.jpg',
    description: 'Katta o‘lchamli derazalar va vitrajlar uchun mustahkamlangan 38mm/45mm metall vallarga ega maxsus rollo tizimi.',
    roomType: 'Vitraj & Panorama',
    fabricType: 'Katta formatli mato'
  },
  {
    id: 'rollo-real-15',
    title: 'Balkon va Vitraj Zonasi Uchun Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Dfy72Qfy/photo-2026-10-01-20-41-41.jpg',
    description: 'Balkon va lodjiyalarning ko‘p qanotli oynalariga ixcham va toza o‘rnatiluvchi mini-rollo tizimlari.',
    roomType: 'Balkon & Lodjiya',
    fabricType: 'Mini-rollo'
  },
  {
    id: 'rollo-real-16',
    title: 'Kofe va Restoranlar Uchun Dizaynerlik Rollo Pardalari',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ch8vtJ2s/photo-2026-10-01-20-41-06.jpg',
    description: 'Qahvaxonalar, restoran va butiklar uchun shinam yarim qorong‘ilik yaratuvchi professional rollo pardalar.',
    roomType: 'Kafe & Restoran',
    fabricType: 'Professional mato'
  },
  {
    id: 'rollo-real-17',
    title: 'Nafis Qirqma Matoli Rollo Parda Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/5NYBQF2/photo-2026-10-01-20-40-51.jpg',
    description: 'Yorug‘lik o‘tganda xonada chiroyli geometrik soyalar hosil qiluvchi nozik ishlov berilgan mato namunasi.',
    roomType: 'Zal & Kabinet',
    fabricType: 'Lazer naqshli'
  },
  {
    id: 'rollo-real-18',
    title: 'Pastel Tonlardagi Yengil Rollo Pardasi — Och Sariq / Qaymoq',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/4gVbsQbK/photo-2026-10-01-20-40-41.jpg',
    description: 'Quyoshli va ijobiy kayfiyat ulashuvchi, xonani iliq quyosh nurlari bilan to‘ldiruvchi pastel matoli parda.',
    roomType: 'Oshxona & Yotoqxona',
    fabricType: 'Pastel yengil mato'
  },
  {
    id: 'rollo-real-19',
    title: 'Premium Oltin Jiloli Rollo Jaluzi — Hashamatli Xonalar',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/6JNswKNv/photo-2026-10-01-20-40-28.jpg',
    description: 'Hashamatli mebel va klassik interyerlar bilan mukammal uyg‘unlashuvchi oltin jiloli rollo parda.',
    roomType: 'Mehmonxona & Saroy',
    fabricType: 'Oltin tola jakkard'
  },
  {
    id: 'rollo-real-20',
    title: 'Zamonaviy Kulrang Melanj Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/VWWLCBwp/photo-2026-10-01-20-40-11.jpg',
    description: 'Ikki xil tusdagi iplar aralashmasidan to‘qilgan melanj matoli zamonaviy rollo jaluzi.',
    roomType: 'Zamonaviy xonadon',
    fabricType: 'Melanj to‘qima'
  },
  {
    id: 'rollo-real-21',
    title: 'Klassik Oq Mat Rollo Parda — Toza Minimalizm',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/B2sk11hr/photo-2026-10-01-20-40-00.jpg',
    description: 'Hech qachon urfdan qolmaydigan, toza va yorqin oppoq mat rollo parda modeli.',
    roomType: 'Barcha xonalar',
    fabricType: 'Oq mat antistatik'
  },
  {
    id: 'rollo-real-22',
    title: 'Shinam Qahva Tusi Rollo Jaluzi — Mehmonxona Uchun',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Lzs2M6fx/photo-2026-10-01-20-39-43.jpg',
    description: 'Yashash xonalari va zallarga chuqur iliqlik beruvchi kofe tusidagi parda.',
    roomType: 'Mehmonxona',
    fabricType: 'Kofe to‘qima'
  },
  {
    id: 'rollo-real-23',
    title: 'Nafis Yashil Zaytun Rollo Pardasi — Tinchlantiruvchi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ZRnBnfKp/photo-2026-10-01-20-38-29.jpg',
    description: 'Ko‘zni quvontiruvchi, xonada tabiiy o‘simliklar va yashillik hissini beruvchi zaytun rang rollo.',
    roomType: 'Dam olish xonasi',
    fabricType: 'Zaytun tabiiy'
  },
  {
    id: 'rollo-real-24',
    title: 'Qalin Kassetali Uni-2 Rollo Jaluzi Modeli',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/HLBHvghF/photo-2026-10-01-20-38-12.jpg',
    description: 'Chuqur deraza shtapiklariga moslashgan, oyna ochilganda qimirlamaydigan mukammal kassetali tizim.',
    roomType: 'Oyna romi',
    fabricType: 'Uni-2 kasetta'
  },
  {
    id: 'rollo-real-25',
    title: 'Zamonaviy Studio Xonadonlar Uchun Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/sd6LrLR5/photo-2026-10-01-20-37-51.jpg',
    description: 'Katta maydonli studiyalar va ochiq rejali xonadonlar uchun eng to‘g‘ri pardalash yechimi.',
    roomType: 'Studiya',
    fabricType: 'Zich poliester'
  },
  {
    id: 'rollo-real-26',
    title: 'Nafis To‘qimali Qumrang Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/RG7H6S78/photo-2026-10-01-20-37-37.jpg',
    description: 'Qum va marmar tolalari taqlidi qilingan, nozik jiloli matodan ishlangan parda.',
    roomType: 'Zal & Mehmonxona',
    fabricType: 'Marmar tola'
  },
  {
    id: 'rollo-real-27',
    title: 'Oq Marvarid Teksturali Rollo — Yengil Nur Taratuvchi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Jj95SXKM/photo-2026-10-01-20-37-13.jpg',
    description: 'Quyosh nurlarini xona bo‘ylab bir tekis taratib, derazadan keladigan issiqni qaytaruvchi shinam mato.',
    roomType: 'Mehmonxona',
    fabricType: 'Marvarid oq'
  },
  {
    id: 'rollo-real-28',
    title: 'Qora Antratsit Blackout Rollo — Uy Kinoteatri Uchun',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/SXQTLWRp/photo-2026-10-01-20-36-50.jpg',
    description: 'Proyektor va televizor tomosha qilishda kunduz kuni ham 100% kinozal qorong‘iligini ta’minlovchi parda.',
    roomType: 'Kinozal & Yotoqxona',
    fabricType: '100% Antratsit Blackout'
  },
  {
    id: 'rollo-real-29',
    title: 'Klassik To‘q Jigarrang Rollo Parda — Kabinet Uchun',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/MyYXgxyW/photo-2026-10-01-20-36-29.jpg',
    description: 'Ish kabinetlari, kutubxona va nufuzli xonalar uchun jiddiy va salobatli ko‘rinish bag‘ishlovchi parda.',
    roomType: 'Ish kabineti',
    fabricType: 'To‘q jigarrang'
  },
  {
    id: 'rollo-real-30',
    title: 'Nafis Bej Rollo Jaluzi — Universal Xonadon Modeli',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Zp3qBRzb/photo-2026-10-01-20-36-13.jpg',
    description: 'Har qanday xona (yotoqxona, zal, bolalar xonasi) uchun mos keluvchi eng ommabop universal bej modeli.',
    roomType: 'Barcha xonalar',
    fabricType: 'Universal bej'
  },
  {
    id: 'rollo-real-31',
    title: 'Klassik Quyoshdan Himoyalovchi Rollo — Yengil Bej',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/BKSQ01r0/photo-2026-10-01-20-36-00.jpg',
    description: 'Xonadon derazalariga oson o‘rnatiluvchi, quyosh jaziramasidan himoyalovchi sifatli rollo pardasi.',
    roomType: 'Yotoqxona',
    fabricType: 'Yengil bej'
  },
  {
    id: 'rollo-real-32',
    title: 'Grafik Chiziqli Zamonaviy Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/fV58rwLt/photo-2026-10-01-20-35-43.jpg',
    description: 'Yengil chiziqli teksturasi bilan derazaga nafis hajm va zamonaviy uslub beruvchi yangi avlod modeli.',
    roomType: 'Mehmonxona',
    fabricType: 'Chiziqli tekstura'
  },
  {
    id: 'rollo-real-33',
    title: 'Nafis Oq To‘rli (Sheer) Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/qYNwLzfb/photo-2026-10-01-20-35-30.jpg',
    description: 'Klassik tyul pardalar o‘rnini bosuvchi, xonani ko‘cha ko‘zlaridan to‘sib, yorug‘likni to‘liq o‘tkazuvchi parda.',
    roomType: 'Zal & Mehmonxona',
    fabricType: 'Sheer shaffof to‘r'
  },
  {
    id: 'rollo-real-34',
    title: 'Kottej va Hovlilar Uchun Maxsus Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/20CxSZ4y/photo-2026-10-01-20-35-13.jpg',
    description: 'Katta hovli uylari va kottej derazalari uchun maxsus qalinlashtirilgan kassetali rollo pardasi.',
    roomType: 'Kottej & Hovli',
    fabricType: 'Kassetali tizim'
  },
  {
    id: 'rollo-real-35',
    title: 'Qaymoq Rang Shinam Rollo Parda — Mehmonxona',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/HLxBQ7t0/photo-2026-10-01-20-34-55.jpg',
    description: 'Xonadon ahlini o‘zining iliq va sokin qaymoq tuslari bilan xursand qiluvchi bejirim parda.',
    roomType: 'Mehmonxona',
    fabricType: 'Qaymoq tola'
  },
  {
    id: 'rollo-real-36',
    title: 'Muz Rangli Zamonaviy Salqin Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ynKmKLXr/photo-2026-10-01-20-34-40.jpg',
    description: 'Janubiy issiq tomondagi derazalar uchun xonaga vizual salqinlik va qulaylik baxsh etuvchi muz rang mato.',
    roomType: 'Janubiy oyna',
    fabricType: 'Muz rang termo'
  },
  {
    id: 'rollo-real-37',
    title: 'Premium Oltin Qum Jakkard Rollo Pardasi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/LD0M7GTG/photo-2026-10-01-20-34-27.jpg',
    description: 'Nafis bo‘rtma relyefli jakkard naqshlariga ega, yorug‘lik tushganda jilolanuvchi hashamatli namuna.',
    roomType: 'Hashamatli zal',
    fabricType: 'Oltin qum jakkard'
  },
  {
    id: 'rollo-real-38',
    title: 'Klassik Qora Shokolad Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/3mfMnbqc/photo-2026-10-01-20-34-15.jpg',
    description: 'Chuqur to‘q shokolad rangidagi zich parda, yotoqxona va kabinetlar uchun qulay yorug‘lik to‘sish tizimi.',
    roomType: 'Kabinet & Yotoqxona',
    fabricType: 'Qora shokolad'
  },
  {
    id: 'rollo-real-39',
    title: 'Minimalist Grafit Rollo Parda — Ofis va Shaxsiy Xona',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/bRP5LsqP/photo-2026-10-01-20-34-01.jpg',
    description: 'Toza chiziqlar, minimalist uslub va funksionallikni o‘zida jamlagan mashhur grafit rangli parda.',
    roomType: 'Ofis & Shaxsiy xona',
    fabricType: 'Grafit minimal'
  },
  {
    id: 'rollo-real-40',
    title: 'Nafis Qaymoqrang Dimout Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/vf66n2Z/photo-2026-10-01-20-33-34.jpg',
    description: 'Yotoqxona va mehmonxona uchun qulay nur taratuvchi, xona shinamligini oshiruvchi yumshoq mato.',
    roomType: 'Yotoqxona',
    fabricType: 'Dimout krem'
  },
  {
    id: 'rollo-real-41',
    title: 'Klassik Marvarid Oq Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/vCQGc07P/photo-2026-10-01-20-33-21.jpg',
    description: 'Toza, nozik va nafis ko‘rinishdagi oq marvarid matosidan ishlangan ommabop rollo pardasi.',
    roomType: 'Mehmonxona',
    fabricType: 'Marvarid oq'
  },
  {
    id: 'rollo-real-42',
    title: 'Shinam To‘q Bej Rollo Jaluzi Modeli',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/VppYkcKX/photo-2026-10-01-20-32-01.jpg',
    description: 'Derazalarga to‘liq mos keluvchi, xonadonga iliq muhit bag‘ishlovchi bejirim model.',
    roomType: 'Barcha xonalar',
    fabricType: 'To‘q bej'
  },
  {
    id: 'rollo-real-43',
    title: 'Zamon bilan Hamnafas Kulrang Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/s9dg4Y8Q/photo-2026-10-01-20-31-44.jpg',
    description: 'Yevropacha dizayn standartidagi, zamonaviy mebellarga mukammal mos keluvchi kulrang rollo pardasi.',
    roomType: 'Zamonaviy kottej',
    fabricType: 'Kulrang antistatik'
  },
  {
    id: 'rollo-real-44',
    title: 'Oshxona va Kafe Uchun Nafis Bej Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/TMfJyrx5/photo-2026-10-01-20-29-46.jpg',
    description: 'Oshxona va dam olish zonalari uchun yengil va qulay tozalanuvchi rollo pardasi.',
    roomType: 'Oshxona & Kafe',
    fabricType: 'Namlikka chidamli'
  },
  {
    id: 'rollo-real-45',
    title: 'Maxsus Mini-Kranisli Rollo Pardasi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/9kq5bRJv/photo-2026-10-01-20-28-54.jpg',
    description: 'Kichik derazalar va ingichka romlar uchun maxsus ixcham kranisli rollo tizimi.',
    roomType: 'Kichik romlar',
    fabricType: 'Mini-kranis'
  },
  {
    id: 'rollo-real-46',
    title: 'Termo-Screen Quyosh Qaytaruvchi Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/3bft3NC/photo-2026-10-01-20-28-33.jpg',
    description: 'Yozgi quyosh issiqligini tashqarida qoldirib, xonada tetiklik va salqinlik saqlovchi termo-screen.',
    roomType: 'Quyoshli tomon',
    fabricType: 'Termo-screen'
  },
  {
    id: 'rollo-real-47',
    title: 'Sutli Krem Rollo Jaluzi — Shinam Yotoqxona',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/27XrS10j/photo-2026-10-01-20-28-09.jpg',
    description: 'Yotoqxonalarda sokin va shinam dam olish muhitini shakllantiruvchi qaymoq tusli parda.',
    roomType: 'Yotoqxona',
    fabricType: 'Sutli krem'
  },
  {
    id: 'rollo-real-48',
    title: 'Klassik Fil Suyagi Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Hf7j7Fds/photo-2026-10-01-20-27-52.jpg',
    description: 'Har qanday devor qog‘ozi va mebellar bilan beg‘ubor uyg‘unlashuvchi fil suyagi rangli parda.',
    roomType: 'Mehmonxona & Xonadon',
    fabricType: 'Fil suyagi'
  }
];
