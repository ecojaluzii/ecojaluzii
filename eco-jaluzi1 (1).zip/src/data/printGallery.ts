import { PortfolioProject } from '../types';

export interface PrintProjectItem extends PortfolioProject {
  roomType?: string;
  printTheme?: string;
}

export const PRINT_GALLERY_PROJECTS: PrintProjectItem[] = [
  {
    "id": "print-gallery-1",
    "title": "Oshxona Uchun Maxsus Meva va Qahva Dizaynli Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/PzVmw055/photo-2022-08-18-12-26-29-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Meva va Qahva"
  },
  {
    "id": "print-gallery-2",
    "title": "Shinam Oshxona Uchun Nafis Gullar Mavzusidagi Print Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/wFxK7RNV/photo-2022-08-18-12-26-29.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Gullar mavzusi"
  },
  {
    "id": "print-gallery-3",
    "title": "Bolalar Xonasi Uchun Ertaknamo Qahramonlar Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/Ps5cFvjG/photo-2021-09-26-22-49-19-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Bolalar ertagi"
  },
  {
    "id": "print-gallery-4",
    "title": "Katta Zal Uchun Tabiat Manzarasi Bosilgan Foto Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/fVVgtJgM/photo-2021-09-26-22-49-19.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Katta Zal",
    "printTheme": "Tabiat manzarasi"
  },
  {
    "id": "print-gallery-5",
    "title": "Mehmonxona Oynalari Uchun Dengiz va Sohil Manzarasi Printi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/TDrVWcQ8/photo-2021-09-26-22-49-17-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Mehmonxona",
    "printTheme": "Dengiz & Sohil"
  },
  {
    "id": "print-gallery-6",
    "title": "Zamonaviy Oshxona Uchun Suvli Mevalar Mavzusidagi Print Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/C3PFBhdt/photo-2021-09-26-22-49-17.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Meva & Sharbat"
  },
  {
    "id": "print-gallery-7",
    "title": "Bolalar Yotoqxonasi Uchun Rang-barang Multfilm Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/Y7dqLPmP/photo-2021-09-26-22-49-15-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Multfilm"
  },
  {
    "id": "print-gallery-8",
    "title": "Ofis va Ish Xonasi Uchun Shahar Panoramasi Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/pvcQDsXR/photo-2021-09-26-22-49-15.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Ofis",
    "printTheme": "Shahar panoramasi"
  },
  {
    "id": "print-gallery-9",
    "title": "Xonadon Oynasi Uchun Tungi Megapolis Manzarali Foto Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/5DBqb0b/photo-2021-09-26-22-49-14-3.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Mehmonxona",
    "printTheme": "Tungi megapolis"
  },
  {
    "id": "print-gallery-10",
    "title": "Oshxona Oynalari Uchun Qahva Donachalari Dizaynli Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/5ghQsDZx/photo-2021-09-26-22-49-13-3.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Qahva donachalari"
  },
  {
    "id": "print-gallery-11",
    "title": "Shinam Yashash Zali Uchun Sharshara va Tog‘lar Print Pardasi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/TMr5wqT9/photo-2021-09-26-22-49-14-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yashash zali",
    "printTheme": "Sharshara & Tog‘lar"
  },
  {
    "id": "print-gallery-12",
    "title": "Yotoqxona Uchun Moviy Osmon va Oq Bulutlar Foto Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/Fq035RNG/photo-2021-09-26-22-49-14.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yotoqxona",
    "printTheme": "Moviy osmon"
  },
  {
    "id": "print-gallery-13",
    "title": "Bolalar Xonasi Uchun Kosmos va Sayyoralar Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/j9V8F7LP/photo-2021-09-26-22-49-13-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Kosmos & Sayyoralar"
  },
  {
    "id": "print-gallery-14",
    "title": "Kottej Oynasi Uchun Bahoriy Lolar va Gullar Mavzusi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/bMRWFpT2/photo-2021-09-26-22-49-13.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Kottej",
    "printTheme": "Bahoriy gullar"
  },
  {
    "id": "print-gallery-15",
    "title": "Mehmonxona Uchun Oltinsimon Abstrakt Naqshli Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/tS83mh6/photo-2021-09-26-22-49-12-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Mehmonxona",
    "printTheme": "Abstrakt naqsh"
  },
  {
    "id": "print-gallery-16",
    "title": "Ofis Qabulxonasi Uchun Brend Logotipi Tushirilgan Print Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/RpwPspdC/photo-2021-09-26-22-49-10-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Ofis / Biznes",
    "printTheme": "Brending / Logo"
  },
  {
    "id": "print-gallery-17",
    "title": "Oshxona Uchun Shirinliklar va Yangi Pishiriqlar Mavzusidagi Print",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/4wyj6CW3/photo-2021-09-26-22-49-11-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Shirinliklar"
  },
  {
    "id": "print-gallery-18",
    "title": "Xonadon Uchun O‘rmon va Yashil Tabiat Panoramasi Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/ccXw84Dz/photo-2021-09-26-22-49-12.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yashash zali",
    "printTheme": "Yashil o‘rmon"
  },
  {
    "id": "print-gallery-19",
    "title": "Qizlar Xonasi Uchun Nafis Pushti Gullar Print Pardasi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/Mx5XFQcy/photo-2021-09-26-22-49-11.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Pushti atirgullar"
  },
  {
    "id": "print-gallery-20",
    "title": "Yotoqxona Uchun Sokin Quyosh Botishi Manzarasi Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/j98tcsc6/photo-2021-09-26-22-49-10.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yotoqxona",
    "printTheme": "Quyosh botishi"
  },
  {
    "id": "print-gallery-21",
    "title": "Bolalar Xonasi Uchun Hayvonot Olami va Jonivorlar Foto Pardasi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/TxYCBrkZ/photo-2021-09-26-22-48-58-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Jonivorlar olami"
  },
  {
    "id": "print-gallery-22",
    "title": "Oshxona Uchun Zaytun va Ziravorlar Mavzusidagi Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/yFfP8pWC/photo-2021-09-26-22-48-58.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Zaytun & Ziravor"
  },
  {
    "id": "print-gallery-23",
    "title": "Balkon Oynalari Uchun Tropik Palmalari Mavzusidagi Print Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/0R2MGYZG/photo-2021-09-26-22-48-57-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Balkon",
    "printTheme": "Tropik palma"
  },
  {
    "id": "print-gallery-24",
    "title": "Mehmonxona Uchun Klassik San’at Asari Reproduksiyasi Printi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/5hDKXd7p/photo-2021-09-26-22-48-55.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Mehmonxona",
    "printTheme": "Klassik san’at"
  },
  {
    "id": "print-gallery-25",
    "title": "Yotoqxona Uchun Oq Atirgullar va Marvarid Naqshli Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/nMNPpFh4/photo-2021-09-26-22-48-57.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yotoqxona",
    "printTheme": "Oq atirgullar"
  },
  {
    "id": "print-gallery-26",
    "title": "Kabinet Uchun Dunyo Xaritasi Dizaynli Eksklyuziv Print Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/dwf4nwt4/photo-2021-09-26-22-48-54-3.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Kabinet / Ofis",
    "printTheme": "Dunyo xaritasi"
  },
  {
    "id": "print-gallery-27",
    "title": "Oshxona Uchun Sharqona Choyxona va Choy Mavzusidagi Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/4hLVTPy/photo-2021-09-26-22-48-54-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Sharqona choy"
  },
  {
    "id": "print-gallery-28",
    "title": "Bolalar Xonasi Uchun Kema va Dengiz Qaroqchilari Printi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/1Y1KrLfQ/photo-2021-09-26-22-48-54.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Dengiz kemalari"
  },
  {
    "id": "print-gallery-29",
    "title": "Shinam Kvartira Uchun Frantsuz Provans Uslubidagi Gullar Printi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/KBXRhsv/photo-2021-09-26-22-48-51.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Kvartira",
    "printTheme": "Provans gullari"
  },
  {
    "id": "print-gallery-30",
    "title": "Yashash Xonasi Uchun Zamonaviy 3D Geometrik Naqshli Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/B9fcvZw/photo-2021-09-26-22-48-53-3.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Mehmonxona",
    "printTheme": "3D Geometriya"
  },
  {
    "id": "print-gallery-31",
    "title": "Kottej Ayvoni Uchun Bog‘ va Gulzor Panoramasi Foto Pardasi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/sv7MT99L/photo-2021-09-26-22-48-53-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Kottej ayvoni",
    "printTheme": "Bog‘ & Gulzor"
  },
  {
    "id": "print-gallery-32",
    "title": "Oshxona Uchun Sharbat va Sitrus Mevalar Dizaynli Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/S77CPC2B/photo-2021-09-26-22-48-52.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Sitrus mevalari"
  },
  {
    "id": "print-gallery-33",
    "title": "O‘g‘il Bolalar Xonasi Uchun Poyga Mashinalari Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/Y7VjNvZ6/photo-2021-09-26-22-48-53.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Poyga mashinalari"
  },
  {
    "id": "print-gallery-34",
    "title": "Yotoqxona Uchun Yulduzli Tun va Galaktika Mavzusidagi Foto Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/ccbQj6QR/photo-2021-09-26-22-48-50.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yotoqxona",
    "printTheme": "Galaktika & Yulduz"
  },
  {
    "id": "print-gallery-35",
    "title": "Kompaniya Ofisi Uchun Korporativ Uslubdagi UV-Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/60gS1SdW/photo-2021-09-26-22-48-48-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Ofis",
    "printTheme": "Korporativ stil"
  },
  {
    "id": "print-gallery-36",
    "title": "Katta Vitraj Oyna Uchun Maxsus Buyurtma Asosidagi Foto Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/ZpSzy8vM/photo-2022-08-18-12-26-24.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Katta Vitraj",
    "printTheme": "Individual foto"
  },
  {
    "id": "print-gallery-37",
    "title": "Dam Olish Xonasi Uchun Bambuk va Zen Tabiat Mavzusi Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/LzsVdmNd/photo-2021-09-26-22-48-49-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Dam olish xonasi",
    "printTheme": "Zen & Bambuk"
  },
  {
    "id": "print-gallery-38",
    "title": "Oshxona Derazasi Uchun Nonvoyxona va Yangi Mevalar Print Pardasi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/v2tZd4d/photo-2021-09-26-22-48-49.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Oshxona mevalari"
  },
  {
    "id": "print-gallery-39",
    "title": "Mehmonxona Uchun Moviy Dengiz va Oq Qumlar Manzarali Print",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/998Yvzfn/photo-2021-09-26-22-48-48.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Mehmonxona",
    "printTheme": "Orol & Dengiz"
  },
  {
    "id": "print-gallery-40",
    "title": "Bolalar Xonasi Uchun Rangli Sharlar va Kamalak Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/8DC7XSVJ/photo-2021-09-26-22-48-47-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Bolalar xonasi",
    "printTheme": "Kamalak & Sharlar"
  },
  {
    "id": "print-gallery-41",
    "title": "Klassik Zal Uchun Nafis Marmar Fakturali UV-Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/vMHgnS1/photo-2021-09-26-22-48-46-3.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Katta Zal",
    "printTheme": "Marmar faktura"
  },
  {
    "id": "print-gallery-42",
    "title": "Yotoqxona Uchun Tungi Shahar Chiroqlari Mavzusidagi Foto Parda",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/VYf6yRRJ/photo-2021-09-26-22-48-47.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Yotoqxona",
    "printTheme": "Tungi shahar"
  },
  {
    "id": "print-gallery-43",
    "title": "Oshxona Uchun Qahvaxona Uslubidagi Retro Print Jaluzi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/zhnqNx2J/photo-2021-09-26-22-48-46-2.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Oshxona",
    "printTheme": "Retro qahvaxona"
  },
  {
    "id": "print-gallery-44",
    "title": "Xonadon Uchun Yuqori Aniqlikdagi HD Tabiat Manzarasi Print Jaluzisi",
    "category": "Print jaluzi",
    "image": "https://i.ibb.co/fGyZvC16/photo-2021-09-26-22-48-46.jpg",
    "description": "Mijoz talabiga ko‘ra individual tanlangan yuqori aniqlikdagi (HD/4K) foto surati tushirilgan sifatli Print jaluzi. Quyoshda o‘chmaydigan ekologik UV-bo‘yoqlar va 3 yillik kafolat.",
    "roomType": "Xonadon",
    "printTheme": "HD Tabiat"
  }
];
