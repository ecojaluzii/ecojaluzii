import urllib.request
import re
import os

pages = [
    ("maslahat.png", "https://ibb.co/KcBtwLSX"),
    ("rolo.png", "https://ibb.co/SXf30VkD"),
    ("dikey_barxat.png", "https://ibb.co/RGZWRVw5"),
    ("dikey.png", "https://ibb.co/RGZWRVw5"),
    ("bolalar.png", "https://ibb.co/Xrgy3b1R"),
    ("quyosh.png", "https://ibb.co/S7rtYZQB"),
    ("zamonaviy.png", "https://ibb.co/Xrgy3b1R"),
    ("oshxona.png", "https://ibb.co/gbvVH2DK"),
    ("kafolat.png", "https://ibb.co/cKSptPbC"),
    ("olchov.png", "https://ibb.co/KcBtwLSX"),
    ("tanishing.png", "https://ibb.co/M574dLHJ"),
    ("buyurtma.png", "https://ibb.co/KcBtwLSX")
]

os.makedirs("public/covers", exist_ok=True)

for name, page_url in pages:
    try:
        # Step 1: Open the ibb.co page
        req1 = urllib.request.Request(page_url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
        })
        html = urllib.request.urlopen(req1).read().decode('utf-8')
        
        # Step 2: Extract og:image
        m = re.search(r'property="og:image" content="([^"]+)"', html)
        if not m:
            print("NO OG:", name, page_url)
            continue
        
        img_url = m.group(1)
        
        # Step 3: Fetch image using page_url as Referer
        req2 = urllib.request.Request(img_url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Referer": page_url,
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
        })
        img_data = urllib.request.urlopen(req2, timeout=10).read()
        
        target_path = os.path.join("public/covers", name)
        with open(target_path, "wb") as f:
            f.write(img_data)
        print(f"SUCCESS {name}: {len(img_data)} bytes from {img_url}")
    except Exception as e:
        print(f"ERROR {name}: {e}")

print("FINISHED DOWNLOAD PERFECT")
